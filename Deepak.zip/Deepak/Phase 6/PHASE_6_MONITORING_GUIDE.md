# Phase 6: Monitoring and Operations Guide
## Hospital Data Management System - IITM Capstone Project

**Date:** 2026-06-14  
**Version:** 1.0  
**Audience:** Operations, ML Engineering, Data Engineering Teams  

---

## Quick Start Guide

### Installation

```bash
# Navigate to Phase 6 directory
cd c:\Users\ervik\Desktop\CapstoneProject\Deepak\Phase 6\

# Install dependencies (if not already installed)
pip install pandas numpy scipy scikit-learn joblib

# Verify installation
python monitoring.py
python drift_detection.py
python audit_logger.py
```

### Running Monitoring Scripts

**Daily Monitoring (Run at 00:30 UTC):**
```bash
python daily_monitoring.py
# Generates: monitoring_logs/validation_report_*.json
```

**Weekly Drift Detection (Run every Monday at 01:00 UTC):**
```bash
python weekly_drift_detection.py
# Generates: monitoring_logs/drift_report_*.json
```

**Generate Audit Summary (Run end of month):**
```bash
python generate_audit_summary.py
# Generates: audit_logs/audit_summary_*.json
```

---

## Table of Contents

1. [Monitoring Architecture](#section-1-architecture)
2. [Daily Operations](#section-2-daily-operations)
3. [Alert Response Procedures](#section-3-alert-response)
4. [Dashboard Setup](#section-4-dashboard)
5. [Troubleshooting](#section-5-troubleshooting)
6. [Integration with FastAPI](#section-6-integration)

---

<a name="section-1-architecture"></a>
## 1. Monitoring Architecture

### 1.1 System Components

```
┌─────────────────────────────────────────────────────────┐
│                 Hospital ML System                       │
└──────────┬──────────────────────────────────────────────┘
           │
    ┌──────▼──────────────────────────────────────┐
    │     Phase 5: FastAPI Service                │
    │  (main.py - Prediction API)                 │
    └──────┬───────────────────────────────────────┘
           │
    ┌──────▼──────────────────────────────────────┐
    │  Phase 6: Monitoring & Governance           │
    │                                              │
    │  ┌──────────────────────────────────────┐  │
    │  │ monitoring.py                        │  │
    │  │ - Data Validation                    │  │
    │  │ - Performance Metrics                │  │
    │  │ - Data Quality Assessment            │  │
    │  └──────────────────────────────────────┘  │
    │                                              │
    │  ┌──────────────────────────────────────┐  │
    │  │ drift_detection.py                   │  │
    │  │ - Feature Drift (KS Test)            │  │
    │  │ - Prediction Drift (Chi-Square)      │  │
    │  │ - Data Drift Analysis                │  │
    │  └──────────────────────────────────────┘  │
    │                                              │
    │  ┌──────────────────────────────────────┐  │
    │  │ audit_logger.py                      │  │
    │  │ - Prediction Logs                    │  │
    │  │ - Model Operation Logs               │  │
    │  │ - Audit Summary                      │  │
    │  └──────────────────────────────────────┘  │
    │                                              │
    │  ┌──────────────────────────────────────┐  │
    │  │ monitoring_logs/ (Output)            │  │
    │  │ - validation_report_*.json           │  │
    │  │ - performance_metrics_*.json         │  │
    │  │ - quality_metrics_*.json             │  │
    │  │ - drift_report_*.json                │  │
    │  │ - monitor_*.log                      │  │
    │  └──────────────────────────────────────┘  │
    │                                              │
    │  ┌──────────────────────────────────────┐  │
    │  │ audit_logs/ (Output)                 │  │
    │  │ - prediction_logs_*.json             │  │
    │  │ - model_logs_*.json                  │  │
    │  │ - audit_summary_*.json               │  │
    │  └──────────────────────────────────────┘  │
    └──────────────────────────────────────────┘
```

### 1.2 Data Flow

```
Raw Data (Patients, Visits, Billing)
    ↓
Feature Engineering (build_features.py)
    ↓
Model Predictions (main.py)
    ↓
┌─────────────────────────────────────────┐
│ MONITORING                              │
├─────────────────────────────────────────┤
│ 1. Validate Input Data                  │
│    - Check missing values               │
│    - Check numeric ranges               │
│    - Check categorical values           │
│    - Check for duplicates               │
│                                          │
│ 2. Assess Data Quality                  │
│    - Completeness %                     │
│    - Outlier detection                  │
│    - Categorical cardinality            │
│                                          │
│ 3. Track Performance                    │
│    - Accuracy, Precision, Recall, F1   │
│    - Per-class metrics                  │
│    - Confusion matrix                   │
│                                          │
│ 4. Detect Drift                         │
│    - Feature drift (KS test)            │
│    - Prediction drift (Chi-square)      │
│    - Overall drift score                │
│                                          │
│ 5. Log Everything                       │
│    - Prediction audit logs              │
│    - Model operation logs               │
│    - Data operation logs                │
│    - Audit summary                      │
│                                          │
│ 6. Generate Alerts                      │
│    - Critical alerts → Immediate        │
│    - Warnings → Within 2 hours          │
│    - Info → Dashboard                   │
└─────────────────────────────────────────┘
    ↓
Reports & Dashboards
```

---

<a name="section-2-daily-operations"></a>
## 2. Daily Operations

### 2.1 Morning Checklist (Daily at 09:00 UTC)

```bash
# 1. Check system health
curl http://localhost:8000/health

# Response should be:
# {
#   "status": "healthy",
#   "timestamp": "2026-06-14T09:00:00Z",
#   "models": {"risk": "active", "claim": "active"},
#   "uptime_hours": 24.5
# }

# If not healthy, see Troubleshooting section

# 2. Check yesterday's monitoring reports
ls -lh monitoring_logs/validation_report_*.json
ls -lh monitoring_logs/performance_metrics_*.json

# 3. Review alerts from yesterday
grep "ERROR\|WARNING" monitoring_logs/monitor_risk_*.log
grep "ERROR\|WARNING" monitoring_logs/monitor_claim_*.log

# 4. Check prediction volume
python scripts/check_prediction_volume.py --date $(date -d yesterday +%Y-%m-%d)

# 5. Verify data freshness
python scripts/check_data_freshness.py
```

### 2.2 Data Validation (Daily at 00:30 UTC)

**Script: `daily_validation.py`**

```python
#!/usr/bin/env python3
"""
Daily data validation script
Run at 00:30 UTC daily
"""

import sys
from pathlib import Path
from datetime import datetime, timedelta
import pandas as pd
import logging

# Add Phase modules to path
sys.path.insert(0, str(Path(__file__).parent))

from monitoring import ModelMonitor
from drift_detection import DriftDetector

# Configuration
RISK_FEATURES = {
    "numeric_features": {
        "age": {"min": 0, "max": 120},
        "length_of_stay_hours": {"min": 0, "max": 1000},
        "billed_amount": {"min": 0, "max": 500000},
        "revenue_realization_ratio": {"min": 0, "max": 1.0},
        "visit_frequency": {"min": 1, "max": 100},
        "avg_los_per_patient": {"min": 0, "max": 1000},
        "days_since_registration": {"min": 0, "max": 10000},
        "provider_rejection_rate": {"min": 0, "max": 100}
    },
    "categorical_features": {
        "gender": ["M", "F"],
        "city": ["Delhi", "Mumbai", "Bangalore", "Chennai", "Pune"],
        "visit_type": ["OPD", "ER", "ICU"],
        "department": ["Cardiology", "ER", "General", "ICU", "Neurology", "Orthopedics"],
        "insurance_provider": ["ICICI Health", "Star Health", "Max Bupa", "Apollo Health"],
        "visit_month": [1,2,3,4,5,6,7,8,9,10,11,12],
        "visit_quarter": [1,2,3,4],
        "visit_day_of_week": [0,1,2,3,4,5,6]
    }
}

def main():
    # Setup logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s'
    )
    logger = logging.getLogger(__name__)
    
    logger.info("Starting daily validation...")
    
    try:
        # Load today's data (assuming it's updated from operational systems)
        today = datetime.now().strftime("%Y-%m-%d")
        # In production: df = load_data_from_warehouse(today)
        # For now, create monitor to validate incoming data
        
        monitor = ModelMonitor("risk", RISK_FEATURES)
        
        # Load latest data (example - replace with actual data source)
        # df = pd.read_csv(f"data/daily_extract_{today}.csv")
        
        # For demo purposes, create sample data
        df = pd.DataFrame({
            "age": [25, 45, 65, 35, 55] * 10,  # 50 rows
            "gender": ["M", "F"] * 25,
            "city": ["Delhi", "Mumbai", "Bangalore"] * 17,
            "visit_type": ["OPD", "ER", "ICU"] * 17,
            "department": ["Cardiology", "ER", "General"] * 17,
            "length_of_stay_hours": [2, 12, 24, 36, 48] * 10,
            "billed_amount": [5000, 15000, 25000, 35000, 50000] * 10,
            "revenue_realization_ratio": [0.9, 0.85, 0.95, 0.88, 0.92] * 10,
            "insurance_provider": ["ICICI Health", "Star Health", "Max Bupa"] * 17,
            "provider_rejection_rate": [5, 8, 12, 3, 6] * 10,
            "visit_frequency": [1, 2, 3, 1, 2] * 10,
            "avg_los_per_patient": [12, 18, 24, 15, 20] * 10,
            "days_since_registration": [30, 90, 180, 365, 730] * 10,
            "visit_month": [6] * 50,
            "visit_quarter": [2] * 50,
            "visit_day_of_week": [2] * 50
        })
        
        logger.info(f"Loaded {len(df)} records")
        
        # 1. Validate data
        validation_report = monitor.validate_data(df)
        monitor.save_validation_report(validation_report)
        logger.info(f"Validation report saved: {validation_report.is_valid}")
        
        # 2. Assess data quality
        quality_metrics = monitor.assess_data_quality(df)
        monitor.save_quality_metrics(quality_metrics)
        logger.info(f"Quality metrics: {quality_metrics.completeness_pct:.2f}% complete")
        
        # 3. Generate alerts if issues found
        if not validation_report.is_valid:
            logger.warning(f"Validation failed with {len(validation_report.alerts)} alerts")
            for alert in validation_report.alerts:
                logger.warning(f"  - {alert}")
        
        if quality_metrics.completeness_pct < 95:
            logger.warning(f"Data completeness low: {quality_metrics.completeness_pct:.2f}%")
        
        logger.info("Daily validation completed successfully")
        return 0
        
    except Exception as e:
        logger.error(f"Daily validation failed: {str(e)}")
        return 1

if __name__ == "__main__":
    sys.exit(main())
```

### 2.3 Weekly Drift Detection (Every Monday at 01:00 UTC)

**Script: `weekly_drift_detection.py`**

```python
#!/usr/bin/env python3
"""
Weekly drift detection script
Run every Monday at 01:00 UTC
"""

import sys
from pathlib import Path
import pandas as pd
import numpy as np
import logging
from datetime import datetime, timedelta

sys.path.insert(0, str(Path(__file__).parent))

from drift_detection import DriftDetector

def main():
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s'
    )
    logger = logging.getLogger(__name__)
    
    logger.info("Starting weekly drift detection...")
    
    try:
        # Load baseline training data
        # In production: baseline_data = load_training_data()
        baseline_data = pd.DataFrame({
            "age": np.random.normal(45, 15, 100),
            "gender": np.random.choice(["M", "F"], 100),
            "city": np.random.choice(["Delhi", "Mumbai", "Bangalore"], 100),
            "billed_amount": np.random.uniform(5000, 50000, 100),
            "revenue_realization_ratio": np.random.uniform(0.8, 1.0, 100)
        })
        
        feature_schema = {
            "numeric": ["age", "billed_amount", "revenue_realization_ratio"],
            "categorical": ["gender", "city"]
        }
        
        detector = DriftDetector("risk", baseline_data, feature_schema)
        logger.info(f"Loaded baseline data: {len(baseline_data)} records")
        
        # Load current week's data (simulated)
        current_data = pd.DataFrame({
            "age": np.random.normal(48, 18, 50),  # Slight shift
            "gender": np.random.choice(["M", "F"], 50),
            "city": np.random.choice(["Delhi", "Mumbai", "Bangalore"], 50),
            "billed_amount": np.random.uniform(6000, 60000, 50),  # Slight shift
            "revenue_realization_ratio": np.random.uniform(0.75, 1.0, 50)
        })
        
        logger.info(f"Loaded current week data: {len(current_data)} records")
        
        # Generate fake baseline and current predictions for drift test
        baseline_preds = np.random.choice(["Low", "Medium", "High"], 100)
        current_preds = np.random.choice(["Low", "Medium", "High"], 50)
        
        # Generate comprehensive drift report
        drift_report = detector.generate_drift_report(
            current_data,
            baseline_preds,
            current_preds,
            ["Low", "Medium", "High"],
            report_period="weekly"
        )
        
        # Save report
        filepath = detector.save_drift_report(drift_report)
        logger.info(f"Drift report saved: {filepath}")
        
        # Check for high drift and alert
        if drift_report.drift_level in ["high", "moderate"]:
            logger.warning(f"DRIFT ALERT: Drift level is {drift_report.drift_level}")
            logger.warning(f"  Overall Score: {drift_report.overall_drift_score:.4f}")
            logger.warning(f"  Features with drift: {drift_report.features_with_drift}")
            logger.warning("  Recommendation: Schedule model retraining")
        else:
            logger.info(f"Drift status: {drift_report.drift_level}")
        
        logger.info("Weekly drift detection completed")
        return 0
        
    except Exception as e:
        logger.error(f"Drift detection failed: {str(e)}")
        return 1

if __name__ == "__main__":
    sys.exit(main())
```

### 2.4 Prediction Logging (Continuous)

Each prediction from `main.py` should be logged:

```python
# In main.py - Add to prediction endpoint

from audit_logger import AuditLogger

audit_logger = AuditLogger()

@app.post("/predict/risk")
async def predict_risk(request: RiskPredictionRequest):
    try:
        # Make prediction
        prediction = model.predict(features)[0]
        confidence = max(model.predict_proba(features)[0])
        
        # Log prediction
        audit_log = audit_logger.log_prediction(
            model_type="risk",
            model_version="1.0.0",
            input_data=request.dict(),
            prediction=prediction,
            prediction_confidence=float(confidence),
            user_id=request.user_id,
            request_id=str(uuid.uuid4()),
            processing_time_ms=elapsed_time_ms,
            data_quality_score=data_quality_score,
            status="success"
        )
        
        # Return prediction
        return {
            "prediction": prediction,
            "confidence": confidence,
            "log_id": audit_log.log_id
        }
        
    except Exception as e:
        # Log failed prediction
        audit_logger.log_prediction(
            model_type="risk",
            model_version="1.0.0",
            input_data=request.dict(),
            prediction="ERROR",
            status="failed",
            error_message=str(e),
            user_id=request.user_id
        )
        raise
```

---

<a name="section-3-alert-response"></a>
## 3. Alert Response Procedures

### 3.1 Alert Priority Levels and Response

**CRITICAL - Respond Within 15 Minutes**

```
Alert: "Accuracy dropped to 75%"

IMMEDIATE ACTIONS:
1. Page on-call ML engineer immediately (SMS)
2. Get incident commander on bridge call
3. Check monitoring dashboard for context
4. Examine last 100 predictions for errors
5. Check data quality report
6. Initiate automatic rollback if not already triggered

ROOT CAUSE CHECKLIST:
□ Is API serving latest model? (Check version)
□ Is input data corrupted? (Check validation report)
□ Has feature distribution changed? (Check drift report)
□ Did recent deployment introduce bug? (Check model logs)
□ Is infrastructure degraded? (Check resource usage)

RESPONSE:
□ Rollback to previous model version
□ OR Fix data issue and retrain
□ OR Fix infrastructure and resume
□ Notify stakeholders of resolution
□ Create incident ticket for post-analysis
```

**WARNING - Respond Within 1 Hour**

```
Alert: "Data completeness dropped to 92%"

ACTIONS:
1. Notify data quality team
2. Check data sources for issues
3. Investigate which fields are missing
4. Determine if data is still usable for predictions
5. Create ticket to investigate root cause

MONITORING:
- Monitor trend over next few hours
- If continues to degrade → escalate to CRITICAL
- If resolves → mark as resolved
```

**INFO - Routine Tracking**

```
Alert: "Drift score increased to 0.35 (moderate)"

ACTIONS:
1. Review drift report details
2. Identify which features show drift
3. Schedule model retraining (within 1 week)
4. Add to monthly retraining queue
5. No immediate action needed

MONITORING:
- Track drift score over time
- If continues to increase → escalate to retraining urgently
```

### 3.2 Alert Runbook Example

**Alert: "Model Predictions Failing - 20% Error Rate in Last Hour"**

```
SEVERITY: CRITICAL

SYMPTOMS:
- Error rate spike in last hour
- User reports seeing error messages
- Prediction API returning 500 errors

DIAGNOSIS (Take 5 minutes):
□ Step 1: Check API logs
  Command: tail -f logs/api_service_*.log | grep ERROR
  Expected: See actual error messages

□ Step 2: Check data validation
  Command: tail monitoring_logs/validation_report_*.json
  Expected: See if data validation is passing

□ Step 3: Check model availability
  Command: curl http://localhost:8000/models/status
  Expected: See if models are loaded

□ Step 4: Check resource usage
  Command: docker stats
  Expected: CPU/Memory not maxed out

□ Step 5: Check recent deployments
  Command: grep "deployment" audit_logs/model_logs_*.json
  Expected: See if deployment happened recently

REMEDIATION (Choose based on diagnosis):

If Data Validation Failed:
  → Contact data team immediately
  → Pause predictions
  → Wait for data fix
  → Resume predictions

If Model Not Loaded:
  → Restart API service: docker restart ml-api
  → Verify: curl http://localhost:8000/health
  → Resume predictions

If Resource Exhausted:
  → Scale up container/instance
  → Restart API service
  → Monitor resource usage
  → Investigate memory leak if continues

If Recent Deployment Caused Issue:
  → Trigger rollback: python scripts/rollback_model.py --model risk --version 1.0.0
  → Verify: curl http://localhost:8000/health
  → Create incident ticket
  → Investigate root cause

VERIFICATION (After remediation):
□ Check error rate dropped below 2%
□ Verify 100 recent predictions successful
□ Check monitoring dashboard shows green
□ Notify stakeholders of resolution
□ Schedule post-incident review within 24h

POST-INCIDENT (Within 24 hours):
1. Review incident timeline
2. Identify root cause
3. Determine preventive measures
4. Create ticket for improvements
5. Update runbooks as needed
```

---

<a name="section-4-dashboard"></a>
## 4. Dashboard Setup

### 4.1 Monitoring Dashboard (Recommended: Grafana + Prometheus)

**Install Grafana:**
```bash
docker pull grafana/grafana
docker run -d -p 3000:3000 --name grafana grafana/grafana
# Access at http://localhost:3000 (admin/admin)
```

**Dashboard Panels:**

```
┌──────────────────────────────────────────────┐
│     Hospital ML System - Monitoring          │
│                                              │
├──────────────────┬───────────────────────────┤
│  Status: HEALTHY │ Uptime: 99.8% (50 days)   │
├──────────────────┬───────────────────────────┤
│ Predictions (24h)│ Success Rate              │
│      15,432      │      99.1%                │
├──────────────────┬───────────────────────────┤
│ Model Version    │ Last Retrain              │
│ risk: 1.0.0      │ 2026-06-10 15:30 UTC      │
│ claim: 1.0.0     │ 2026-06-10 14:15 UTC      │
├──────────────────┴───────────────────────────┤
│ PERFORMANCE METRICS (Risk Model)             │
├──────────────────┬───────────────────────────┤
│ Accuracy: 85.2%  │ Precision: 84.9%          │
│ Recall: 85.5%    │ F1-Score: 85.2%           │
├──────────────────┴───────────────────────────┤
│ DATA QUALITY                                 │
├──────────────────┬───────────────────────────┤
│ Completeness:97.8│ Drift Score: 0.15         │
│ Duplicates: 0    │ Drift Level: NONE         │
├──────────────────┴───────────────────────────┤
│ ALERTS                                       │
├──────────────────────────────────────────────┤
│ ✓ All systems healthy                        │
│ ℹ  Scheduled retraining: 2026-07-01          │
│ ⚠  Monitor feature 'age' - slight drift       │
└──────────────────────────────────────────────┘
```

### 4.2 Key Metrics to Display

**Real-time (Updated every minute):**
- System health status (green/yellow/red)
- API response time (ms)
- Error rate (%)
- Prediction volume (last 1h)

**Hourly:**
- Accuracy trend (last 24h)
- Prediction distribution (by class)
- Data quality score

**Daily:**
- F1-score trend (last 30 days)
- Drift score trend
- Model deployments/rollbacks
- Incident count

**Weekly:**
- Feature importance
- Per-class performance
- User activity

### 4.3 Alert Configuration

**Configure Alert Rules in Prometheus:**

```yaml
# prometheus.yml
global:
  scrape_interval: 1m

scrape_configs:
  - job_name: 'hospital-ml'
    static_configs:
      - targets: ['localhost:9090']

alerting:
  alertmanagers:
    - static_configs:
        - targets: ['localhost:9093']

rule_files:
  - 'alert_rules.yml'
```

**Alert Rules:**

```yaml
# alert_rules.yml

groups:
  - name: hospital_ml_alerts
    rules:
      - alert: HighErrorRate
        expr: error_rate > 10
        for: 5m
        labels:
          severity: critical
        annotations:
          summary: "Error rate high"

      - alert: LowAccuracy
        expr: model_accuracy < 0.80
        for: 10m
        labels:
          severity: critical

      - alert: HighDrift
        expr: drift_score > 0.5
        for: 1h
        labels:
          severity: warning
        annotations:
          summary: "High prediction drift detected"

      - alert: DataQualityIssue
        expr: data_completeness < 0.95
        for: 5m
        labels:
          severity: warning
```

---

<a name="section-5-troubleshooting"></a>
## 5. Troubleshooting

### 5.1 Common Issues and Solutions

**Issue: API Not Responding**

```
Symptoms: curl http://localhost:8000/health returns Connection Refused

Troubleshooting:
1. Check if service is running: docker ps | grep ml-api
   
   If not running:
   → docker run -p 8000:8000 hospital-ml-api:1.0
   
2. Check logs: docker logs ml-api
   Expected: See startup messages, no errors
   
3. Check resource limits: docker stats ml-api
   Expected: CPU/Memory usage reasonable
   
4. If stuck, restart: docker restart ml-api

Resolution Time: <5 minutes
```

**Issue: Predictions Failing - Validation Errors**

```
Symptoms:
- Prediction requests returning 422 errors
- Validation report shows missing values
- Monitoring logs show "validation_failed"

Troubleshooting:
1. Check validation report:
   cat monitoring_logs/validation_report_*.json | jq .

2. Identify which fields are missing:
   - Look for .missing_value_issues in report
   
3. Check data source:
   - Connect to database directly
   - Run: SELECT * FROM visits LIMIT 10
   - Check if expected fields exist

4. If field missing from new data:
   → Add field to data extraction query
   → Re-run daily data load
   → Resume predictions

5. If field shouldn't be required:
   → Update feature schema
   → Update validation rules
   → Re-run validation

Resolution Time: 15-30 minutes
```

**Issue: Model Accuracy Degraded**

```
Symptoms:
- Accuracy dropped from 85% to 78%
- Precision/Recall imbalanced
- Error rate spiked

Root Cause Analysis:
1. Check if data distribution changed:
   → Run drift detection
   → Compare current vs. baseline statistics
   
2. Check if model is correct version:
   → curl http://localhost:8000/models/risk/version
   → Should return "1.0.0" (or latest)
   
3. Check prediction volume:
   → Are predictions being made on similar data?
   → If yes, investigate feature drift
   
4. Check if recent deployment issue:
   → grep "deployment" audit_logs/model_logs_*.json
   → Did deployment happen in last few hours?

Resolution:
IF Drift Detected:
  → Schedule urgent retraining
  → Run: python scripts/retrain_model.py --model risk --urgent
  
IF Wrong Model Deployed:
  → Rollback to previous version
  → Run: python scripts/rollback_model.py --model risk

IF Recent Deployment Caused Issue:
  → Rollback immediately
  → Investigate code changes
  → Fix and redeploy

Resolution Time: 30-60 minutes
```

**Issue: High Drift Score but No Clear Root Cause**

```
Symptoms:
- Drift score 0.45-0.65 (moderate/high)
- Multiple features showing drift
- But performance metrics still good

This is NORMAL and means:
- Data distribution is slowly evolving
- Model still performs OK (hasn't degraded yet)
- Proactive retraining needed

Actions:
1. Document which features are drifting
2. Investigate root cause:
   - New patient demographics?
   - Insurance policy changes?
   - Seasonal patterns?
   - Data collection changes?

3. Schedule retraining within 1 week
4. Collect more data to understand pattern
5. Retrain model monthly to adapt

This is NOT an emergency - continue monitoring
```

### 5.2 Diagnostic Commands

```bash
# Check if API is healthy
curl http://localhost:8000/health

# Get current model version
curl http://localhost:8000/models/versions

# Get prediction stats (last 1h)
python scripts/get_prediction_stats.py --hours 1

# View monitoring logs
tail -f monitoring_logs/monitor_risk_*.log

# View recent errors
grep "ERROR" monitoring_logs/*.log | tail -20

# Check drift status
cat monitoring_logs/drift_report_*.json | jq '.drift_level'

# Get audit summary
cat audit_logs/audit_summary_*.json | jq '.successful_predictions'

# Monitor in real-time
watch -n 5 'curl http://localhost:8000/health && echo "" && ls -lh monitoring_logs/ | tail -5'
```

---

<a name="section-6-integration"></a>
## 6. Integration with FastAPI

### 6.1 Adding Monitoring to main.py

```python
# In main.py - Add monitoring imports
import sys
sys.path.insert(0, str(Path(__file__).parent / "Phase 6"))

from monitoring import ModelMonitor, AlertManager
from drift_detection import DriftDetector
from audit_logger import AuditLogger

# Initialize monitoring components (on startup)
app_state = {
    "monitors": {
        "risk": ModelMonitor("risk", RISK_FEATURE_SCHEMA),
        "claim": ModelMonitor("claim", CLAIM_FEATURE_SCHEMA)
    },
    "drift_detectors": {
        "risk": DriftDetector("risk", baseline_risk_data, RISK_FEATURE_SCHEMA),
        "claim": DriftDetector("claim", baseline_claim_data, CLAIM_FEATURE_SCHEMA)
    },
    "audit_logger": AuditLogger(),
    "alert_manager": AlertManager()
}

@app.post("/predict/risk")
async def predict_risk(request: RiskPredictionRequest):
    start_time = time.time()
    request_id = str(uuid.uuid4())
    
    try:
        # 1. Validate input data
        input_df = pd.DataFrame([request.dict()])
        validation_report = app_state["monitors"]["risk"].validate_data(input_df)
        
        if not validation_report.is_valid:
            # Log failed prediction
            app_state["audit_logger"].log_prediction(
                model_type="risk",
                model_version="1.0.0",
                input_data=request.dict(),
                prediction="ERROR",
                status="validation_failed",
                request_id=request_id,
                error_message=str(validation_report.alerts)
            )
            raise HTTPException(
                status_code=422,
                detail=f"Input validation failed: {validation_report.alerts}"
            )
        
        # 2. Make prediction
        prediction = model.predict(features)[0]
        confidence = float(max(model.predict_proba(features)[0]))
        
        # 3. Calculate data quality score
        quality_metrics = app_state["monitors"]["risk"].assess_data_quality(input_df)
        data_quality_score = quality_metrics.completeness_pct / 100.0
        
        # 4. Log successful prediction
        processing_time_ms = (time.time() - start_time) * 1000
        audit_log = app_state["audit_logger"].log_prediction(
            model_type="risk",
            model_version="1.0.0",
            input_data=request.dict(),
            prediction=prediction,
            prediction_confidence=confidence,
            user_id=request.user_id,
            request_id=request_id,
            processing_time_ms=processing_time_ms,
            data_quality_score=data_quality_score,
            status="success"
        )
        
        # 5. Check for alerts (offline, don't delay response)
        if data_quality_score < 0.95:
            app_state["alert_manager"].add_alert(
                severity="warning",
                message=f"Data quality low: {data_quality_score:.2%}",
                category="data_quality"
            )
        
        return {
            "prediction": prediction,
            "confidence": confidence,
            "log_id": audit_log.log_id
        }
        
    except Exception as e:
        processing_time_ms = (time.time() - start_time) * 1000
        
        # Log failed prediction
        app_state["audit_logger"].log_prediction(
            model_type="risk",
            model_version="1.0.0",
            input_data=request.dict(),
            prediction="ERROR",
            status="failed",
            request_id=request_id,
            error_message=str(e),
            processing_time_ms=processing_time_ms,
            user_id=request.user_id
        )
        
        # Alert critical failure
        app_state["alert_manager"].add_alert(
            severity="critical",
            message=f"Prediction failed: {str(e)}",
            category="prediction_error"
        )
        
        raise HTTPException(status_code=500, detail=str(e))

# Add health check endpoint
@app.get("/health")
async def health_check():
    return {
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "models": {"risk": "active", "claim": "active"},
        "uptime_minutes": uptime_minutes
    }

# Add monitoring endpoints
@app.get("/monitoring/alerts")
async def get_alerts():
    return {
        "alerts": [a.to_dict() for a in app_state["alert_manager"].get_critical_alerts()],
        "alert_count": len(app_state["alert_manager"].get_critical_alerts())
    }

@app.get("/monitoring/performance/{model_type}")
async def get_performance(model_type: str):
    # Return latest performance metrics
    pass
```

### 6.2 Scheduled Monitoring Tasks

```python
# Use APScheduler for scheduled monitoring tasks

from apscheduler.schedulers.background import BackgroundScheduler

scheduler = BackgroundScheduler()

# Daily validation at 00:30 UTC
@scheduler.scheduled_job('cron', hour=0, minute=30)
def daily_validation_job():
    logger.info("Running daily validation...")
    try:
        # Run validation on latest data
        # Save reports
    except Exception as e:
        logger.error(f"Daily validation failed: {e}")
        app_state["alert_manager"].add_alert(
            severity="critical",
            message="Daily validation failed",
            category="monitoring_failure"
        )

# Weekly drift detection on Monday at 01:00 UTC
@scheduler.scheduled_job('cron', day_of_week='mon', hour=1, minute=0)
def weekly_drift_detection_job():
    logger.info("Running weekly drift detection...")
    try:
        # Run drift detection
        # Generate reports
        # Check for high drift
    except Exception as e:
        logger.error(f"Drift detection failed: {e}")

# Monthly audit summary on 1st of month at 02:00 UTC
@scheduler.scheduled_job('cron', day=1, hour=2, minute=0)
def monthly_audit_summary_job():
    logger.info("Generating monthly audit summary...")
    try:
        # Generate audit summary
        # Save report
        # Email to stakeholders
    except Exception as e:
        logger.error(f"Audit summary generation failed: {e}")

scheduler.start()
```

---

## Conclusion

This monitoring and operations guide provides the framework for maintaining a healthy, reliable hospital ML system. Regular monitoring, prompt alert response, and proactive drift detection ensure that predictions remain accurate and trustworthy.

**Key Operations Reminders:**
1. ✅ Daily validation at 00:30 UTC
2. ✅ Weekly drift detection every Monday
3. ✅ Respond to CRITICAL alerts within 15 minutes
4. ✅ Review performance trends daily
5. ✅ Escalate high drift for urgent retraining
6. ✅ Maintain complete audit trail
7. ✅ Monthly retraining scheduled
8. ✅ Quarterly compliance reviews

**For Support:**
- ML Team: ml-team@hospital.com
- On-call Engineer: See Slack #ml-oncall
- Escalation: Director of AI/ML
- Emergency: Call 1-800-ML-CRISIS

---

**Document Version:** 1.0  
**Last Updated:** 2026-06-14  
**Next Review:** 2026-09-14
