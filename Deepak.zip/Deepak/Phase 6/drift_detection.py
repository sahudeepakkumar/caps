"""
Phase 6: Drift Detection Module for Hospital ML System
Detects feature drift, prediction drift, and data drift

Created: 2026-06-14
Version: 1.0

This module provides:
- Feature drift detection (statistical tests, Kolmogorov-Smirnov)
- Prediction drift detection (output distribution changes)
- Data drift detection (statistical metrics)
- Drift scoring and alerts
"""

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass, asdict

import numpy as np
import pandas as pd
from scipy import stats


# ============================================================================
# DATA STRUCTURES
# ============================================================================

@dataclass
class FeatureDriftMetrics:
    """Metrics for feature drift"""
    feature_name: str
    data_type: str  # "numeric" or "categorical"
    drift_detected: bool
    drift_score: float  # 0-1, higher means more drift
    p_value: float  # Statistical test p-value
    baseline_stats: Dict
    current_stats: Dict
    method: str  # "ks_test" for numeric, "chi2" for categorical
    threshold: float
    
    def to_dict(self) -> Dict:
        return asdict(self)


@dataclass
class PredictionDriftMetrics:
    """Metrics for prediction drift"""
    timestamp: str
    model_type: str
    drift_detected: bool
    drift_score: float  # 0-1
    baseline_distribution: Dict[str, float]
    current_distribution: Dict[str, float]
    class_shift: Dict[str, float]  # Percentage change per class
    chi2_statistic: float
    p_value: float
    method: str
    
    def to_dict(self) -> Dict:
        return asdict(self)


@dataclass
class DataDriftReport:
    """Comprehensive data drift report"""
    timestamp: str
    report_period: str
    total_features_analyzed: int
    features_with_drift: int
    feature_drift_metrics: List[FeatureDriftMetrics]
    prediction_drift_metrics: Optional[PredictionDriftMetrics]
    overall_drift_score: float  # Average drift across features
    drift_level: str  # "none", "low", "moderate", "high"
    alerts: List[str]
    recommendations: List[str]
    
    def to_dict(self) -> Dict:
        data = asdict(self)
        data["feature_drift_metrics"] = [m.to_dict() for m in self.feature_drift_metrics]
        if self.prediction_drift_metrics:
            data["prediction_drift_metrics"] = self.prediction_drift_metrics.to_dict()
        return data


# ============================================================================
# DRIFT DETECTOR CLASS
# ============================================================================

class DriftDetector:
    """
    Comprehensive drift detection system for hospital ML models
    """
    
    def __init__(self, model_name: str, baseline_data: pd.DataFrame,
                 feature_schema: Dict, output_dir: str = "monitoring_logs"):
        """
        Initialize drift detector
        
        Args:
            model_name: "risk" or "claim"
            baseline_data: Training data for baseline statistics
            feature_schema: Dictionary with feature definitions
            output_dir: Directory to store drift reports
        """
        self.model_name = model_name
        self.baseline_data = baseline_data
        self.feature_schema = feature_schema
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(exist_ok=True)
        
        # Setup logging
        self.logger = logging.getLogger(f"drift_{model_name}")
        self.logger.setLevel(logging.INFO)
        handler = logging.FileHandler(
            self.output_dir / f"drift_{model_name}_{datetime.now().strftime('%Y%m%d')}.log"
        )
        handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
        self.logger.addHandler(handler)
        
        # Calculate baseline statistics
        self.baseline_stats = self._calculate_statistics(baseline_data)
        
        # Thresholds
        self.thresholds = {
            "numeric_ks_pvalue": 0.05,  # p-value threshold for KS test
            "categorical_chi2_pvalue": 0.05,
            "drift_score": 0.3,  # Drift score threshold
            "overall_drift_threshold": 0.25  # Average drift threshold
        }
    
    # ========================================================================
    # BASELINE STATISTICS
    # ========================================================================
    
    def _calculate_statistics(self, df: pd.DataFrame) -> Dict:
        """Calculate baseline statistics from data"""
        stats_dict = {}
        
        for col in df.columns:
            if df[col].dtype in ['int64', 'float64']:
                stats_dict[col] = {
                    "type": "numeric",
                    "mean": float(df[col].mean()),
                    "std": float(df[col].std()),
                    "min": float(df[col].min()),
                    "max": float(df[col].max()),
                    "median": float(df[col].median()),
                    "q25": float(df[col].quantile(0.25)),
                    "q75": float(df[col].quantile(0.75))
                }
            else:
                # Categorical
                value_counts = df[col].value_counts(normalize=True)
                stats_dict[col] = {
                    "type": "categorical",
                    "distribution": value_counts.to_dict(),
                    "unique_count": int(df[col].nunique()),
                    "mode": str(df[col].mode()[0]) if len(df[col].mode()) > 0 else None
                }
        
        return stats_dict
    
    # ========================================================================
    # FEATURE DRIFT DETECTION
    # ========================================================================
    
    def detect_feature_drift(self, current_data: pd.DataFrame,
                            feature_list: Optional[List[str]] = None) -> List[FeatureDriftMetrics]:
        """
        Detect drift for each feature
        
        Args:
            current_data: New data to compare against baseline
            feature_list: Specific features to check (None = all)
            
        Returns:
            List of FeatureDriftMetrics
        """
        drift_metrics = []
        
        features = feature_list or current_data.columns.tolist()
        
        for feature in features:
            if feature not in self.baseline_stats or feature not in current_data.columns:
                continue
            
            baseline_stat = self.baseline_stats[feature]
            
            if baseline_stat["type"] == "numeric":
                metrics = self._detect_numeric_drift(feature, current_data)
            else:
                metrics = self._detect_categorical_drift(feature, current_data)
            
            drift_metrics.append(metrics)
            
            # Log drift detection
            if metrics.drift_detected:
                self.logger.warning(
                    f"Drift detected in {feature}: "
                    f"score={metrics.drift_score:.4f}, p-value={metrics.p_value:.4f}"
                )
        
        return drift_metrics
    
    def _detect_numeric_drift(self, feature: str, 
                             current_data: pd.DataFrame) -> FeatureDriftMetrics:
        """Detect drift in numeric feature using Kolmogorov-Smirnov test"""
        baseline_values = self.baseline_data[feature].dropna().values
        current_values = current_data[feature].dropna().values
        
        # KS test
        statistic, p_value = stats.ks_2samp(baseline_values, current_values)
        
        # Drift score based on statistical distance
        drift_score = min(statistic, 1.0)  # Normalize to [0, 1]
        drift_detected = p_value < self.thresholds["numeric_ks_pvalue"]
        
        baseline_stat = self.baseline_stats[feature]
        current_stat = {
            "mean": float(current_data[feature].mean()),
            "std": float(current_data[feature].std()),
            "min": float(current_data[feature].min()),
            "max": float(current_data[feature].max()),
            "median": float(current_data[feature].median())
        }
        
        return FeatureDriftMetrics(
            feature_name=feature,
            data_type="numeric",
            drift_detected=drift_detected,
            drift_score=drift_score,
            p_value=p_value,
            baseline_stats=baseline_stat,
            current_stats=current_stat,
            method="ks_test",
            threshold=self.thresholds["numeric_ks_pvalue"]
        )
    
    def _detect_categorical_drift(self, feature: str,
                                 current_data: pd.DataFrame) -> FeatureDriftMetrics:
        """Detect drift in categorical feature using Chi-square test"""
        baseline_values = self.baseline_data[feature].dropna()
        current_values = current_data[feature].dropna()
        
        # Get value counts
        baseline_counts = baseline_values.value_counts()
        current_counts = current_values.value_counts()
        
        # Align categories
        all_categories = set(baseline_counts.index) | set(current_counts.index)
        baseline_aligned = np.array([baseline_counts.get(cat, 0) for cat in all_categories])
        current_aligned = np.array([current_counts.get(cat, 0) for cat in all_categories])
        
        # Normalize to proportions
        baseline_props = baseline_aligned / baseline_aligned.sum()
        current_props = current_aligned / current_aligned.sum()
        
        # Chi-square test
        # Expected frequencies (average of baseline and current)
        expected = ((baseline_aligned + current_aligned) / 2.0)
        expected = np.where(expected == 0, 1, expected)  # Avoid division by zero
        
        chi2_stat = np.sum(((baseline_aligned - expected) ** 2) / expected)
        df = len(all_categories) - 1
        p_value = 1 - stats.chi2.cdf(chi2_stat, df) if df > 0 else 1.0
        
        # Drift score based on population stability index (PSI)
        psi = np.sum((current_props - baseline_props) * 
                     np.log((current_props + 1e-10) / (baseline_props + 1e-10)))
        drift_score = min(abs(psi), 1.0)  # Normalize
        
        drift_detected = p_value < self.thresholds["categorical_chi2_pvalue"]
        
        baseline_stat = self.baseline_stats[feature]
        current_stat = {
            "distribution": current_counts.to_dict(),
            "unique_count": int(current_values.nunique()),
            "mode": str(current_values.mode()[0]) if len(current_values.mode()) > 0 else None
        }
        
        return FeatureDriftMetrics(
            feature_name=feature,
            data_type="categorical",
            drift_detected=drift_detected,
            drift_score=drift_score,
            p_value=p_value,
            baseline_stats=baseline_stat,
            current_stats=current_stat,
            method="chi2_test",
            threshold=self.thresholds["categorical_chi2_pvalue"]
        )
    
    # ========================================================================
    # PREDICTION DRIFT DETECTION
    # ========================================================================
    
    def detect_prediction_drift(self, baseline_predictions: np.ndarray,
                               current_predictions: np.ndarray,
                               classes: List[str]) -> PredictionDriftMetrics:
        """
        Detect drift in model predictions
        
        Args:
            baseline_predictions: Predictions from training/baseline period
            current_predictions: Recent predictions
            classes: List of class names
            
        Returns:
            PredictionDriftMetrics
        """
        timestamp = datetime.now().isoformat()
        
        # Calculate distributions
        baseline_dist = {}
        current_dist = {}
        
        for cls in classes:
            baseline_dist[cls] = float((baseline_predictions == cls).sum() / len(baseline_predictions))
            current_dist[cls] = float((current_predictions == cls).sum() / len(current_predictions))
        
        # Calculate class shift
        class_shift = {
            cls: float(current_dist[cls] - baseline_dist[cls]) for cls in classes
        }
        
        # Chi-square test
        baseline_counts = np.array([
            (baseline_predictions == cls).sum() for cls in classes
        ])
        current_counts = np.array([
            (current_predictions == cls).sum() for cls in classes
        ])
        
        expected = ((baseline_counts + current_counts) / 2.0)
        expected = np.where(expected == 0, 1, expected)
        
        chi2_stat = float(np.sum(((baseline_counts - expected) ** 2) / expected))
        df = len(classes) - 1
        p_value = float(1 - stats.chi2.cdf(chi2_stat, df) if df > 0 else 1.0)
        
        # Drift score
        drift_score = min(chi2_stat / (len(classes) * 10), 1.0)  # Normalize
        drift_detected = p_value < self.thresholds["categorical_chi2_pvalue"]
        
        metrics = PredictionDriftMetrics(
            timestamp=timestamp,
            model_type=self.model_name,
            drift_detected=drift_detected,
            drift_score=drift_score,
            baseline_distribution=baseline_dist,
            current_distribution=current_dist,
            class_shift=class_shift,
            chi2_statistic=chi2_stat,
            p_value=p_value,
            method="chi2_test"
        )
        
        if drift_detected:
            self.logger.warning(
                f"Prediction drift detected: "
                f"score={drift_score:.4f}, p-value={p_value:.4f}"
            )
        
        return metrics
    
    # ========================================================================
    # COMPREHENSIVE DRIFT REPORT
    # ========================================================================
    
    def generate_drift_report(self, current_data: pd.DataFrame,
                             baseline_predictions: np.ndarray,
                             current_predictions: np.ndarray,
                             classes: List[str],
                             report_period: str = "daily") -> DataDriftReport:
        """
        Generate comprehensive drift report
        
        Args:
            current_data: Current period data
            baseline_predictions: Baseline predictions
            current_predictions: Current predictions
            classes: Class names
            report_period: "daily", "weekly", "monthly"
            
        Returns:
            DataDriftReport
        """
        timestamp = datetime.now().isoformat()
        
        # Detect feature drift
        feature_drift_metrics = self.detect_feature_drift(current_data)
        
        # Detect prediction drift
        pred_drift_metrics = self.detect_prediction_drift(
            baseline_predictions, current_predictions, classes
        )
        
        # Calculate overall drift score
        feature_drift_scores = [m.drift_score for m in feature_drift_metrics]
        overall_drift_score = float(np.mean(feature_drift_scores)) if feature_drift_scores else 0.0
        
        # Determine drift level
        if overall_drift_score > 0.75:
            drift_level = "high"
        elif overall_drift_score > 0.5:
            drift_level = "moderate"
        elif overall_drift_score > 0.25:
            drift_level = "low"
        else:
            drift_level = "none"
        
        # Generate alerts
        alerts = []
        drifted_features = [m for m in feature_drift_metrics if m.drift_detected]
        
        if drifted_features:
            alerts.append(
                f"Feature drift detected in {len(drifted_features)} features: "
                f"{', '.join([m.feature_name for m in drifted_features])}"
            )
        
        if pred_drift_metrics.drift_detected:
            alerts.append("Prediction distribution has shifted significantly")
        
        if drift_level in ["high", "moderate"]:
            alerts.append(f"Overall drift level is {drift_level} - consider retraining")
        
        # Generate recommendations
        recommendations = []
        if drift_level in ["high", "moderate"]:
            recommendations.append(
                "Schedule model retraining with recent data"
            )
            recommendations.append(
                "Investigate root causes of data distribution changes"
            )
        
        if drifted_features:
            recommendations.append(
                f"Monitor these features closely: {', '.join([m.feature_name for m in drifted_features[:5]])}"
            )
        
        recommendations.append("Increase monitoring frequency if drift is detected")
        
        report = DataDriftReport(
            timestamp=timestamp,
            report_period=report_period,
            total_features_analyzed=len(feature_drift_metrics),
            features_with_drift=len(drifted_features),
            feature_drift_metrics=feature_drift_metrics,
            prediction_drift_metrics=pred_drift_metrics,
            overall_drift_score=overall_drift_score,
            drift_level=drift_level,
            alerts=alerts,
            recommendations=recommendations
        )
        
        self.logger.info(
            f"Drift report generated. "
            f"Overall score: {overall_drift_score:.4f}, Level: {drift_level}"
        )
        
        return report
    
    # ========================================================================
    # REPORT PERSISTENCE
    # ========================================================================
    
    def save_drift_report(self, report: DataDriftReport,
                         filename: Optional[str] = None) -> str:
        """Save drift report to JSON file"""
        if filename is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"drift_report_{self.model_name}_{timestamp}.json"
        
        filepath = self.output_dir / filename
        with open(filepath, 'w') as f:
            json.dump(report.to_dict(), f, indent=2, default=str)
        
        self.logger.info(f"Drift report saved: {filepath}")
        return str(filepath)


# ============================================================================
# USAGE EXAMPLE
# ============================================================================

if __name__ == "__main__":
    print("Hospital ML System Drift Detection Module")
    print("=" * 50)
    
    # Create sample data
    baseline_data = pd.DataFrame({
        "age": np.random.normal(45, 15, 100),
        "billed_amount": np.random.uniform(5000, 50000, 100),
        "gender": np.random.choice(["M", "F"], 100)
    })
    
    current_data = pd.DataFrame({
        "age": np.random.normal(48, 18, 50),  # Slight shift
        "billed_amount": np.random.uniform(6000, 60000, 50),  # Slight shift
        "gender": np.random.choice(["M", "F"], 50)
    })
    
    # Create detector
    feature_schema = {
        "numeric": ["age", "billed_amount"],
        "categorical": ["gender"]
    }
    detector = DriftDetector("risk", baseline_data, feature_schema)
    
    # Detect feature drift
    drift_metrics = detector.detect_feature_drift(current_data)
    print("\nFeature Drift Metrics:")
    for metric in drift_metrics:
        print(f"  {metric.feature_name}: drift={metric.drift_detected}, score={metric.drift_score:.4f}")
    
    # Detect prediction drift
    baseline_preds = np.random.choice(["Low", "Medium", "High"], 100)
    current_preds = np.random.choice(["Low", "Medium", "High"], 50)
    
    pred_drift = detector.detect_prediction_drift(
        baseline_preds, current_preds, ["Low", "Medium", "High"]
    )
    print(f"\nPrediction Drift: {pred_drift.drift_detected}, score={pred_drift.drift_score:.4f}")
    
    # Generate report
    report = detector.generate_drift_report(
        current_data, baseline_preds, current_preds, ["Low", "Medium", "High"]
    )
    print(f"\nDrift Report: Level={report.drift_level}, Overall Score={report.overall_drift_score:.4f}")
