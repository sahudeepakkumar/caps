# Phase 6: Governance and Compliance Document
## Hospital Data Management System - IITM Capstone Project

**Completion Date:** 2026-06-14  
**Phase:** 6 - Monitoring, Drift Detection, and Governance  
**Status:** ✓ COMPLETE  

---

## Executive Summary

This document establishes governance, compliance, and risk management frameworks for the Hospital ML Analytics System. It provides hospital leadership with assurance that the AI system operates safely, reliably, and in accordance with regulatory requirements.

**Key Commitments:**
- Transparent documentation of model assumptions and limitations
- Regular monitoring for model drift and data quality degradation
- Comprehensive audit trails for all predictions and model changes
- Clear escalation procedures for system failures
- Evidence of alignment with healthcare compliance requirements (HIPAA, data protection)

---

## Table of Contents

1. [System Assumptions and Constraints](#section-1-system-assumptions)
2. [Model Limitations and Risk Profile](#section-2-model-limitations)
3. [Data Governance](#section-3-data-governance)
4. [Model Governance](#section-4-model-governance)
5. [Monitoring and Alert Framework](#section-5-monitoring)
6. [Drift Detection and Retraining](#section-6-drift-detection)
7. [Audit and Compliance Logging](#section-7-audit-logging)
8. [Incident Response and Rollback](#section-8-incident-response)
9. [User Access and Accountability](#section-9-user-access)
10. [Data Retention and Deletion Policy](#section-10-data-retention)
11. [Regulatory Compliance](#section-11-regulatory-compliance)
12. [System Limitations and Recommendations](#section-12-limitations)

---

<a name="section-1-system-assumptions"></a>
## 1. System Assumptions and Constraints

### 1.1 Data Assumptions

#### A. Training Data Characteristics (Phase 2)
- **Dataset:** Hospital operational data from three sources (patients, visits, billing)
- **Time Period:** Historical data spanning multiple months/years up to 2026-06-13
- **Sample Size:** 483 records with 37 features
- **Geographic Scope:** Multi-city hospital network (Delhi, Mumbai, Bangalore, etc.)
- **Data Quality:** 99.2% completeness, minimal duplicates

**Implication:** Models are calibrated for the hospital network's operational context. Performance may degrade when applied to different hospitals, healthcare systems, or geographic regions.

#### B. Feature Distribution Assumptions
All features were engineered assuming:
- **Numeric Features:** Approximately normal distributions (mean/std used for scaling)
- **Categorical Features:** Stable category sets with limited unseen values
- **Temporal Features:** Patterns consistent across seasons and fiscal years
- **No Concept Drift:** Feature relationships remain stable over time

**Implication:** If category distributions shift significantly or new categories emerge, model performance may degrade.

#### C. Patient Population
- **Demographics:** Mix of ages (1-90), both genders, chronic and non-chronic conditions
- **Visit Patterns:** Outpatient (OPD), Emergency (ER), and Intensive Care (ICU) visits
- **Insurance Coverage:** Multiple insurance providers with varying claim approval rates
- **Economic Status:** Patient population reflects hospital's service area

**Implication:** Model may not generalize well to significantly different patient populations (e.g., pediatric specialty hospital, geriatric-only facility).

### 1.2 Model Assumptions

#### A. Model A: Visit Risk Classification

**Business Model:**
- Risk is stratified into three categories: Low, Medium, High
- Risk categories are assumed to be **mutually exclusive** and **exhaustive**
- Risk is defined based on **visit characteristics** at prediction time

**Assumptions:**
1. Past visit history indicates future risk (temporal consistency)
2. Patient demographics are relatively stable
3. Chronic condition flags are accurate and current
4. Insurance provider risk profiles are stable
5. Billed amounts reflect clinical complexity

**Implication:** If patients move between cities, change insurance, or develop new chronic conditions between predictions, model accuracy may decrease.

#### B. Model B: Claim Outcome Prediction

**Business Model:**
- Claim outcomes are classified as: Paid, Pending, or Rejected
- Outcome depends on visit characteristics and insurance factors
- Outcome is **independent** of hospital's billing practices

**Assumptions:**
1. Insurance providers follow consistent claim approval policies
2. Rejected claims are primarily due to medical necessity/coverage disputes
3. Pending claims eventually resolve (not permanently stuck)
4. Claim processing timelines are stable
5. No systematic gaming or fraud

**Implication:** Model assumes insurance companies operate consistently and transparently. If claim processing changes (e.g., new pre-auth requirements), model performance may shift.

### 1.3 System Integration Assumptions

1. **Real-time Data Availability:** Input features are available in real-time or near real-time
2. **Batch Processing:** Daily batch predictions for trend analysis (not required for live decisions)
3. **API Availability:** FastAPI service remains available 99.5% of the time
4. **Model Artifacts:** Trained models, scalers, and encoders remain available in production
5. **Model Versioning:** Clear versioning allows tracking of model changes
6. **Prediction Logging:** All predictions are logged for audit trail

---

<a name="section-2-model-limitations"></a>
## 2. Model Limitations and Risk Profile

### 2.1 Model A: Visit Risk Classification

#### Limitations

| Limitation | Impact | Mitigation |
|-----------|--------|-----------|
| Class Imbalance | Model may be biased toward majority class | SMOTE applied; monitor per-class performance |
| Limited Features (18) | May miss important risk factors | Requires domain expert review for new features |
| 483 Training Records | Smaller dataset = higher variance | More data needed for robust generalization |
| Time-Window Training | Models trained on specific time period | Retrain monthly to capture seasonal patterns |
| No Real-time EHR Integration | Missing current clinical notes | Consider natural language processing in future |
| Historical Bias | Model reflects past hospital practices | Monitor for unintended bias by demographics |

#### Known Performance Gaps

**Per-Class Performance:**
- **Low Risk Class:** May have lower recall (misses some low-risk patients)
- **Medium Risk Class:** Highest confusion with Low and High classes
- **High Risk Class:** Generally well-identified (highest precision)

**Data Segment Performance:**
- Performance may vary by:
  - **Department:** ICU vs. General may have different accuracy
  - **Visit Type:** ER vs. OPD patterns differ
  - **Age Groups:** Model tuned on average patient; may vary by age
  - **City/Location:** Regional variation in healthcare practices

### 2.2 Model B: Claim Outcome Prediction

#### Limitations

| Limitation | Impact | Mitigation |
|-----------|--------|-----------|
| Class Imbalance (Paid > Rejected) | Model skewed toward "Paid" predictions | SMOTE applied; monitor false positive rate |
| Insurance Policy Changes | Claims policies change; model doesn't auto-adapt | Retrain within 2 weeks of policy changes |
| Missing Claim Details | Pre-authorization, medical necessity unknown | Requires manual review for rejected claims |
| Time Lag | Historical claim data may have lookback lag | Use near-term data for model evaluation |
| No Appeal Tracking | Model doesn't account for claim appeals | Consider appeal data in future retraining |

#### Known Performance Gaps

- **Claim Rejected:** Model may underestimate rejection risk (if trained on approved claims)
- **Claim Pending:** Harder to predict; depends on insurance processing speed
- **New Insurance Providers:** Unseen providers will trigger validation warnings

### 2.3 System Limitations

1. **Explainability:** Random Forest/Gradient Boosting models are less interpretable than linear models
   - **Mitigation:** Use SHAP/LIME for local explainability on critical decisions

2. **Real-time Constraints:** Batch predictions may lag by hours to days
   - **Mitigation:** Cache recent predictions; use fallback rules for urgent decisions

3. **Data Privacy:** Personal health information (PHI) in audit logs
   - **Mitigation:** Audit logs store only feature hashes, not raw patient data

4. **External Factors:** Model doesn't account for:
   - Emergency situations requiring immediate action (can't wait for AI prediction)
   - Clinical judgment that contradicts model prediction
   - Rare diseases or conditions not well-represented in training data

### 2.4 When NOT to Trust Model Predictions

| Scenario | Action |
|----------|--------|
| Patient demographics are unusual (e.g., age > 100) | Manual review required |
| New insurance provider not in training data | Use fallback rule; log as drift |
| Data validation fails (missing values, out-of-range) | Reject prediction; alert data team |
| Model performance drops below threshold | Use previous model version (rollback) |
| Drift alert triggered | Require manual confirmation before deployment |
| Patient has rare condition with no history | Clinical team override; update model with new case |

---

<a name="section-3-data-governance"></a>
## 3. Data Governance

### 3.1 Data Sources and Lineage

**Authoritative Sources:**
1. **Patients Table:** Master patient records (registration, demographics, insurance)
2. **Visits Table:** Hospital visit records (admission, discharge, department, visit type)
3. **Billing Table:** Claim and billing information (billed amount, approved amount, status)

**Data Pipeline:**
```
Patients + Visits + Billing
        ↓
    Merge (Left join on patient_id, visit_id)
        ↓
Feature Engineering (build_features.py)
        ↓
Model Training Dataset (model_table.csv / parquet)
        ↓
Model Predictions
        ↓
Audit Logs (predictions, drift, performance)
```

**Data Ownership:**
- **Patients Table:** Patient Services / HIM Department
- **Visits Table:** Clinical Operations
- **Billing Table:** Finance / Revenue Cycle Department
- **Model Dataset:** Data Science Team
- **Audit Logs:** Compliance / Risk Management

### 3.2 Data Quality Governance

**Minimum Data Quality Thresholds:**
- **Completeness:** ≥ 95% (no more than 5% missing values per feature)
- **Duplicates:** 0 duplicates allowed
- **Outliers:** <5% of records can be statistical outliers
- **Freshness:** Data updated at least weekly (daily preferred)
- **Consistency:** No contradictory values between tables

**Data Validation Checks (Automated - Daily):**
1. **Missing Values:** Alert if >5% missing for any feature
2. **Numeric Ranges:** Alert if out-of-range values detected
3. **Categorical Constraints:** Alert if unseen category values appear
4. **Duplicate Records:** Alert if duplicates detected
5. **Freshness:** Alert if data hasn't updated in 7 days

**Escalation Path for Data Quality Issues:**
```
Data Quality Alert
        ↓
Automated Validation Fails
        ↓
Alert sent to Data Quality Team (Slack/Email)
        ↓
Investigation (max 2 hours)
        ↓
Root Cause Found
        ↓
Predictions Suspended until Data Fixed
        ↓
Remediation + Revalidation
        ↓
Resume Predictions
```

### 3.3 Data Retention Policy

| Data Type | Retention Period | Storage Location | Deletion Method |
|-----------|-----------------|------------------|-----------------|
| Raw Patient/Visit/Billing Data | 7 years | Database | Secure deletion |
| Model Training Data | 3 years | Data Lake / Archive | Anonymization + deletion |
| Prediction Audit Logs | 5 years | Secure Log Storage | Cryptographic deletion |
| Performance Metrics | 2 years | Monitoring Dashboard | Archive after 2 years |
| Drift Detection Reports | 1 year | Report Archive | Secure deletion |

**Compliance Notes:**
- HIPAA requires minimum 6 years retention for certain records
- Hospital policy extends to 7 years for full audit trail
- All deletions require approval from Compliance Officer

### 3.4 Data Privacy and Protection

**Personally Identifiable Information (PII) Protection:**
- Patient names, SSN, email, phone numbers **never** logged in audit logs
- Only patient IDs (de-identified) and feature values used for model inputs
- Audit logs store **hash** of input data, not raw values
- All communication channels encrypted (HTTPS for APIs)

**Data Access Controls:**
- Only authorized personnel can access:
  - Raw patient data (patient services team)
  - Billing data (finance team)
  - Model predictions (clinical and administrative staff)
  - Audit logs (compliance team)
- Role-based access control (RBAC) enforced
- Access logged and auditable

---

<a name="section-4-model-governance"></a>
## 4. Model Governance

### 4.1 Model Versioning and Tracking

**Version Scheme:** `major.minor.patch` (e.g., 1.0.0)
- **Major:** Significant model architecture or retraining decision change
- **Minor:** Feature engineering changes or hyperparameter tuning
- **Patch:** Bug fixes or minor improvements

**Metadata Tracked per Version:**
```json
{
  "model_id": "risk_model_v1.0.0",
  "model_type": "risk",
  "version": "1.0.0",
  "created_date": "2026-06-13",
  "algorithm": "Random Forest",
  "feature_count": 18,
  "training_samples": 386,
  "test_accuracy": 0.85,
  "f1_score_weighted": 0.84,
  "baseline_performance": {
    "accuracy": 0.85,
    "precision": 0.85,
    "recall": 0.85
  },
  "deployed_date": "2026-06-14",
  "deployment_status": "active",
  "trained_on_data": "2026-06-13",
  "last_monitored": "2026-06-14"
}
```

### 4.2 Model Deployment and Rollback

**Deployment Process:**

1. **Model Development** (Data Science Team)
   - Train model on latest data
   - Evaluate performance on hold-out test set
   - Document performance metrics and assumptions

2. **Staging Testing** (QA/Testing)
   - Deploy to staging environment
   - Run integration tests with live data
   - Validate API responses and latency
   - Stress test (1000+ predictions/second)
   - Minimum 48-hour staging period

3. **Production Deployment** (Ops/DevOps)
   - Blue-Green deployment (no downtime)
   - Monitor prediction latency and errors
   - Validate predictions match expected ranges
   - Collect baseline performance metrics

4. **Monitoring & Rollback** (Ongoing)
   - Daily performance monitoring
   - If performance drops >5%, trigger rollback alert
   - Manual or automated rollback to previous version
   - Incident report and root cause analysis

**Rollback Criteria (Automatic Alert):**
- Accuracy drops below 80%
- F1-score drops below 0.80
- >10% prediction errors in 1 hour
- Data validation failures for >5% of requests
- Prediction drift score > 0.5

### 4.3 Model Retraining Strategy

**Retraining Triggers:**
1. **Scheduled Retraining** (Monthly - 1st of each month)
   - Collect data from previous month
   - Retrain model on accumulated data
   - Evaluate performance improvement
   - Deploy if improved; otherwise keep current version

2. **Drift-Triggered Retraining** (As needed)
   - Feature drift detected in >3 features
   - Prediction drift detected (distribution shift)
   - Data quality degradation
   - Manual trigger by ML team

3. **Performance-Triggered Retraining**
   - Accuracy drops >5%
   - F1-score drops >0.05
   - Per-class performance imbalance

**Retraining Process:**
```
Data Collection (30 days of new data)
        ↓
Feature Engineering
        ↓
Train/Test Split (80/20)
        ↓
Model Training (Multiple algorithms)
        ↓
Hyperparameter Tuning (GridSearchCV)
        ↓
Evaluate Performance
        ↓
Performance > Current Version?
  Yes: Deploy (Blue-Green)
  No: Keep Current Version
```

**Retraining Cadence:**
- **Risk Model:** Monthly scheduled + on-demand for drift
- **Claim Model:** Monthly scheduled + on-demand for drift
- **Emergency Retraining:** <4 hours if critical issue detected

---

<a name="section-5-monitoring"></a>
## 5. Monitoring and Alert Framework

### 5.1 Real-time Monitoring

**Metrics Monitored (Every Prediction):**

| Metric | Target | Warning | Critical |
|--------|--------|---------|----------|
| API Response Time | <200ms | >500ms | >1000ms |
| Prediction Success Rate | >99% | <98% | <95% |
| Data Validation Pass Rate | >95% | <90% | <85% |
| Model Availability | 99.9% uptime | 99.0% | 98.0% |

**Daily Performance Monitoring:**

| Metric | Target | Alert Threshold |
|--------|--------|-----------------|
| Accuracy | >85% | <80% |
| Precision (weighted) | >85% | <80% |
| Recall (weighted) | >85% | <80% |
| F1-Score (weighted) | >85% | <80% |

### 5.2 Data Quality Monitoring

**Daily Data Quality Checks:**
```python
# Validation Script runs daily at 00:30 UTC

1. Check Missing Values
   - Alert if any feature >5% missing
   - Log percentage of missing values per feature

2. Check Numeric Ranges
   - Age: [0, 120]
   - Billed Amount: [0, 500,000]
   - Revenue Ratio: [0, 1.0]
   - Alert if out-of-range

3. Check Categorical Constraints
   - Valid cities: [Delhi, Mumbai, Bangalore, ...]
   - Valid departments: [Cardiology, ER, General, ...]
   - Alert if unseen category

4. Check Duplicates
   - Alert if duplicate records found

5. Calculate Quality Score
   - completeness_pct = (total_cells - missing_cells) / total_cells
   - Alert if <95%

6. Generate Report
   - Save to monitoring_logs/quality_metrics_*.json
   - Email to Data Quality Team if issues found
```

### 5.3 Alert Framework

**Alert Severity Levels:**

**CRITICAL (Immediate Action):**
- Model API is down (>5 minutes)
- Prediction accuracy <80%
- >50% of predictions fail validation
- Data completeness <85%
- Drift score >0.7 (high drift)

**WARNING (Within 2 Hours):**
- API response time >500ms
- Accuracy 80-85%
- Data completeness 85-95%
- Moderate drift detected
- Prediction success rate 95-98%

**INFO (Track for Trending):**
- Minor data quality issues
- Performance trending down
- Low drift detected
- Routine monitoring reports

**Alert Routing:**
```
CRITICAL  → Ops Team + ML Team + Manager (SMS + Email)
WARNING   → ML Team + Data Team (Email + Slack)
INFO      → Dashboard Only (Email Summary Daily)
```

### 5.4 Health Dashboard

**Real-time Dashboard Displays:**
- Prediction volume (per hour, rolling 24h)
- Success rate (%)
- Average response time (ms)
- Data quality score (%)
- Drift score (0-1)
- Model version deployed
- Last retraining date
- Active alerts count

**Historical Dashboard:**
- Accuracy trend (daily)
- F1-score trend (daily)
- Data quality trend (daily)
- Drift trend (weekly)
- Prediction distribution (per class, daily)

---

<a name="section-6-drift-detection"></a>
## 6. Drift Detection and Retraining

### 6.1 Feature Drift Detection

**Method:** Kolmogorov-Smirnov (KS) Test for Numeric Features

**Process:**
1. Calculate KS statistic comparing baseline vs. current period distributions
2. If p-value < 0.05, flag as drift detected
3. Calculate drift score (0-1): normalized KS statistic
4. Track drift score over time

**Numeric Features Monitored:**
```
- age
- length_of_stay_hours
- visit_frequency
- avg_los_per_patient
- days_since_registration
- billed_amount
- revenue_realization_ratio
- provider_rejection_rate
```

**Categorical Features Monitored (Chi-Square Test):**
```
- gender
- city
- visit_type
- department
- insurance_provider
- visit_month
- visit_quarter
- visit_day_of_week
```

**Drift Score Thresholds:**
- 0.0-0.2: No drift
- 0.2-0.4: Low drift (monitor)
- 0.4-0.6: Moderate drift (schedule retraining)
- 0.6-1.0: High drift (retrain immediately)

### 6.2 Prediction Drift Detection

**Method:** Chi-Square Test on Prediction Distributions

**Process:**
1. Compare baseline class distribution (training period) vs. current period
2. Calculate chi-square statistic
3. If p-value < 0.05, flag as prediction drift
4. Calculate drift score based on chi-square value

**Interpretation:**
- **Baseline Distribution:** 40% Low, 35% Medium, 25% High
- **Current Distribution:** 20% Low, 40% Medium, 40% High
- **Interpretation:** Model predictions shifting toward High-risk classification

**Action Triggers:**
- If prediction distribution shift > 15% for any class → Alert
- If prediction drift score > 0.5 → Retrain
- If combined feature + prediction drift → Urgent retrain

### 6.3 Drift Detection Baseline

**Baseline Established from Training Data:**

For each feature, baseline statistics calculated from 386 training records:

```json
{
  "feature": "age",
  "type": "numeric",
  "baseline_stats": {
    "mean": 45.2,
    "std": 18.5,
    "min": 5,
    "max": 88,
    "median": 43.0,
    "q25": 28.0,
    "q75": 62.0
  },
  "drift_threshold_ks_pvalue": 0.05
}
```

**Baseline Prediction Distribution:**
```json
{
  "model": "risk",
  "baseline_predictions": {
    "Low": 0.40,
    "Medium": 0.35,
    "High": 0.25
  },
  "drift_threshold_chi2_pvalue": 0.05
}
```

**Baseline Update Schedule:**
- Updated monthly with new training data
- Updated manually if retraining occurs
- Versioned for audit trail

---

<a name="section-7-audit-logging"></a>
## 7. Audit and Compliance Logging

### 7.1 Prediction Audit Logs

**Every prediction is logged with:**

| Field | Example | Purpose |
|-------|---------|---------|
| log_id | 550e8400-e29b-41d4-a716-446655440000 | Unique identifier |
| timestamp | 2026-06-14T10:30:45.123456Z | When prediction occurred |
| model_type | "risk" | Which model used |
| model_version | "1.0.0" | Version deployed |
| input_hash | 8f14e45fceea167a5a36dedd4bea2543 | Verify input integrity |
| input_summary | {age: 45, city: "Delhi"} | Key features (no PII) |
| prediction | "High" | Predicted class |
| prediction_confidence | 0.92 | Model confidence score |
| user_id | "dr_smith" | Who requested prediction |
| request_id | 3fa85f64-5717-4562-b3fc-2c963f66afa6 | Trace request |
| status | "success" | Success/failed/validation_failed |
| processing_time_ms | 145 | How long prediction took |
| data_quality_score | 0.95 | Data quality assessment |

**Audit Log Retention:**
- Store for **5 years** (HIPAA compliance)
- Encrypted storage in secure logs directory
- Immutable once written
- No modification without explicit audit trail

**Audit Log Access:**
- Only accessible by authorized compliance/audit team
- All access logged and audited
- Cannot be deleted (only archived)

### 7.2 Model Operation Logs

**Logged Events:**

**Deployment:**
```json
{
  "operation": "deployment",
  "model_type": "risk",
  "model_version_old": "1.0.0",
  "model_version_new": "1.0.1",
  "triggered_by": "manual",
  "user_id": "ml_engineer_john",
  "status": "success",
  "timestamp": "2026-06-14T08:00:00Z",
  "details": {
    "accuracy_improvement": "+2.5%",
    "staging_hours": 48,
    "rollback_procedure": "automatic"
  }
}
```

**Retraining:**
```json
{
  "operation": "retraining",
  "model_type": "risk",
  "model_version_new": "1.0.1",
  "triggered_by": "drift_alert",
  "status": "success",
  "timestamp": "2026-06-14T12:00:00Z",
  "details": {
    "training_records": 450,
    "drift_score": 0.62,
    "features_engineered": 18,
    "training_time_minutes": 12
  }
}
```

**Rollback:**
```json
{
  "operation": "rollback",
  "model_type": "risk",
  "model_version_old": "1.0.1",
  "model_version_new": "1.0.0",
  "triggered_by": "accuracy_drop",
  "user_id": "ops_team",
  "status": "success",
  "timestamp": "2026-06-14T14:30:00Z",
  "details": {
    "reason": "Accuracy dropped to 78%",
    "automatic_trigger": true,
    "confirmation_required": false
  }
}
```

### 7.3 Data Operation Logs

**Logged Data Operations:**

**Ingestion:**
```json
{
  "operation": "ingestion",
  "data_source": "patients_table",
  "record_count": 1250,
  "status": "success",
  "timestamp": "2026-06-14T00:30:00Z",
  "quality_metrics": {
    "completeness_pct": 98.5,
    "duplicate_count": 0,
    "validation_passed": true
  }
}
```

**Feature Engineering:**
```json
{
  "operation": "transformation",
  "data_source": "raw_visits_table",
  "record_count": 1500,
  "status": "success",
  "timestamp": "2026-06-14T01:00:00Z",
  "details": {
    "features_created": 18,
    "features_with_errors": 0,
    "output_file": "model_table_2026-06-14.parquet"
  }
}
```

### 7.4 Audit Summary Generation

**Weekly Audit Summary Report (Every Monday):**
```
Weekly Audit Report
Date: 2026-06-10 to 2026-06-14

Predictions:
  - Total: 15,432
  - Successful: 15,289 (99.1%)
  - Failed: 143 (0.9%)
  - Average Confidence: 0.89

Model Operations:
  - Deployments: 0
  - Retrainings: 1
  - Rollbacks: 0
  - Updates: 0

Data Quality:
  - Avg Completeness: 97.8%
  - Data Validation Passes: 100%
  - Duplicates Found: 0
  - Quality Alerts: 1 (Minor issue in visit_date field)

Drift Detection:
  - Features with Drift: 0
  - Prediction Drift Events: 0
  - Retraining Recommended: No

Compliance:
  - Violations: 0
  - Access Policy Breaches: 0
  - Unauthorized Access Attempts: 0
  - Data Retention Violations: 0

Incidents:
  - Critical: 0
  - Warnings: 0
  - Info: 2

Next Steps:
  - Continue routine monitoring
  - Investigate 1 minor data quality issue
  - Schedule monthly retraining for 2026-07-01
```

---

<a name="section-8-incident-response"></a>
## 8. Incident Response and Rollback

### 8.1 Incident Severity Classification

| Severity | Description | Response Time | Escalation |
|----------|-----------|---------------|-----------|
| CRITICAL | System down, accuracy <80%, widespread errors | <15 min | CEO, CMO, CFO |
| HIGH | Significant performance degradation, data quality issue | <1 hour | Department Head, CIO |
| MEDIUM | Minor performance drop, localized data issue | <4 hours | Team Lead |
| LOW | Informational, monitoring alert | <24 hours | On-demand |

### 8.2 Incident Response Procedures

**CRITICAL Incident (System Down):**

```
00:00 - Alert triggered (Accuracy < 80%)
        ↓
00:05 - Ops team paged automatically
        ↓
00:10 - Incident commander assigned
        ↓
00:15 - Root cause analysis begins
        
        Option A: Data Quality Issue
          → Halt predictions
          → Investigate source data
          → Fix data issue
          → Resume predictions
        
        Option B: Model Degradation
          → Trigger automatic rollback to previous version
          → Verify predictions working
          → Resume service
          → Post-analysis scheduled
        
        Option C: API/Infrastructure Failure
          → Failover to backup instance
          → Restore from snapshot
          → Resume service
          → Infrastructure team investigates
        
01:00 - Service restored
        ↓
04:00 - Incident report completed
        ↓
24:00 - Root cause analysis + preventive measures
```

### 8.3 Automatic Rollback Triggers

```python
# Automatic rollback happens if:
if accuracy < 0.80:
    trigger_rollback("Critical accuracy drop")
    
elif f1_score_weighted < 0.80:
    trigger_rollback("F1 score dropped")
    
elif prediction_error_rate > 0.10:  # >10% errors in 1 hour
    trigger_rollback("High error rate")
    
elif data_validation_failure_rate > 0.05:  # >5% validation failures
    trigger_rollback("Data quality degradation")
    
elif drift_score > 0.50:
    alert_team("High drift detected - manual review required")
    # Note: Drift doesn't auto-rollback, requires manual confirmation
```

### 8.4 Rollback Procedure

1. **Automatic Detection:** System detects performance degradation
2. **Alert Notification:** Ops and ML teams notified immediately
3. **Rollback Trigger:** System switches to previous stable model version
4. **Verification:** Health checks confirm service restored
5. **Notification:** Stakeholders informed of rollback
6. **Investigation:** ML team investigates root cause
7. **Resolution:** Issue fixed; new version tested before redeployment

**Rollback Time:** <5 minutes from alert to service restoration
**Data Loss:** None (predictions already logged)
**Service Interruption:** None (blue-green deployment with no downtime)

---

<a name="section-9-user-access"></a>
## 9. User Access and Accountability

### 9.1 Role-Based Access Control (RBAC)

| Role | Access | Permissions |
|------|--------|-------------|
| Clinical Staff | Risk Model predictions | View predictions only; no model changes |
| Finance Staff | Claim Model predictions | View predictions; override flag disputed claims |
| ML Engineer | All models + code | Deploy, retrain, modify models |
| Data Analyst | All data + logs | View data and audit logs; no deletion |
| Operations | System health | Monitor uptime, trigger rollbacks |
| Compliance Officer | Audit logs | View audit logs; generate compliance reports |
| System Admin | Full system | Full access; user management; disaster recovery |

### 9.2 Access Logging

**Every access to sensitive data is logged:**
```json
{
  "timestamp": "2026-06-14T10:30:45Z",
  "user_id": "dr_smith",
  "role": "clinical_staff",
  "action": "view_prediction",
  "resource": "prediction_request_123",
  "result": "success",
  "ip_address": "192.168.1.100",
  "session_id": "sess_abc123"
}
```

**Access Log Retention:**
- Store for 3 years
- Immutable once written
- Encrypted storage
- Quarterly audit of access patterns

### 9.3 User Accountability

**For Predictions:**
- Each prediction logged with user_id who requested it
- If ML model makes incorrect prediction, user is notified to provide feedback
- Override flags when clinical judgment differs from model

**For Model Changes:**
- Each deployment/rollback logged with user who triggered it
- Each retrain logged with reason and metrics
- Authorization required for production deployments

**Incident Accountability:**
- Incident commander assigned
- Root cause documented
- Preventive measures assigned to team lead
- Follow-up tracking until resolved

---

<a name="section-10-data-retention"></a>
## 10. Data Retention and Deletion Policy

### 10.1 Data Retention Schedule

| Data Category | Retention Period | Rationale | Deletion Method |
|---------------|-----------------|-----------|-----------------|
| Raw Patient Data | 7 years | HIPAA + Hospital policy | Secure deletion (DOD 5220.22-M) |
| Raw Billing Data | 7 years | Tax + Regulatory | Secure deletion |
| Training Datasets | 3 years | Model audit trail | Anonymization + deletion |
| Prediction Audit Logs | 5 years | Compliance audit trail | Cryptographic deletion |
| Performance Metrics | 2 years | Historical trending | Deletion or archival |
| Drift Reports | 1 year | Monitoring history | Deletion |
| Model Artifacts | During deployment | For rollback purposes | Deletion 2 years after version retired |

### 10.2 Deletion Process

**Request for Deletion:**
1. Compliance Officer initiates deletion request
2. Specify data category and date range
3. Review for regulatory holds (litigation, audit)
4. Obtain approval from Data Governance Committee

**Deletion Execution:**
1. Backup created (before deletion)
2. Data deleted using secure method
3. Deletion log created (what was deleted, when, by whom)
4. Verification that data is unrecoverable
5. Deletion certificate provided to requester

**Deletion Certificate Example:**
```
Certificate of Data Deletion

Data Category: Prediction Audit Logs
Period: 2020-01-01 to 2020-12-31
Records Deleted: 45,382
Deletion Method: Cryptographic Deletion
Deletion Date: 2023-01-15
Performed By: IT Security Team
Verified By: Compliance Officer

This certifies that the above data has been securely deleted
and is unrecoverable.
```

---

<a name="section-11-regulatory-compliance"></a>
## 11. Regulatory Compliance

### 11.1 Healthcare Compliance Requirements

**HIPAA Compliance:**
- ✅ Patient PII not stored in prediction logs
- ✅ Access controls and audit logs maintained
- ✅ Data encrypted in transit (HTTPS/TLS)
- ✅ Data encrypted at rest
- ✅ Breach notification procedures documented
- ✅ Business Associate Agreements in place
- ✅ Data retention policies documented

**FDA Guidance for AI/ML (21 CFR Part 11):**
- ✅ Model documentation and version control
- ✅ Validation and verification procedures
- ✅ Audit trails for predictions
- ✅ Rollback and contingency procedures
- ✅ User training and access controls
- ⚠️ Clinical validation studies recommended (future phase)

**State Privacy Laws (CCPA, state-specific):**
- ✅ Patient right to access their predictions
- ✅ Patient right to deletion of their data
- ✅ Patient right to know if AI decision affects them
- ✅ Opt-out mechanisms available
- ✅ Data processing agreements in place

### 11.2 Compliance Checklist

**Quarterly Compliance Review:**
- [ ] All predictions logged with audit trail
- [ ] No compliance violations detected
- [ ] Access logs reviewed for unauthorized access
- [ ] Data retention policies followed
- [ ] Breach notification procedures tested
- [ ] Staff training current (annual)
- [ ] Security patches applied
- [ ] Backup/disaster recovery tested
- [ ] Third-party vendors assessed
- [ ] Incident response procedures tested

**Annual Compliance Audit:**
- Independent third-party audit
- All systems tested for compliance
- Audit report provided to hospital leadership
- Findings and remediation tracked

---

<a name="section-12-limitations"></a>
## 12. System Limitations and Recommendations

### 12.1 Current Limitations

1. **Explainability:** Models use Random Forest/Gradient Boosting (black box)
   - **Mitigation:** Use SHAP/LIME for local explanations in future
   - **Recommendation:** Implement LIME for top 10% high-impact predictions

2. **Real-time Data:** Batch processing with hourly/daily latency
   - **Mitigation:** Use fallback rules for urgent decisions
   - **Recommendation:** Implement streaming data pipeline for real-time features

3. **Unseen Categories:** New insurance providers, departments, cities cause errors
   - **Mitigation:** Validation warnings; manual review required
   - **Recommendation:** Implement handling for new categories (smoothing, default classes)

4. **Limited Feature Set (18 features):** Missing clinical notes, lab values, medications
   - **Mitigation:** Periodic retraining with new features
   - **Recommendation:** Integrate EHR data; extract clinical notes with NLP

5. **Historical Bias:** Training data reflects past hospital practices and biases
   - **Mitigation:** Monitor predictions by demographic groups; retrain as practices evolve
   - **Recommendation:** Conduct fairness audit; implement debiasing techniques

6. **Seasonal Patterns:** Model trained on limited time period; may not handle all seasons
   - **Mitigation:** Retrain monthly to capture seasonal patterns
   - **Recommendation:** Implement seasonal adjustments or separate seasonal models

### 12.2 Future Enhancements

**Short-term (3-6 months):**
1. Implement SHAP explainability for model predictions
2. Add clinical notes text processing (NLP)
3. Implement fairness metrics and bias detection
4. Real-time streaming data pipeline for urgent predictions

**Medium-term (6-12 months):**
1. Integrate laboratory test results as features
2. Add medication and treatment history
3. Implement ensemble models (combine risk + claim predictions)
4. Develop patient-facing explanation dashboard

**Long-term (1-2 years):**
1. Personalized risk models (per patient type)
2. Uncertainty quantification (prediction confidence intervals)
3. Causal inference models (why predictions change)
4. Real-time clinical decision support integration

### 12.3 Recommendations for Hospital Leadership

**Governance:**
- Establish AI Governance Committee (quarterly meetings)
- Assign Chief AI Officer or similar responsible party
- Implement AI procurement standards for all new AI/ML systems

**Implementation:**
- Staff training on responsible AI use
- Clinical workflow integration (predictions in EHR, not separate)
- Fallback procedures for system failures documented and tested

**Monitoring:**
- Quarterly reports on model performance and compliance
- Annual audit of AI systems
- Public transparency report (aggregate metrics, no individual predictions)

**Budget Allocation:**
- Estimated annual cost for maintenance and monitoring: $150K-250K
- Estimated cost for enhancements: $200K-300K/year
- ROI tracking: Monitor claim approval rates, reduce rejections, faster processing

---

## Conclusion

This governance framework ensures that the Hospital ML Analytics System operates safely, reliably, and in compliance with healthcare regulations. Through comprehensive monitoring, drift detection, and audit logging, the hospital can trust the AI system to enhance decision-making for administrators, clinicians, and finance teams.

**Key Takeaways:**
1. ✅ Models have documented assumptions, limitations, and performance baselines
2. ✅ Real-time monitoring detects performance degradation and data quality issues
3. ✅ Drift detection triggers retraining before predictions become unreliable
4. ✅ Audit logs provide complete traceability for all predictions and model changes
5. ✅ Incident response and rollback procedures ensure business continuity
6. ✅ HIPAA and regulatory requirements addressed
7. ✅ Clear escalation paths and accountability measures in place

**Next Steps:**
1. Obtain hospital leadership approval for this governance framework
2. Implement monitoring dashboards and alerting
3. Train staff on AI system use and governance requirements
4. Establish AI Governance Committee
5. Schedule quarterly compliance reviews

---

**Document Version:** 1.0  
**Last Updated:** 2026-06-14  
**Next Review Date:** 2026-09-14 (Quarterly)  
**Approved By:** [Pending Hospital Leadership Signature]
