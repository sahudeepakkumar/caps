"""
Phase 6: Monitoring Module for Hospital ML System
Comprehensive monitoring, data validation, and performance tracking

Created: 2026-06-14
Version: 1.0

This module provides:
- Real-time data validation (missing values, numeric ranges, unseen categories)
- Performance tracking (accuracy, precision, recall, F1)
- Data quality metrics
- Alert generation for anomalies
"""

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Tuple, Optional, Any
from dataclasses import dataclass, asdict

import numpy as np
import pandas as pd
from scipy import stats


# ============================================================================
# DATA STRUCTURES
# ============================================================================

@dataclass
class DataValidationReport:
    """Report for data validation results"""
    timestamp: str
    is_valid: bool
    total_records: int
    valid_records: int
    missing_value_issues: Dict[str, int]
    numeric_range_issues: Dict[str, List[float]]
    categorical_issues: Dict[str, List[str]]
    validation_passed: bool
    alerts: List[str]
    warnings: List[str]
    
    def to_dict(self) -> Dict:
        return asdict(self)


@dataclass
class PerformanceMetrics:
    """Performance metrics for model"""
    timestamp: str
    model_type: str  # "risk" or "claim"
    accuracy: float
    precision_weighted: float
    recall_weighted: float
    f1_weighted: float
    support: int
    per_class_metrics: Dict[str, Dict[str, float]]
    confusion_matrix: List[List[int]]
    
    def to_dict(self) -> Dict:
        return asdict(self)


@dataclass
class DataQualityMetrics:
    """Data quality metrics"""
    timestamp: str
    completeness_pct: float
    duplicate_count: int
    missing_value_pct: Dict[str, float]
    numeric_outliers: Dict[str, int]
    categorical_cardinality: Dict[str, int]
    
    def to_dict(self) -> Dict:
        return asdict(self)


# ============================================================================
# MONITORING CLASS
# ============================================================================

class ModelMonitor:
    """
    Comprehensive monitoring system for hospital ML models
    """
    
    def __init__(self, model_name: str, feature_schema: Dict, 
                 output_dir: str = "monitoring_logs"):
        """
        Initialize monitor
        
        Args:
            model_name: "risk" or "claim"
            feature_schema: Dictionary with feature definitions and constraints
            output_dir: Directory to store monitoring logs
        """
        self.model_name = model_name
        self.feature_schema = feature_schema
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(exist_ok=True)
        
        # Setup logging
        self.logger = self._setup_logger()
        
        # Thresholds for alerts
        self.thresholds = {
            "missing_value_pct": 5.0,  # Alert if > 5% missing
            "duplicate_rows": 0,  # Alert if any duplicates
            "accuracy_drop": 0.05,  # Alert if accuracy drops > 5%
            "data_completeness": 95.0,  # Alert if < 95% complete
        }
        
    def _setup_logger(self) -> logging.Logger:
        """Setup logging for monitoring"""
        logger = logging.getLogger(f"monitor_{self.model_name}")
        logger.setLevel(logging.INFO)
        
        handler = logging.FileHandler(
            self.output_dir / f"monitor_{self.model_name}_{datetime.now().strftime('%Y%m%d')}.log"
        )
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        
        return logger
    
    # ========================================================================
    # DATA VALIDATION
    # ========================================================================
    
    def validate_data(self, df: pd.DataFrame) -> DataValidationReport:
        """
        Comprehensive data validation
        
        Args:
            df: Input dataframe
            
        Returns:
            DataValidationReport with validation results
        """
        timestamp = datetime.now().isoformat()
        alerts = []
        warnings = []
        
        # 1. Check missing values
        missing_value_issues = self._check_missing_values(df)
        if missing_value_issues:
            alerts.append(f"Missing values detected: {missing_value_issues}")
        
        # 2. Check numeric ranges
        numeric_range_issues = self._check_numeric_ranges(df)
        if numeric_range_issues:
            alerts.append(f"Numeric range violations: {numeric_range_issues}")
        
        # 3. Check categorical values (unseen categories)
        categorical_issues = self._check_categorical_values(df)
        if categorical_issues:
            warnings.append(f"Unseen categorical values: {categorical_issues}")
        
        # 4. Check for duplicates
        duplicates = df.duplicated().sum()
        if duplicates > 0:
            alerts.append(f"Duplicate rows detected: {duplicates}")
        
        # 5. Calculate overall validity
        valid_records = len(df) - duplicates
        is_valid = len(alerts) == 0
        
        report = DataValidationReport(
            timestamp=timestamp,
            is_valid=is_valid,
            total_records=len(df),
            valid_records=valid_records,
            missing_value_issues=missing_value_issues,
            numeric_range_issues=numeric_range_issues,
            categorical_issues=categorical_issues,
            validation_passed=is_valid,
            alerts=alerts,
            warnings=warnings
        )
        
        # Log results
        log_level = logging.ERROR if alerts else logging.INFO
        self.logger.log(
            log_level,
            f"Data validation completed. Valid: {is_valid}. "
            f"Records: {len(df)}. Alerts: {len(alerts)}"
        )
        
        return report
    
    def _check_missing_values(self, df: pd.DataFrame) -> Dict[str, int]:
        """Check for missing values in data"""
        issues = {}
        for col in df.columns:
            missing_count = df[col].isna().sum()
            missing_pct = (missing_count / len(df)) * 100
            
            if missing_count > 0:
                if missing_pct > self.thresholds["missing_value_pct"]:
                    issues[col] = f"{missing_count} ({missing_pct:.2f}%)"
        
        return issues
    
    def _check_numeric_ranges(self, df: pd.DataFrame) -> Dict[str, List[float]]:
        """Check if numeric values are within expected ranges"""
        issues = {}
        
        numeric_features = self.feature_schema.get("numeric_features", {})
        for feature, constraints in numeric_features.items():
            if feature not in df.columns:
                continue
            
            min_val = constraints.get("min")
            max_val = constraints.get("max")
            
            if min_val is not None or max_val is not None:
                out_of_range = df[
                    (df[feature] < min_val) | (df[feature] > max_val)
                ][feature].tolist()
                
                if out_of_range:
                    issues[feature] = out_of_range[:10]  # First 10 values
        
        return issues
    
    def _check_categorical_values(self, df: pd.DataFrame) -> Dict[str, List[str]]:
        """Check for unseen categorical values"""
        issues = {}
        
        categorical_features = self.feature_schema.get("categorical_features", {})
        for feature, allowed_values in categorical_features.items():
            if feature not in df.columns:
                continue
            
            unique_vals = set(df[feature].dropna().unique())
            allowed_set = set(allowed_values)
            
            unseen = unique_vals - allowed_set
            if unseen:
                issues[feature] = list(unseen)[:5]  # First 5 unseen values
        
        return issues
    
    # ========================================================================
    # PERFORMANCE TRACKING
    # ========================================================================
    
    def calculate_performance_metrics(
        self, 
        y_true: np.ndarray, 
        y_pred: np.ndarray,
        classes: List[str]
    ) -> PerformanceMetrics:
        """
        Calculate detailed performance metrics
        
        Args:
            y_true: True labels
            y_pred: Predicted labels
            classes: List of class names
            
        Returns:
            PerformanceMetrics object
        """
        from sklearn.metrics import (
            accuracy_score, precision_score, recall_score, f1_score,
            confusion_matrix, classification_report
        )
        
        timestamp = datetime.now().isoformat()
        
        # Overall metrics
        accuracy = accuracy_score(y_true, y_pred)
        precision = precision_score(y_true, y_pred, average='weighted', zero_division=0)
        recall = recall_score(y_true, y_pred, average='weighted', zero_division=0)
        f1 = f1_score(y_true, y_pred, average='weighted', zero_division=0)
        
        # Per-class metrics
        report = classification_report(y_true, y_pred, output_dict=True, zero_division=0)
        per_class_metrics = {}
        for class_name in classes:
            if str(class_name) in report:
                per_class_metrics[class_name] = report[str(class_name)]
        
        # Confusion matrix
        cm = confusion_matrix(y_true, y_pred, labels=classes)
        
        metrics = PerformanceMetrics(
            timestamp=timestamp,
            model_type=self.model_name,
            accuracy=float(accuracy),
            precision_weighted=float(precision),
            recall_weighted=float(recall),
            f1_weighted=float(f1),
            support=len(y_true),
            per_class_metrics=per_class_metrics,
            confusion_matrix=cm.tolist()
        )
        
        self.logger.info(
            f"Performance metrics calculated. "
            f"Accuracy: {accuracy:.4f}, F1: {f1:.4f}"
        )
        
        return metrics
    
    # ========================================================================
    # DATA QUALITY ASSESSMENT
    # ========================================================================
    
    def assess_data_quality(self, df: pd.DataFrame) -> DataQualityMetrics:
        """
        Comprehensive data quality assessment
        
        Args:
            df: Input dataframe
            
        Returns:
            DataQualityMetrics object
        """
        timestamp = datetime.now().isoformat()
        
        # Completeness
        total_cells = df.shape[0] * df.shape[1]
        missing_cells = df.isna().sum().sum()
        completeness_pct = ((total_cells - missing_cells) / total_cells) * 100
        
        # Missing values per column
        missing_per_column = {}
        for col in df.columns:
            missing_pct = (df[col].isna().sum() / len(df)) * 100
            if missing_pct > 0:
                missing_per_column[col] = missing_pct
        
        # Duplicates
        duplicates = df.duplicated().sum()
        
        # Numeric outliers (using IQR method)
        numeric_outliers = {}
        numeric_cols = df.select_dtypes(include=[np.number]).columns
        for col in numeric_cols:
            Q1 = df[col].quantile(0.25)
            Q3 = df[col].quantile(0.75)
            IQR = Q3 - Q1
            outliers = ((df[col] < (Q1 - 1.5 * IQR)) | 
                       (df[col] > (Q3 + 1.5 * IQR))).sum()
            if outliers > 0:
                numeric_outliers[col] = outliers
        
        # Categorical cardinality
        categorical_cols = df.select_dtypes(include=['object']).columns
        categorical_cardinality = {
            col: df[col].nunique() for col in categorical_cols
        }
        
        metrics = DataQualityMetrics(
            timestamp=timestamp,
            completeness_pct=completeness_pct,
            duplicate_count=duplicates,
            missing_value_pct=missing_per_column,
            numeric_outliers=numeric_outliers,
            categorical_cardinality=categorical_cardinality
        )
        
        self.logger.info(
            f"Data quality assessed. "
            f"Completeness: {completeness_pct:.2f}%, "
            f"Duplicates: {duplicates}"
        )
        
        return metrics
    
    # ========================================================================
    # REPORT GENERATION
    # ========================================================================
    
    def save_validation_report(self, report: DataValidationReport, 
                              filename: Optional[str] = None) -> str:
        """Save validation report to JSON file"""
        if filename is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"validation_report_{self.model_name}_{timestamp}.json"
        
        filepath = self.output_dir / filename
        with open(filepath, 'w') as f:
            json.dump(report.to_dict(), f, indent=2, default=str)
        
        return str(filepath)
    
    def save_performance_metrics(self, metrics: PerformanceMetrics,
                                filename: Optional[str] = None) -> str:
        """Save performance metrics to JSON file"""
        if filename is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"performance_metrics_{self.model_name}_{timestamp}.json"
        
        filepath = self.output_dir / filename
        with open(filepath, 'w') as f:
            json.dump(metrics.to_dict(), f, indent=2, default=str)
        
        return str(filepath)
    
    def save_quality_metrics(self, metrics: DataQualityMetrics,
                            filename: Optional[str] = None) -> str:
        """Save quality metrics to JSON file"""
        if filename is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"quality_metrics_{self.model_name}_{timestamp}.json"
        
        filepath = self.output_dir / filename
        with open(filepath, 'w') as f:
            json.dump(metrics.to_dict(), f, indent=2, default=str)
        
        return str(filepath)


# ============================================================================
# ALERT MANAGER
# ============================================================================

class AlertManager:
    """Manage and escalate monitoring alerts"""
    
    def __init__(self, output_dir: str = "monitoring_logs"):
        """Initialize alert manager"""
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(exist_ok=True)
        self.alerts: List[Dict] = []
    
    def add_alert(self, severity: str, message: str, 
                  category: str, metadata: Optional[Dict] = None) -> None:
        """
        Add an alert
        
        Args:
            severity: "critical", "warning", "info"
            message: Alert message
            category: "data_quality", "performance", "drift", etc.
            metadata: Additional context
        """
        alert = {
            "timestamp": datetime.now().isoformat(),
            "severity": severity,
            "category": category,
            "message": message,
            "metadata": metadata or {}
        }
        self.alerts.append(alert)
        
        # Log based on severity
        log_level = getattr(logging, severity.upper(), logging.INFO)
        logging.log(log_level, f"[{category.upper()}] {message}")
    
    def get_critical_alerts(self) -> List[Dict]:
        """Get all critical alerts"""
        return [a for a in self.alerts if a["severity"] == "critical"]
    
    def save_alerts(self, filename: Optional[str] = None) -> str:
        """Save alerts to JSON file"""
        if filename is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"alerts_{timestamp}.json"
        
        filepath = self.output_dir / filename
        with open(filepath, 'w') as f:
            json.dump(self.alerts, f, indent=2, default=str)
        
        return str(filepath)
    
    def clear_alerts(self) -> None:
        """Clear alert history"""
        self.alerts = []


# ============================================================================
# USAGE EXAMPLE
# ============================================================================

if __name__ == "__main__":
    # Example usage
    print("Hospital ML System Monitoring Module")
    print("=" * 50)
    
    # Define feature schema
    feature_schema = {
        "numeric_features": {
            "age": {"min": 0, "max": 120},
            "billed_amount": {"min": 0, "max": 1000000},
            "revenue_realization_ratio": {"min": 0, "max": 1.0}
        },
        "categorical_features": {
            "gender": ["M", "F"],
            "city": ["Delhi", "Mumbai", "Bangalore"],
            "visit_type": ["OPD", "ER", "ICU"]
        }
    }
    
    # Create monitor
    monitor = ModelMonitor("risk", feature_schema)
    
    # Create sample data
    sample_data = pd.DataFrame({
        "age": [25, 45, 65, 35, 55],
        "gender": ["M", "F", "M", "F", "M"],
        "city": ["Delhi", "Mumbai", "Delhi", "Mumbai", "Bangalore"],
        "visit_type": ["OPD", "ER", "OPD", "ICU", "OPD"],
        "billed_amount": [5000, 15000, 8000, 50000, 6000],
        "revenue_realization_ratio": [0.9, 0.85, 0.95, 0.88, 0.92]
    })
    
    # Run validation
    validation_report = monitor.validate_data(sample_data)
    print("\nValidation Report:")
    print(json.dumps(validation_report.to_dict(), indent=2, default=str))
    
    # Assess data quality
    quality_metrics = monitor.assess_data_quality(sample_data)
    print("\nData Quality Metrics:")
    print(json.dumps(quality_metrics.to_dict(), indent=2, default=str))
