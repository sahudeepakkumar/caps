"""
Phase 6: Audit Logging Module for Hospital ML System
Maintains comprehensive audit logs for compliance and governance

Created: 2026-06-14
Version: 1.0

This module provides:
- Audit logging for all predictions
- Model version tracking
- Data lineage tracking
- User action logging
- Regulatory compliance
"""

import json
import logging
import hashlib
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict
import uuid


# ============================================================================
# DATA STRUCTURES
# ============================================================================

@dataclass
class PredictionAuditLog:
    """Audit log entry for a single prediction"""
    log_id: str
    timestamp: str
    model_type: str  # "risk" or "claim"
    model_version: str
    input_hash: str  # Hash of input data for integrity
    input_summary: Dict[str, Any]  # Subset of input data (non-sensitive)
    prediction: str
    prediction_confidence: Optional[float]
    user_id: Optional[str]
    request_id: str
    status: str  # "success", "failed", "validation_failed"
    error_message: Optional[str]
    processing_time_ms: float
    data_quality_score: Optional[float]
    
    def to_dict(self) -> Dict:
        return asdict(self)


@dataclass
class ModelAuditLog:
    """Audit log entry for model operations"""
    log_id: str
    timestamp: str
    operation: str  # "deployment", "retraining", "evaluation", "rollback"
    model_type: str
    model_version_old: Optional[str]
    model_version_new: Optional[str]
    triggered_by: str  # "automated", "manual", "drift_alert"
    user_id: Optional[str]
    status: str  # "success", "failed", "pending"
    details: Dict[str, Any]
    
    def to_dict(self) -> Dict:
        return asdict(self)


@dataclass
class DataAuditLog:
    """Audit log entry for data operations"""
    log_id: str
    timestamp: str
    operation: str  # "ingestion", "transformation", "validation"
    data_source: str
    record_count: int
    quality_metrics: Dict[str, float]
    user_id: Optional[str]
    status: str
    details: Dict[str, Any]
    
    def to_dict(self) -> Dict:
        return asdict(self)


@dataclass
class AuditSummary:
    """Summary statistics from audit logs"""
    period_start: str
    period_end: str
    total_predictions: int
    successful_predictions: int
    failed_predictions: int
    avg_prediction_confidence: Optional[float]
    models_deployed: int
    retraining_events: int
    drift_alerts_triggered: int
    avg_data_quality_score: Optional[float]
    compliance_violations: int
    
    def to_dict(self) -> Dict:
        return asdict(self)


# ============================================================================
# AUDIT LOGGER CLASS
# ============================================================================

class AuditLogger:
    """
    Comprehensive audit logging system for hospital ML models
    Ensures regulatory compliance and governance
    """
    
    def __init__(self, output_dir: str = "audit_logs"):
        """
        Initialize audit logger
        
        Args:
            output_dir: Directory to store audit logs
        """
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(exist_ok=True)
        
        # Setup logging
        self.logger = logging.getLogger("audit")
        self.logger.setLevel(logging.INFO)
        
        # Separate file for audit logs
        handler = logging.FileHandler(
            self.output_dir / f"audit_{datetime.now().strftime('%Y%m%d')}.log"
        )
        handler.setFormatter(
            logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        )
        self.logger.addHandler(handler)
        
        # In-memory storage for session logs
        self.prediction_logs: List[PredictionAuditLog] = []
        self.model_logs: List[ModelAuditLog] = []
        self.data_logs: List[DataAuditLog] = []
    
    # ========================================================================
    # PREDICTION LOGGING
    # ========================================================================
    
    def log_prediction(self, model_type: str, model_version: str,
                      input_data: Dict, prediction: str,
                      prediction_confidence: Optional[float] = None,
                      user_id: Optional[str] = None,
                      request_id: Optional[str] = None,
                      processing_time_ms: float = 0.0,
                      data_quality_score: Optional[float] = None,
                      status: str = "success",
                      error_message: Optional[str] = None) -> PredictionAuditLog:
        """
        Log a prediction
        
        Args:
            model_type: "risk" or "claim"
            model_version: Version of the model
            input_data: Input features (full or subset)
            prediction: Predicted class
            prediction_confidence: Confidence score
            user_id: ID of user making prediction request
            request_id: Unique request identifier
            processing_time_ms: Time to generate prediction
            data_quality_score: Data quality assessment
            status: "success", "failed", "validation_failed"
            error_message: Error if applicable
            
        Returns:
            PredictionAuditLog entry
        """
        log_id = str(uuid.uuid4())
        timestamp = datetime.now().isoformat()
        request_id = request_id or str(uuid.uuid4())
        
        # Create hash of input for integrity verification
        input_str = json.dumps(input_data, sort_keys=True, default=str)
        input_hash = hashlib.sha256(input_str.encode()).hexdigest()
        
        # Create summary (exclude sensitive fields)
        input_summary = self._create_input_summary(input_data)
        
        audit_log = PredictionAuditLog(
            log_id=log_id,
            timestamp=timestamp,
            model_type=model_type,
            model_version=model_version,
            input_hash=input_hash,
            input_summary=input_summary,
            prediction=prediction,
            prediction_confidence=prediction_confidence,
            user_id=user_id,
            request_id=request_id,
            status=status,
            error_message=error_message,
            processing_time_ms=processing_time_ms,
            data_quality_score=data_quality_score
        )
        
        self.prediction_logs.append(audit_log)
        
        # Log to file
        log_msg = (
            f"[{model_type.upper()}] Prediction: {prediction} | "
            f"Status: {status} | "
            f"Confidence: {prediction_confidence} | "
            f"Quality: {data_quality_score} | "
            f"User: {user_id} | "
            f"Request: {request_id}"
        )
        self.logger.info(log_msg)
        
        return audit_log
    
    def _create_input_summary(self, input_data: Dict) -> Dict:
        """Create summary of input data for audit log (exclude sensitive info)"""
        summary = {}
        
        # Include key features, exclude PII
        sensitive_fields = {"patient_id", "patient_name", "email", "phone", 
                          "ssn", "password", "api_key"}
        
        for key, value in input_data.items():
            if key.lower() not in sensitive_fields:
                # For numeric values, include directly; for strings, include first 20 chars
                if isinstance(value, (int, float)):
                    summary[key] = value
                elif isinstance(value, str):
                    summary[key] = value[:20] if len(value) > 20 else value
                else:
                    summary[key] = str(value)[:20]
        
        return summary
    
    # ========================================================================
    # MODEL OPERATION LOGGING
    # ========================================================================
    
    def log_model_operation(self, operation: str, model_type: str,
                           model_version_new: str,
                           model_version_old: Optional[str] = None,
                           triggered_by: str = "manual",
                           user_id: Optional[str] = None,
                           status: str = "success",
                           details: Optional[Dict] = None) -> ModelAuditLog:
        """
        Log model operations (deployment, retraining, etc.)
        
        Args:
            operation: "deployment", "retraining", "evaluation", "rollback"
            model_type: "risk" or "claim"
            model_version_new: Version being deployed
            model_version_old: Previous version (for rollback)
            triggered_by: "automated", "manual", "drift_alert"
            user_id: User performing operation
            status: "success", "failed", "pending"
            details: Additional context
            
        Returns:
            ModelAuditLog entry
        """
        log_id = str(uuid.uuid4())
        timestamp = datetime.now().isoformat()
        
        audit_log = ModelAuditLog(
            log_id=log_id,
            timestamp=timestamp,
            operation=operation,
            model_type=model_type,
            model_version_old=model_version_old,
            model_version_new=model_version_new,
            triggered_by=triggered_by,
            user_id=user_id,
            status=status,
            details=details or {}
        )
        
        self.model_logs.append(audit_log)
        
        # Log to file
        log_msg = (
            f"[MODEL] {operation.upper()}: {model_type} v{model_version_new} | "
            f"Status: {status} | "
            f"Triggered by: {triggered_by} | "
            f"User: {user_id}"
        )
        log_level = logging.INFO if status == "success" else logging.WARNING
        self.logger.log(log_level, log_msg)
        
        return audit_log
    
    # ========================================================================
    # DATA OPERATION LOGGING
    # ========================================================================
    
    def log_data_operation(self, operation: str, data_source: str,
                          record_count: int,
                          quality_metrics: Optional[Dict] = None,
                          user_id: Optional[str] = None,
                          status: str = "success",
                          details: Optional[Dict] = None) -> DataAuditLog:
        """
        Log data operations (ingestion, transformation, validation)
        
        Args:
            operation: "ingestion", "transformation", "validation"
            data_source: Source of data
            record_count: Number of records processed
            quality_metrics: Data quality metrics
            user_id: User performing operation
            status: "success", "failed"
            details: Additional context
            
        Returns:
            DataAuditLog entry
        """
        log_id = str(uuid.uuid4())
        timestamp = datetime.now().isoformat()
        
        audit_log = DataAuditLog(
            log_id=log_id,
            timestamp=timestamp,
            operation=operation,
            data_source=data_source,
            record_count=record_count,
            quality_metrics=quality_metrics or {},
            user_id=user_id,
            status=status,
            details=details or {}
        )
        
        self.data_logs.append(audit_log)
        
        # Log to file
        log_msg = (
            f"[DATA] {operation.upper()}: {data_source} ({record_count} records) | "
            f"Status: {status} | "
            f"Quality: {quality_metrics} | "
            f"User: {user_id}"
        )
        self.logger.info(log_msg)
        
        return audit_log
    
    # ========================================================================
    # AUDIT RETRIEVAL AND ANALYSIS
    # ========================================================================
    
    def get_prediction_logs(self, model_type: Optional[str] = None,
                           status: Optional[str] = None,
                           start_time: Optional[str] = None,
                           end_time: Optional[str] = None) -> List[PredictionAuditLog]:
        """
        Retrieve prediction logs with optional filtering
        
        Args:
            model_type: Filter by model type
            status: Filter by status
            start_time: ISO format start time
            end_time: ISO format end time
            
        Returns:
            Filtered list of prediction logs
        """
        logs = self.prediction_logs
        
        if model_type:
            logs = [l for l in logs if l.model_type == model_type]
        
        if status:
            logs = [l for l in logs if l.status == status]
        
        if start_time:
            logs = [l for l in logs if l.timestamp >= start_time]
        
        if end_time:
            logs = [l for l in logs if l.timestamp <= end_time]
        
        return logs
    
    def get_model_logs(self, operation: Optional[str] = None,
                      model_type: Optional[str] = None,
                      status: Optional[str] = None) -> List[ModelAuditLog]:
        """Retrieve model operation logs"""
        logs = self.model_logs
        
        if operation:
            logs = [l for l in logs if l.operation == operation]
        
        if model_type:
            logs = [l for l in logs if l.model_type == model_type]
        
        if status:
            logs = [l for l in logs if l.status == status]
        
        return logs
    
    def generate_audit_summary(self, start_time: Optional[str] = None,
                              end_time: Optional[str] = None) -> AuditSummary:
        """
        Generate summary statistics from audit logs
        
        Args:
            start_time: ISO format start time
            end_time: ISO format end time
            
        Returns:
            AuditSummary with statistics
        """
        timestamp_now = datetime.now().isoformat()
        
        # Filter predictions by time
        pred_logs = self.prediction_logs
        if start_time:
            pred_logs = [l for l in pred_logs if l.timestamp >= start_time]
        if end_time:
            pred_logs = [l for l in pred_logs if l.timestamp <= end_time]
        
        # Calculate metrics
        successful_preds = len([l for l in pred_logs if l.status == "success"])
        failed_preds = len(pred_logs) - successful_preds
        
        confidences = [l.prediction_confidence for l in pred_logs 
                      if l.prediction_confidence is not None]
        avg_confidence = sum(confidences) / len(confidences) if confidences else None
        
        quality_scores = [l.data_quality_score for l in pred_logs 
                         if l.data_quality_score is not None]
        avg_quality = sum(quality_scores) / len(quality_scores) if quality_scores else None
        
        # Count model operations
        model_logs = self.model_logs
        if start_time:
            model_logs = [l for l in model_logs if l.timestamp >= start_time]
        if end_time:
            model_logs = [l for l in model_logs if l.timestamp <= end_time]
        
        deployments = len([l for l in model_logs if l.operation == "deployment"])
        retraining = len([l for l in model_logs if l.operation == "retraining"])
        
        # Count drift alerts (can be tracked in model logs details)
        drift_alerts = len([l for l in model_logs if l.triggered_by == "drift_alert"])
        
        summary = AuditSummary(
            period_start=start_time or timestamp_now,
            period_end=end_time or timestamp_now,
            total_predictions=len(pred_logs),
            successful_predictions=successful_preds,
            failed_predictions=failed_preds,
            avg_prediction_confidence=avg_confidence,
            models_deployed=deployments,
            retraining_events=retraining,
            drift_alerts_triggered=drift_alerts,
            avg_data_quality_score=avg_quality,
            compliance_violations=0  # Can be enhanced
        )
        
        return summary
    
    # ========================================================================
    # PERSISTENCE
    # ========================================================================
    
    def save_prediction_logs(self, filename: Optional[str] = None) -> str:
        """Save prediction logs to JSON"""
        if filename is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"prediction_logs_{timestamp}.json"
        
        filepath = self.output_dir / filename
        with open(filepath, 'w') as f:
            json.dump(
                [l.to_dict() for l in self.prediction_logs],
                f, indent=2, default=str
            )
        
        self.logger.info(f"Prediction logs saved: {filepath}")
        return str(filepath)
    
    def save_model_logs(self, filename: Optional[str] = None) -> str:
        """Save model operation logs to JSON"""
        if filename is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"model_logs_{timestamp}.json"
        
        filepath = self.output_dir / filename
        with open(filepath, 'w') as f:
            json.dump(
                [l.to_dict() for l in self.model_logs],
                f, indent=2, default=str
            )
        
        self.logger.info(f"Model logs saved: {filepath}")
        return str(filepath)
    
    def save_audit_summary(self, summary: AuditSummary,
                          filename: Optional[str] = None) -> str:
        """Save audit summary to JSON"""
        if filename is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"audit_summary_{timestamp}.json"
        
        filepath = self.output_dir / filename
        with open(filepath, 'w') as f:
            json.dump(summary.to_dict(), f, indent=2, default=str)
        
        self.logger.info(f"Audit summary saved: {filepath}")
        return str(filepath)
    
    def save_all_logs(self) -> Dict[str, str]:
        """Save all audit logs and summary"""
        results = {
            "predictions": self.save_prediction_logs(),
            "models": self.save_model_logs()
        }
        
        summary = self.generate_audit_summary()
        results["summary"] = self.save_audit_summary(summary)
        
        return results


# ============================================================================
# USAGE EXAMPLE
# ============================================================================

if __name__ == "__main__":
    print("Hospital ML System Audit Logger")
    print("=" * 50)
    
    # Create logger
    logger = AuditLogger()
    
    # Log some predictions
    print("\nLogging sample predictions...")
    for i in range(5):
        log = logger.log_prediction(
            model_type="risk",
            model_version="1.0",
            input_data={"age": 45, "gender": "M", "city": "Delhi"},
            prediction="High",
            prediction_confidence=0.92,
            user_id="dr_smith",
            data_quality_score=0.95
        )
        print(f"  Logged: {log.log_id}")
    
    # Log model operation
    print("\nLogging model deployment...")
    deploy_log = logger.log_model_operation(
        operation="deployment",
        model_type="risk",
        model_version_new="1.0",
        triggered_by="manual",
        user_id="ml_engineer",
        status="success"
    )
    print(f"  Logged: {deploy_log.log_id}")
    
    # Generate summary
    print("\nGenerating audit summary...")
    summary = logger.generate_audit_summary()
    print(f"  Total predictions: {summary.total_predictions}")
    print(f"  Successful: {summary.successful_predictions}")
    print(f"  Avg confidence: {summary.avg_prediction_confidence:.4f}")
    
    # Save logs
    print("\nSaving audit logs...")
    saved_files = logger.save_all_logs()
    for log_type, filepath in saved_files.items():
        print(f"  {log_type}: {filepath}")
