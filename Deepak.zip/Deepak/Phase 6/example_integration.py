"""
Phase 6: Example Integration Script
Shows how to use monitoring, drift detection, and audit logging together

Created: 2026-06-14
Version: 1.0

This script demonstrates:
1. Data validation on incoming predictions
2. Performance monitoring
3. Drift detection
4. Audit logging
5. Alert generation
"""

import sys
from pathlib import Path
import pandas as pd
import numpy as np
import json
import time
from datetime import datetime

# Add Phase 6 modules to path
sys.path.insert(0, str(Path(__file__).parent))

from monitoring import ModelMonitor, AlertManager
from drift_detection import DriftDetector
from audit_logger import AuditLogger


# ============================================================================
# CONFIGURATION
# ============================================================================

RISK_FEATURE_SCHEMA = {
    "numeric_features": {
        "age": {"min": 0, "max": 120},
        "length_of_stay_hours": {"min": 0, "max": 1000},
        "billed_amount": {"min": 0, "max": 500000},
        "revenue_realization_ratio": {"min": 0, "max": 1.0},
        "visit_frequency": {"min": 1, "max": 100},
        "avg_los_per_patient": {"min": 0, "max": 1000},
        "days_since_registration": {"min": 0, "max": 10000},
        "provider_rejection_rate": {"min": 0, "max": 100}
    },
    "categorical_features": {
        "gender": ["M", "F"],
        "city": ["Delhi", "Mumbai", "Bangalore", "Chennai", "Pune"],
        "visit_type": ["OPD", "ER", "ICU"],
        "department": ["Cardiology", "ER", "General", "ICU", "Neurology", "Orthopedics"],
        "insurance_provider": ["ICICI Health", "Star Health", "Max Bupa", "Apollo Health"],
        "visit_month": [1,2,3,4,5,6,7,8,9,10,11,12],
        "visit_quarter": [1,2,3,4],
        "visit_day_of_week": [0,1,2,3,4,5,6]
    }
}


# ============================================================================
# SAMPLE DATA GENERATION
# ============================================================================

def generate_baseline_data(n_samples=100):
    """Generate baseline training data"""
    np.random.seed(42)
    return pd.DataFrame({
        "age": np.random.normal(45, 15, n_samples),
        "gender": np.random.choice(["M", "F"], n_samples),
        "city": np.random.choice(["Delhi", "Mumbai", "Bangalore"], n_samples),
        "visit_type": np.random.choice(["OPD", "ER", "ICU"], n_samples),
        "department": np.random.choice(["Cardiology", "General", "ER"], n_samples),
        "length_of_stay_hours": np.random.uniform(1, 100, n_samples),
        "visit_frequency": np.random.randint(1, 10, n_samples),
        "avg_los_per_patient": np.random.uniform(5, 50, n_samples),
        "days_since_registration": np.random.randint(1, 3000, n_samples),
        "billed_amount": np.random.uniform(5000, 100000, n_samples),
        "revenue_realization_ratio": np.random.uniform(0.7, 1.0, n_samples),
        "insurance_provider": np.random.choice(["ICICI Health", "Star Health"], n_samples),
        "provider_rejection_rate": np.random.uniform(1, 20, n_samples),
        "visit_month": np.random.randint(1, 13, n_samples),
        "visit_quarter": np.random.randint(1, 5, n_samples),
        "visit_day_of_week": np.random.randint(0, 7, n_samples)
    })


def generate_current_data(n_samples=50):
    """Generate current period data (with slight drift)"""
    np.random.seed(123)
    return pd.DataFrame({
        "age": np.random.normal(48, 18, n_samples),  # Slight mean shift
        "gender": np.random.choice(["M", "F"], n_samples),
        "city": np.random.choice(["Delhi", "Mumbai", "Bangalore", "Chennai"], n_samples),
        "visit_type": np.random.choice(["OPD", "ER", "ICU"], n_samples),
        "department": np.random.choice(["Cardiology", "General", "ER", "Neurology"], n_samples),
        "length_of_stay_hours": np.random.uniform(2, 120, n_samples),
        "visit_frequency": np.random.randint(1, 12, n_samples),
        "avg_los_per_patient": np.random.uniform(8, 60, n_samples),
        "days_since_registration": np.random.randint(5, 3500, n_samples),
        "billed_amount": np.random.uniform(8000, 120000, n_samples),
        "revenue_realization_ratio": np.random.uniform(0.65, 1.0, n_samples),
        "insurance_provider": np.random.choice(["ICICI Health", "Star Health", "Max Bupa"], n_samples),
        "provider_rejection_rate": np.random.uniform(2, 25, n_samples),
        "visit_month": np.random.randint(1, 13, n_samples),
        "visit_quarter": np.random.randint(1, 5, n_samples),
        "visit_day_of_week": np.random.randint(0, 7, n_samples)
    })


# ============================================================================
# INTEGRATION EXAMPLE
# ============================================================================

def main():
    print("=" * 80)
    print("HOSPITAL ML SYSTEM - MONITORING, DRIFT DETECTION & GOVERNANCE")
    print("Integration Example")
    print("=" * 80)
    print()
    
    # ========================================================================
    # 1. INITIALIZE COMPONENTS
    # ========================================================================
    
    print("1. INITIALIZING COMPONENTS")
    print("-" * 80)
    
    monitor = ModelMonitor("risk", RISK_FEATURE_SCHEMA, output_dir="monitoring_logs")
    print("✓ Monitoring module initialized")
    
    baseline_data = generate_baseline_data(100)
    drift_detector = DriftDetector("risk", baseline_data, 
                                   {"numeric": [], "categorical": []}, 
                                   output_dir="monitoring_logs")
    print("✓ Drift detection module initialized")
    
    audit_logger = AuditLogger(output_dir="audit_logs")
    print("✓ Audit logger initialized")
    
    alert_manager = AlertManager(output_dir="monitoring_logs")
    print("✓ Alert manager initialized")
    print()
    
    # ========================================================================
    # 2. DATA VALIDATION
    # ========================================================================
    
    print("2. DATA VALIDATION")
    print("-" * 80)
    
    current_data = generate_current_data(50)
    print(f"Generated {len(current_data)} records for validation")
    
    validation_report = monitor.validate_data(current_data)
    print(f"Validation passed: {validation_report.is_valid}")
    print(f"Valid records: {validation_report.valid_records}/{validation_report.total_records}")
    
    if validation_report.alerts:
        print(f"Alerts ({len(validation_report.alerts)}):")
        for alert in validation_report.alerts:
            print(f"  - {alert}")
    else:
        print("✓ No validation issues")
    
    if validation_report.warnings:
        print(f"Warnings ({len(validation_report.warnings)}):")
        for warning in validation_report.warnings:
            print(f"  - {warning}")
    
    monitor.save_validation_report(validation_report)
    print("✓ Validation report saved")
    print()
    
    # ========================================================================
    # 3. DATA QUALITY ASSESSMENT
    # ========================================================================
    
    print("3. DATA QUALITY ASSESSMENT")
    print("-" * 80)
    
    quality_metrics = monitor.assess_data_quality(current_data)
    print(f"Completeness: {quality_metrics.completeness_pct:.2f}%")
    print(f"Duplicate records: {quality_metrics.duplicate_count}")
    
    if quality_metrics.missing_value_pct:
        print(f"Missing values:")
        for col, pct in quality_metrics.missing_value_pct.items():
            print(f"  - {col}: {pct:.2f}%")
    
    if quality_metrics.numeric_outliers:
        print(f"Numeric outliers:")
        for col, count in quality_metrics.numeric_outliers.items():
            print(f"  - {col}: {count} records")
    
    monitor.save_quality_metrics(quality_metrics)
    print("✓ Quality metrics saved")
    print()
    
    # ========================================================================
    # 4. PERFORMANCE MONITORING
    # ========================================================================
    
    print("4. PERFORMANCE MONITORING")
    print("-" * 80)
    
    # Simulate predictions
    y_true = np.random.choice(["Low", "Medium", "High"], 50)
    y_pred = np.random.choice(["Low", "Medium", "High"], 50)
    
    performance = monitor.calculate_performance_metrics(
        y_true, y_pred, ["Low", "Medium", "High"]
    )
    
    print(f"Accuracy: {performance.accuracy:.4f}")
    print(f"Precision (weighted): {performance.precision_weighted:.4f}")
    print(f"Recall (weighted): {performance.recall_weighted:.4f}")
    print(f"F1-Score (weighted): {performance.f1_weighted:.4f}")
    print(f"Support: {performance.support} samples")
    
    monitor.save_performance_metrics(performance)
    print("✓ Performance metrics saved")
    print()
    
    # ========================================================================
    # 5. DRIFT DETECTION
    # ========================================================================
    
    print("5. DRIFT DETECTION")
    print("-" * 80)
    
    baseline_preds = np.random.choice(["Low", "Medium", "High"], 100)
    current_preds = np.random.choice(["Low", "Medium", "High"], 50)
    
    drift_report = drift_detector.generate_drift_report(
        current_data, baseline_preds, current_preds,
        ["Low", "Medium", "High"], report_period="daily"
    )
    
    print(f"Report period: {drift_report.report_period}")
    print(f"Features analyzed: {drift_report.total_features_analyzed}")
    print(f"Features with drift: {drift_report.features_with_drift}")
    print(f"Overall drift score: {drift_report.overall_drift_score:.4f}")
    print(f"Drift level: {drift_report.drift_level}")
    
    if drift_report.alerts:
        print(f"\nDrift Alerts ({len(drift_report.alerts)}):")
        for alert in drift_report.alerts:
            print(f"  - {alert}")
    
    if drift_report.recommendations:
        print(f"\nRecommendations ({len(drift_report.recommendations)}):")
        for rec in drift_report.recommendations[:3]:  # Show first 3
            print(f"  - {rec}")
    
    drift_detector.save_drift_report(drift_report)
    print("✓ Drift report saved")
    print()
    
    # ========================================================================
    # 6. AUDIT LOGGING
    # ========================================================================
    
    print("6. AUDIT LOGGING")
    print("-" * 80)
    
    # Log predictions
    for i in range(5):
        pred_log = audit_logger.log_prediction(
            model_type="risk",
            model_version="1.0.0",
            input_data=current_data.iloc[i].to_dict(),
            prediction=np.random.choice(["Low", "Medium", "High"]),
            prediction_confidence=np.random.uniform(0.7, 0.99),
            user_id=f"user_{i}",
            processing_time_ms=np.random.uniform(50, 200),
            data_quality_score=0.95,
            status="success"
        )
        print(f"✓ Logged prediction {i+1}: {pred_log.log_id[:8]}...")
    
    # Log model operation
    model_log = audit_logger.log_model_operation(
        operation="deployment",
        model_type="risk",
        model_version_new="1.0.0",
        triggered_by="manual",
        user_id="ml_engineer",
        status="success",
        details={"accuracy_improvement": "+2.5%"}
    )
    print(f"✓ Logged model deployment: {model_log.log_id[:8]}...")
    
    # Log data operation
    data_log = audit_logger.log_data_operation(
        operation="validation",
        data_source="daily_extract",
        record_count=len(current_data),
        quality_metrics={"completeness": 0.978},
        status="success"
    )
    print(f"✓ Logged data operation: {data_log.log_id[:8]}...")
    
    audit_logger.save_prediction_logs()
    audit_logger.save_model_logs()
    print("✓ Audit logs saved")
    print()
    
    # ========================================================================
    # 7. AUDIT SUMMARY
    # ========================================================================
    
    print("7. AUDIT SUMMARY")
    print("-" * 80)
    
    summary = audit_logger.generate_audit_summary()
    print(f"Total predictions: {summary.total_predictions}")
    print(f"Successful: {summary.successful_predictions}")
    print(f"Failed: {summary.failed_predictions}")
    if summary.avg_prediction_confidence:
        print(f"Avg confidence: {summary.avg_prediction_confidence:.4f}")
    print(f"Models deployed: {summary.models_deployed}")
    print(f"Retraining events: {summary.retraining_events}")
    print(f"Drift alerts: {summary.drift_alerts_triggered}")
    
    audit_logger.save_audit_summary(summary)
    print("✓ Audit summary saved")
    print()
    
    # ========================================================================
    # 8. ALERT MANAGEMENT
    # ========================================================================
    
    print("8. ALERT MANAGEMENT")
    print("-" * 80)
    
    # Add sample alerts
    alert_manager.add_alert(
        severity="info",
        message="Daily validation completed successfully",
        category="monitoring"
    )
    
    if drift_report.drift_level == "high":
        alert_manager.add_alert(
            severity="warning",
            message="High drift detected - consider retraining",
            category="drift",
            metadata={"drift_score": drift_report.overall_drift_score}
        )
    
    if quality_metrics.completeness_pct < 95:
        alert_manager.add_alert(
            severity="warning",
            message="Data quality below threshold",
            category="data_quality",
            metadata={"completeness": quality_metrics.completeness_pct}
        )
    
    critical_alerts = alert_manager.get_critical_alerts()
    print(f"Critical alerts: {len(critical_alerts)}")
    print(f"Total alerts: {len(alert_manager.alerts)}")
    
    alert_manager.save_alerts()
    print("✓ Alerts saved")
    print()
    
    # ========================================================================
    # 9. SUMMARY REPORT
    # ========================================================================
    
    print("9. SUMMARY REPORT")
    print("-" * 80)
    
    print(f"""
MONITORING STATUS:
  Data Validation:        {'✓ PASS' if validation_report.is_valid else '✗ FAIL'}
  Data Completeness:      {quality_metrics.completeness_pct:.2f}% {'✓ OK' if quality_metrics.completeness_pct >= 95 else '✗ LOW'}
  Model Accuracy:         {performance.accuracy:.4f} {'✓ OK' if performance.accuracy >= 0.85 else '✗ LOW'}
  Drift Level:            {drift_report.drift_level.upper()} {'✓ OK' if drift_report.drift_level == 'none' else '⚠ ACTION NEEDED'}
  
SYSTEM HEALTH:
  Predictions Logged:     {summary.total_predictions}
  Success Rate:           {(summary.successful_predictions/summary.total_predictions*100):.1f}%
  Audit Trail:            {'✓ COMPLETE' if len(audit_logger.prediction_logs) > 0 else '✗ INCOMPLETE'}
  
RECOMMENDATIONS:
""")
    
    if drift_report.recommendations:
        for i, rec in enumerate(drift_report.recommendations[:3], 1):
            print(f"  {i}. {rec}")
    
    print()
    print("=" * 80)
    print("INTEGRATION EXAMPLE COMPLETED SUCCESSFULLY")
    print("=" * 80)
    print()
    print("Generated Files:")
    print("  - monitoring_logs/validation_report_*.json")
    print("  - monitoring_logs/quality_metrics_*.json")
    print("  - monitoring_logs/performance_metrics_*.json")
    print("  - monitoring_logs/drift_report_*.json")
    print("  - monitoring_logs/alerts_*.json")
    print("  - audit_logs/prediction_logs_*.json")
    print("  - audit_logs/model_logs_*.json")
    print("  - audit_logs/audit_summary_*.json")
    print()


if __name__ == "__main__":
    main()
