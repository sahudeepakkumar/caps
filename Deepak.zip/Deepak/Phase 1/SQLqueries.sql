-- ============================================================================
-- HOSPITAL DATA MANAGEMENT SYSTEM - COMPLETE SQL SCRIPT
-- IITM Capstone Project
-- ============================================================================
-- This script creates the complete database schema with proper constraints,
-- loads CSV data, and provides comprehensive analytical queries for
-- operational, financial, and data quality analysis.
-- ============================================================================

-- ============================================================================
-- PHASE 0: DATABASE AND SCHEMA SETUP
-- ============================================================================

-- Create database if it doesn't exist
CREATE DATABASE IF NOT EXISTS hospital_db;
USE hospital_db;

-- ============================================================================
-- PHASE 1A: TABLE CREATION WITH CONSTRAINTS AND DATA TYPES
-- ============================================================================

-- Drop tables if they exist (in reverse order due to foreign keys)
DROP TABLE IF EXISTS billing;
DROP TABLE IF EXISTS visits;
DROP TABLE IF EXISTS patients;

-- ============================================================================
-- TABLE 1: PATIENTS
-- Primary table storing patient demographic and registration data
-- ============================================================================
CREATE TABLE patients (
    patient_id INT PRIMARY KEY,
    age INT NOT NULL,
    gender VARCHAR(10) NOT NULL,
    city VARCHAR(50) NOT NULL,
    insurance_provider VARCHAR(50) NOT NULL,
    chronic_flag INT NOT NULL DEFAULT 0 CHECK (chronic_flag IN (0, 1)),
    registration_date DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_age CHECK (age >= 0 AND age <= 150)
);

-- ============================================================================
-- TABLE 2: VISITS
-- Stores hospital encounter and operational data
-- Links to patients table via patient_id
-- ============================================================================
CREATE TABLE visits (
    visit_id INT PRIMARY KEY,
    patient_id INT NOT NULL,
    visit_date DATE NOT NULL,
    department VARCHAR(50) NOT NULL,
    visit_type VARCHAR(20) NOT NULL,
    length_of_stay_hours DECIMAL(10, 2),
    risk_score VARCHAR(20) NOT NULL,
    doctor_id INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patients(patient_id),
    CONSTRAINT chk_risk_score CHECK (risk_score IN ('Low', 'Medium', 'High')),
    CONSTRAINT chk_visit_type CHECK (visit_type IN ('OPD', 'ER', 'ICU')),
    CONSTRAINT chk_length_of_stay CHECK (length_of_stay_hours >= 0)
);

-- ============================================================================
-- TABLE 3: BILLING
-- Stores billing and insurance claim information
-- Links to visits table via visit_id
-- ============================================================================
CREATE TABLE billing (
    bill_id INT PRIMARY KEY,
    visit_id INT NOT NULL,
    billed_amount DECIMAL(12, 2) NOT NULL,
    approved_amount DECIMAL(12, 2),
    claim_status VARCHAR(20) NOT NULL,
    payment_days INT,
    billing_date DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (visit_id) REFERENCES visits(visit_id),
    CONSTRAINT chk_billed_amount CHECK (billed_amount >= 0),
    CONSTRAINT chk_approved_amount CHECK (approved_amount IS NULL OR approved_amount >= 0),
    CONSTRAINT chk_claim_status CHECK (claim_status IN ('Paid', 'Pending', 'Rejected')),
    CONSTRAINT chk_payment_days CHECK (payment_days IS NULL OR payment_days >= 0)
);

-- ============================================================================
-- PHASE 1B: INDEX CREATION FOR PERFORMANCE OPTIMIZATION
-- ============================================================================
-- These indexes optimize commonly queried fields for faster data retrieval

-- Indexes on patients table
CREATE INDEX idx_patients_city ON patients(city);
CREATE INDEX idx_patients_insurance_provider ON patients(insurance_provider);
CREATE INDEX idx_patients_chronic_flag ON patients(chronic_flag);
CREATE INDEX idx_patients_registration_date ON patients(registration_date);

-- Indexes on visits table
CREATE INDEX idx_visits_patient_id ON visits(patient_id);
CREATE INDEX idx_visits_visit_date ON visits(visit_date);
CREATE INDEX idx_visits_department ON visits(department);
CREATE INDEX idx_visits_visit_type ON visits(visit_type);
CREATE INDEX idx_visits_risk_score ON visits(risk_score);
CREATE INDEX idx_visits_doctor_id ON visits(doctor_id);

-- Indexes on billing table
CREATE INDEX idx_billing_visit_id ON billing(visit_id);
CREATE INDEX idx_billing_claim_status ON billing(claim_status);
CREATE INDEX idx_billing_billing_date ON billing(billing_date);
CREATE INDEX idx_billing_payment_days ON billing(payment_days);

-- Composite indexes for common query patterns
CREATE INDEX idx_visits_department_risk ON visits(department, risk_score);
CREATE INDEX idx_billing_visit_status ON billing(visit_id, claim_status);
CREATE INDEX idx_patients_insurance_chronic ON patients(insurance_provider, chronic_flag);

-- ============================================================================
-- PHASE 2: DATA LOADING FROM CSV FILES
-- ============================================================================
-- Note: Adjust file paths based on your system. Use appropriate LOAD DATA statement.
-- For MySQL running on Windows, use proper file path format.

-- Load data into patients table
-- LOAD DATA INFILE 'C:/path/to/patients.csv'
-- INTO TABLE patients
-- FIELDS TERMINATED BY ','
-- LINES TERMINATED BY '\n'
-- IGNORE 1 ROWS
-- (patient_id, age, gender, city, insurance_provider, chronic_flag, registration_date);

-- Load data into visits table
-- LOAD DATA INFILE 'C:/path/to/visits.csv'
-- INTO TABLE visits
-- FIELDS TERMINATED BY ','
-- LINES TERMINATED BY '\n'
-- IGNORE 1 ROWS
-- (visit_id, patient_id, visit_date, department, visit_type, length_of_stay_hours, risk_score, doctor_id);

-- Load data into billing table
-- LOAD DATA INFILE 'C:/path/to/billing.csv'
-- INTO TABLE billing
-- FIELDS TERMINATED BY ','
-- LINES TERMINATED BY '\n'
-- IGNORE 1 ROWS
-- (bill_id, visit_id, billed_amount, approved_amount, claim_status, payment_days, billing_date);

-- ============================================================================
-- PHASE 3: OPERATIONAL ANALYSIS QUERIES
-- ============================================================================
-- These queries provide insights into hospital operations, department performance,
-- visit patterns, and physician workload analysis.

-- ============================================================================
-- OPERATIONAL QUERY 1: Top 10 Departments by Total Visit Volume
-- Purpose: Identify high-traffic departments for resource allocation
-- ============================================================================
-- Index Used: idx_visits_department
SELECT 
    department,
    COUNT(visit_id) AS total_visits,
    ROUND(COUNT(visit_id) * 100.0 / (SELECT COUNT(*) FROM visits), 2) AS visit_percentage
FROM visits
GROUP BY department
ORDER BY total_visits DESC
LIMIT 10;

-- ============================================================================
-- OPERATIONAL QUERY 2: Top 5 Departments with Highest Average Length of Stay
-- Purpose: Identify departments with longer patient stays for efficiency analysis
-- ============================================================================
-- Index Used: idx_visits_department
SELECT 
    department,
    COUNT(visit_id) AS total_visits,
    ROUND(AVG(length_of_stay_hours), 2) AS avg_length_of_stay,
    ROUND(MIN(length_of_stay_hours), 2) AS min_stay,
    ROUND(MAX(length_of_stay_hours), 2) AS max_stay,
    ROUND(STDDEV(length_of_stay_hours), 2) AS stddev_stay
FROM visits
WHERE length_of_stay_hours IS NOT NULL
GROUP BY department
ORDER BY avg_length_of_stay DESC
LIMIT 5;

-- ============================================================================
-- OPERATIONAL QUERY 3: Percentage of High Risk Visits per Department
-- Purpose: Identify departments with higher risk patient loads
-- ============================================================================
-- Index Used: idx_visits_department_risk
SELECT 
    department,
    COUNT(*) AS total_visits,
    SUM(CASE WHEN risk_score = 'High' THEN 1 ELSE 0 END) AS high_risk_visits,
    ROUND(SUM(CASE WHEN risk_score = 'High' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS high_risk_percentage,
    SUM(CASE WHEN risk_score = 'Medium' THEN 1 ELSE 0 END) AS medium_risk_visits,
    ROUND(SUM(CASE WHEN risk_score = 'Medium' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS medium_risk_percentage
FROM visits
GROUP BY department
ORDER BY high_risk_percentage DESC;

-- ============================================================================
-- OPERATIONAL QUERY 4: Average Number of Visits per Patient by City
-- Purpose: Understand patient engagement and healthcare utilization by region
-- ============================================================================
-- Index Used: idx_patients_city, idx_visits_patient_id
SELECT 
    p.city,
    COUNT(DISTINCT p.patient_id) AS total_patients,
    COUNT(v.visit_id) AS total_visits,
    ROUND(COUNT(v.visit_id) / COUNT(DISTINCT p.patient_id), 2) AS avg_visits_per_patient,
    ROUND(AVG(v.length_of_stay_hours), 2) AS avg_length_of_stay,
    COUNT(DISTINCT v.doctor_id) AS unique_doctors
FROM patients p
LEFT JOIN visits v ON p.patient_id = v.patient_id
GROUP BY p.city
ORDER BY avg_visits_per_patient DESC;

-- ============================================================================
-- OPERATIONAL QUERY 5: Doctors Handling Highest Number of High Risk Visits
-- Purpose: Identify experienced physicians managing critical patients
-- ============================================================================
-- Index Used: idx_visits_doctor_id, idx_visits_risk_score
SELECT 
    doctor_id,
    COUNT(*) AS total_visits,
    SUM(CASE WHEN risk_score = 'High' THEN 1 ELSE 0 END) AS high_risk_visits,
    ROUND(SUM(CASE WHEN risk_score = 'High' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS high_risk_percentage,
    ROUND(AVG(length_of_stay_hours), 2) AS avg_length_of_stay,
    COUNT(DISTINCT DATE(visit_date)) AS active_days
FROM visits
WHERE doctor_id IS NOT NULL
GROUP BY doctor_id
HAVING high_risk_visits > 0
ORDER BY high_risk_visits DESC, total_visits DESC
LIMIT 20;

-- ============================================================================
-- PHASE 4: FINANCIAL ANALYSIS QUERIES
-- ============================================================================
-- These queries analyze billing patterns, insurance provider performance,
-- and revenue realization metrics for financial decision-making.

-- ============================================================================
-- FINANCIAL QUERY 1: Top 10 Insurance Providers by Total Billed Amount
-- Purpose: Identify major insurance partners and volume drivers
-- ============================================================================
-- Index Used: idx_patients_insurance_provider, idx_billing_visit_id
SELECT 
    p.insurance_provider,
    COUNT(DISTINCT p.patient_id) AS total_patients,
    COUNT(DISTINCT v.visit_id) AS total_visits,
    ROUND(SUM(b.billed_amount), 2) AS total_billed,
    ROUND(AVG(b.billed_amount), 2) AS avg_billed_per_claim,
    ROUND(SUM(b.approved_amount), 2) AS total_approved,
    ROUND(SUM(b.approved_amount) / SUM(b.billed_amount) * 100, 2) AS realization_ratio
FROM patients p
INNER JOIN visits v ON p.patient_id = v.patient_id
INNER JOIN billing b ON v.visit_id = b.visit_id
GROUP BY p.insurance_provider
ORDER BY total_billed DESC
LIMIT 10;

-- ============================================================================
-- FINANCIAL QUERY 2: Top 5 Insurance Providers with Highest Claim Rejection Rate
-- Purpose: Identify problematic insurance providers for contract negotiation
-- ============================================================================
-- Index Used: idx_patients_insurance_provider, idx_billing_claim_status
SELECT 
    p.insurance_provider,
    COUNT(DISTINCT b.bill_id) AS total_claims,
    SUM(CASE WHEN b.claim_status = 'Rejected' THEN 1 ELSE 0 END) AS rejected_claims,
    ROUND(SUM(CASE WHEN b.claim_status = 'Rejected' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS rejection_rate,
    SUM(CASE WHEN b.claim_status = 'Paid' THEN 1 ELSE 0 END) AS paid_claims,
    SUM(CASE WHEN b.claim_status = 'Pending' THEN 1 ELSE 0 END) AS pending_claims,
    ROUND(SUM(CASE WHEN b.claim_status = 'Rejected' THEN b.billed_amount ELSE 0 END), 2) AS rejected_amount
FROM patients p
INNER JOIN visits v ON p.patient_id = v.patient_id
INNER JOIN billing b ON v.visit_id = b.visit_id
GROUP BY p.insurance_provider
HAVING total_claims > 0
ORDER BY rejection_rate DESC
LIMIT 5;

-- ============================================================================
-- FINANCIAL QUERY 3: Average Payment Delay by Insurance Provider
-- Purpose: Analyze cash flow patterns for working capital management
-- ============================================================================
-- Index Used: idx_patients_insurance_provider, idx_billing_payment_days
SELECT 
    p.insurance_provider,
    COUNT(DISTINCT b.bill_id) AS total_claims,
    ROUND(AVG(CASE WHEN b.claim_status = 'Paid' THEN b.payment_days END), 2) AS avg_payment_delay,
    MIN(CASE WHEN b.claim_status = 'Paid' THEN b.payment_days END) AS min_delay,
    MAX(CASE WHEN b.claim_status = 'Paid' THEN b.payment_days END) AS max_delay,
    ROUND(PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY b.payment_days) 
        OVER (PARTITION BY p.insurance_provider), 2) AS median_delay,
    SUM(CASE WHEN b.claim_status = 'Paid' THEN 1 ELSE 0 END) AS paid_claims
FROM patients p
INNER JOIN visits v ON p.patient_id = v.patient_id
INNER JOIN billing b ON v.visit_id = b.visit_id
WHERE b.payment_days IS NOT NULL AND b.claim_status = 'Paid'
GROUP BY p.insurance_provider
ORDER BY avg_payment_delay DESC;

-- ============================================================================
-- FINANCIAL QUERY 4: Revenue Realization Ratio by Department
-- Purpose: Measure billing effectiveness and approval rates by department
-- ============================================================================
-- Index Used: idx_visits_department, idx_billing_visit_id
SELECT 
    v.department,
    COUNT(DISTINCT b.bill_id) AS total_claims,
    ROUND(SUM(b.billed_amount), 2) AS total_billed,
    ROUND(SUM(b.approved_amount), 2) AS total_approved,
    ROUND(COALESCE(SUM(b.approved_amount), 0) / SUM(b.billed_amount) * 100, 2) AS realization_ratio,
    COUNT(CASE WHEN b.claim_status = 'Rejected' THEN 1 END) AS rejected_claims,
    COUNT(CASE WHEN b.claim_status = 'Pending' THEN 1 END) AS pending_claims,
    ROUND(AVG(b.billed_amount), 2) AS avg_claim_amount
FROM visits v
INNER JOIN billing b ON v.visit_id = b.visit_id
GROUP BY v.department
ORDER BY realization_ratio DESC;

-- ============================================================================
-- FINANCIAL QUERY 5: High Billed but Low/Zero Approved Claims
-- Purpose: Identify billing disputes and approval issues for follow-up
-- ============================================================================
-- Index Used: idx_billing_visit_id, idx_visits_department
SELECT 
    b.bill_id,
    v.visit_id,
    v.department,
    v.visit_date,
    p.insurance_provider,
    b.billed_amount,
    b.approved_amount,
    ROUND((b.billed_amount - COALESCE(b.approved_amount, 0)), 2) AS approval_gap,
    b.claim_status,
    ROUND((b.billed_amount - COALESCE(b.approved_amount, 0)) * 100.0 / b.billed_amount, 2) AS gap_percentage
FROM billing b
INNER JOIN visits v ON b.visit_id = v.visit_id
INNER JOIN patients p ON v.patient_id = p.patient_id
WHERE b.billed_amount > 5000 AND (b.approved_amount IS NULL OR b.approved_amount = 0)
ORDER BY approval_gap DESC
LIMIT 50;

-- ============================================================================
-- PHASE 5: DATA QUALITY AND INTEGRITY CHECKS
-- ============================================================================
-- These queries validate data completeness and consistency

-- ============================================================================
-- DATA QUALITY QUERY 1: Visits Without Corresponding Billing Records
-- Purpose: Identify unbilled services for revenue capture
-- ============================================================================
SELECT 
    COUNT(v.visit_id) AS visits_without_billing
FROM visits v
LEFT JOIN billing b ON v.visit_id = b.visit_id
WHERE b.bill_id IS NULL;

-- Detailed view of unbilled visits
SELECT 
    v.visit_id,
    v.patient_id,
    p.insurance_provider,
    v.visit_date,
    v.department,
    v.length_of_stay_hours
FROM visits v
LEFT JOIN billing b ON v.visit_id = b.visit_id
LEFT JOIN patients p ON v.patient_id = p.patient_id
WHERE b.bill_id IS NULL
ORDER BY v.visit_date DESC;

-- ============================================================================
-- DATA QUALITY QUERY 2: Billing Records Without Corresponding Visits
-- Purpose: Identify orphaned billing records indicating data integrity issues
-- ============================================================================
SELECT 
    COUNT(b.bill_id) AS billing_without_visits
FROM billing b
LEFT JOIN visits v ON b.visit_id = v.visit_id
WHERE v.visit_id IS NULL;

-- Detailed view of orphaned billing records
SELECT 
    b.bill_id,
    b.visit_id,
    b.billed_amount,
    b.claim_status,
    b.billing_date
FROM billing b
LEFT JOIN visits v ON b.visit_id = v.visit_id
WHERE v.visit_id IS NULL;

-- ============================================================================
-- DATA QUALITY QUERY 3: Patients with Duplicate IDs
-- Purpose: Ensure data integrity in patient master
-- ============================================================================
SELECT 
    COUNT(*) AS total_patients,
    COUNT(DISTINCT patient_id) AS unique_patients,
    COUNT(*) - COUNT(DISTINCT patient_id) AS duplicate_count
FROM patients;

-- Find duplicate records if any
SELECT 
    patient_id,
    COUNT(*) AS occurrence_count
FROM patients
GROUP BY patient_id
HAVING COUNT(*) > 1;

-- ============================================================================
-- DATA QUALITY QUERY 4: Missing or Invalid Length of Stay Hours
-- Purpose: Identify incomplete operational data
-- ============================================================================
SELECT 
    COUNT(*) AS total_visits,
    SUM(CASE WHEN length_of_stay_hours IS NULL THEN 1 ELSE 0 END) AS null_length_stay,
    ROUND(SUM(CASE WHEN length_of_stay_hours IS NULL THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS null_percentage
FROM visits;

-- Detail of visits with missing length_of_stay_hours
SELECT 
    v.visit_id,
    v.patient_id,
    v.visit_date,
    v.department,
    v.visit_type,
    v.length_of_stay_hours
FROM visits v
WHERE v.length_of_stay_hours IS NULL OR v.length_of_stay_hours < 0
ORDER BY v.visit_date DESC;

-- ============================================================================
-- DATA QUALITY QUERY 5: Missing or Invalid Payment Days
-- Purpose: Ensure billing timeline data is complete
-- ============================================================================
SELECT 
    COUNT(*) AS total_billing_records,
    SUM(CASE WHEN payment_days IS NULL THEN 1 ELSE 0 END) AS null_payment_days,
    ROUND(SUM(CASE WHEN payment_days IS NULL THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS null_percentage,
    SUM(CASE WHEN payment_days < 0 THEN 1 ELSE 0 END) AS negative_payment_days
FROM billing;

-- Detail of billing records with missing/invalid payment_days
SELECT 
    b.bill_id,
    b.visit_id,
    b.billed_amount,
    b.claim_status,
    b.payment_days,
    b.billing_date
FROM billing b
WHERE b.payment_days IS NULL OR b.payment_days < 0
ORDER BY b.billing_date DESC;

-- ============================================================================
-- DATA QUALITY QUERY 6: Visits Linked to Patients with Missing Insurance
-- Purpose: Ensure all patients have insurance information
-- ============================================================================
SELECT 
    COUNT(DISTINCT v.visit_id) AS visits_with_missing_insurance
FROM visits v
INNER JOIN patients p ON v.patient_id = p.patient_id
WHERE p.insurance_provider IS NULL OR p.insurance_provider = '';

-- Detailed view
SELECT 
    v.visit_id,
    v.patient_id,
    p.patient_id AS patient_exists,
    p.insurance_provider,
    v.visit_date,
    v.department
FROM visits v
LEFT JOIN patients p ON v.patient_id = p.patient_id
WHERE p.insurance_provider IS NULL OR p.insurance_provider = '' OR p.patient_id IS NULL
ORDER BY v.visit_date DESC;

-- ============================================================================
-- DATA QUALITY QUERY 7: Summary Data Quality Report
-- Purpose: Comprehensive data quality metrics dashboard
-- ============================================================================
SELECT 
    'Total Patients' AS metric,
    COUNT(*) AS value
FROM patients
UNION ALL
SELECT 
    'Total Visits',
    COUNT(*)
FROM visits
UNION ALL
SELECT 
    'Total Billing Records',
    COUNT(*)
FROM billing
UNION ALL
SELECT 
    'Visits with Billing',
    COUNT(DISTINCT v.visit_id)
FROM visits v
INNER JOIN billing b ON v.visit_id = b.visit_id
UNION ALL
SELECT 
    'Visits without Billing',
    COUNT(DISTINCT v.visit_id)
FROM visits v
LEFT JOIN billing b ON v.visit_id = b.visit_id
WHERE b.bill_id IS NULL
UNION ALL
SELECT 
    'Visits with Missing Length of Stay',
    COUNT(*)
FROM visits
WHERE length_of_stay_hours IS NULL
UNION ALL
SELECT 
    'Billing Records with Missing Payment Days',
    COUNT(*)
FROM billing
WHERE payment_days IS NULL
UNION ALL
SELECT 
    'High Risk Visits',
    COUNT(*)
FROM visits
WHERE risk_score = 'High'
UNION ALL
SELECT 
    'Visits with Chronic Patients',
    COUNT(DISTINCT v.visit_id)
FROM visits v
INNER JOIN patients p ON v.patient_id = p.patient_id
WHERE p.chronic_flag = 1;

-- ============================================================================
-- PHASE 6: ADVANCED ANALYTICAL VIEWS (OPTIONAL)
-- ============================================================================
-- Create views for common analytical queries

-- ============================================================================
-- VIEW 1: Department Performance Summary
-- ============================================================================
CREATE OR REPLACE VIEW v_department_performance AS
SELECT 
    v.department,
    COUNT(DISTINCT v.visit_id) AS total_visits,
    COUNT(DISTINCT v.patient_id) AS unique_patients,
    ROUND(AVG(v.length_of_stay_hours), 2) AS avg_length_of_stay,
    SUM(CASE WHEN v.risk_score = 'High' THEN 1 ELSE 0 END) AS high_risk_visits,
    ROUND(SUM(CASE WHEN v.risk_score = 'High' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS high_risk_pct,
    ROUND(SUM(b.billed_amount), 2) AS total_revenue,
    ROUND(SUM(b.approved_amount), 2) AS total_approved,
    ROUND(SUM(b.approved_amount) / SUM(b.billed_amount) * 100, 2) AS realization_ratio,
    ROUND(AVG(CASE WHEN b.claim_status = 'Paid' THEN b.payment_days END), 2) AS avg_payment_days
FROM visits v
LEFT JOIN billing b ON v.visit_id = b.visit_id
GROUP BY v.department;

-- ============================================================================
-- VIEW 2: Insurance Provider Summary
-- ============================================================================
CREATE OR REPLACE VIEW v_insurance_summary AS
SELECT 
    p.insurance_provider,
    COUNT(DISTINCT p.patient_id) AS total_patients,
    COUNT(DISTINCT v.visit_id) AS total_visits,
    ROUND(SUM(b.billed_amount), 2) AS total_billed,
    ROUND(SUM(b.approved_amount), 2) AS total_approved,
    COUNT(CASE WHEN b.claim_status = 'Rejected' THEN 1 END) AS rejected_claims,
    ROUND(COUNT(CASE WHEN b.claim_status = 'Rejected' THEN 1 END) * 100.0 / COUNT(*), 2) AS rejection_rate,
    ROUND(AVG(CASE WHEN b.claim_status = 'Paid' THEN b.payment_days END), 2) AS avg_payment_delay
FROM patients p
LEFT JOIN visits v ON p.patient_id = v.patient_id
LEFT JOIN billing b ON v.visit_id = b.visit_id
GROUP BY p.insurance_provider;

-- ============================================================================
-- VIEW 3: Patient Risk and Chronic Condition Analysis
-- ============================================================================
CREATE OR REPLACE VIEW v_patient_risk_analysis AS
SELECT 
    p.patient_id,
    p.age,
    p.gender,
    p.city,
    p.insurance_provider,
    p.chronic_flag,
    COUNT(DISTINCT v.visit_id) AS total_visits,
    ROUND(AVG(v.length_of_stay_hours), 2) AS avg_length_of_stay,
    SUM(CASE WHEN v.risk_score = 'High' THEN 1 ELSE 0 END) AS high_risk_visits,
    ROUND(SUM(b.billed_amount), 2) AS total_billed,
    ROUND(SUM(b.approved_amount), 2) AS total_approved
FROM patients p
LEFT JOIN visits v ON p.patient_id = v.patient_id
LEFT JOIN billing b ON v.visit_id = b.visit_id
GROUP BY p.patient_id;

-- ============================================================================
-- END OF SQL SCRIPT
-- ============================================================================
-- NOTES FOR IMPLEMENTATION:
-- 1. Uncomment and adjust the LOAD DATA INFILE statements with correct file paths
-- 2. Ensure MySQL server has appropriate file permissions (FILE privilege)
-- 3. For Windows paths, use forward slashes (/) or escaped backslashes
-- 4. Test data loading with LOAD DATA LOCAL INFILE if remote loading fails
-- 5. Verify data integrity after loading using the quality check queries
-- 6. Create views only after successful data loading
-- 7. Monitor query performance and adjust indexes if needed
-- ============================================================================
