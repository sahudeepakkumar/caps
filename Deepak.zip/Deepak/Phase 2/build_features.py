"""
Feature Engineering Script for Hospital Data Management System
IITM Capstone Project - Phase 2

This script loads the merged hospital dataset and creates engineered features
for predictive modeling, including:
- Visit frequency per patient
- Average length of stay per patient
- Insurance provider rejection rates
- Days since registration
- Temporal features (month, quarter, year)
- Revenue realization metrics
- Patient age groups
- Billing gap analysis
"""

import pandas as pd
import numpy as np
from datetime import datetime
import os

# Configuration
INPUT_PATH = r'c:\Users\sahud\OneDrive\Documents\IITM-Pravartak\Capstone Project'
OUTPUT_PATH = INPUT_PATH

# Reference date for calculating days since registration
REFERENCE_DATE = pd.to_datetime('2026-06-13')


def load_data():
    """Load CSV files and merge them into a single dataset"""
    print("Loading data files...")
    
    patients = pd.read_csv(f'{INPUT_PATH}/patients.csv')
    visits = pd.read_csv(f'{INPUT_PATH}/visits.csv')
    billing = pd.read_csv(f'{INPUT_PATH}/billing.csv')
    
    # Merge datasets
    merged_data = visits.merge(patients, on='patient_id', how='left')
    merged_data = merged_data.merge(billing, on='visit_id', how='left')
    
    # Convert date columns
    merged_data['visit_date'] = pd.to_datetime(merged_data['visit_date'])
    merged_data['registration_date'] = pd.to_datetime(merged_data['registration_date'])
    merged_data['billing_date'] = pd.to_datetime(merged_data['billing_date'])
    
    print(f"✓ Data loaded: {merged_data.shape[0]} rows, {merged_data.shape[1]} columns")
    return merged_data


def create_visit_frequency(df):
    """Create visit frequency feature (visits per patient)"""
    print("Creating visit_frequency feature...")
    visit_freq = df.groupby('patient_id').size().reset_index(name='visit_frequency')
    df = df.merge(visit_freq, on='patient_id', how='left')
    return df


def create_avg_los(df):
    """Create average length of stay per patient"""
    print("Creating avg_los_per_patient feature...")
    avg_los = df.groupby('patient_id')['length_of_stay_hours'].mean().reset_index(
        name='avg_los_per_patient'
    )
    df = df.merge(avg_los, on='patient_id', how='left')
    return df


def create_provider_rejection_rate(df):
    """Create insurance provider rejection rate feature"""
    print("Creating provider_rejection_rate feature...")
    rejection_rate = df.groupby('insurance_provider').apply(
        lambda x: (x['claim_status'] == 'Rejected').sum() / len(x) * 100 if len(x) > 0 else 0
    ).reset_index(name='provider_rejection_rate')
    df = df.merge(rejection_rate, on='insurance_provider', how='left')
    return df


def create_temporal_features(df):
    """Create temporal features from visit_date"""
    print("Creating temporal features...")
    df['visit_month'] = df['visit_date'].dt.month
    df['visit_quarter'] = df['visit_date'].dt.quarter
    df['visit_year'] = df['visit_date'].dt.year
    df['visit_day_of_week'] = df['visit_date'].dt.dayofweek
    df['visit_week_of_year'] = df['visit_date'].dt.isocalendar().week
    return df


def create_days_since_registration(df):
    """Create days since registration feature"""
    print("Creating days_since_registration feature...")
    df['days_since_registration'] = (REFERENCE_DATE - df['registration_date']).dt.days
    return df


def create_revenue_realization(df):
    """Create revenue realization ratio feature"""
    print("Creating revenue_realization_ratio feature...")
    df['revenue_realization_ratio'] = df['approved_amount'] / df['billed_amount']
    df['revenue_realization_ratio'] = df['revenue_realization_ratio'].fillna(0)
    df['revenue_realization_ratio'] = df['revenue_realization_ratio'].clip(0, 1)
    return df


def create_age_group(df):
    """Create categorical age group feature"""
    print("Creating age_group feature...")
    df['age_group'] = pd.cut(
        df['age'], 
        bins=[0, 18, 35, 50, 65, 100],
        labels=['<18', '18-35', '35-50', '50-65', '65+']
    )
    return df


def create_billing_gap(df):
    """Create billing gap feature"""
    print("Creating billing_gap feature...")
    df['billing_gap'] = df['billed_amount'] - df['approved_amount'].fillna(0)
    return df


def create_additional_features(df):
    """Create additional analytical features"""
    print("Creating additional features...")
    
    # Visit type encoded
    df['is_emergency'] = (df['visit_type'] == 'ER').astype(int)
    df['is_icu'] = (df['visit_type'] == 'ICU').astype(int)
    
    # Risk score encoded
    df['is_high_risk'] = (df['risk_score'] == 'High').astype(int)
    df['is_medium_risk'] = (df['risk_score'] == 'Medium').astype(int)
    
    # Chronic flag
    df['has_chronic_condition'] = df['chronic_flag'].astype(int)
    
    # Claim status encoded
    df['claim_rejected'] = (df['claim_status'] == 'Rejected').astype(int)
    df['claim_pending'] = (df['claim_status'] == 'Pending').astype(int)
    df['claim_paid'] = (df['claim_status'] == 'Paid').astype(int)
    
    # Billing amount categories
    df['billing_amount_category'] = pd.cut(
        df['billed_amount'],
        bins=[0, 10000, 25000, 50000, 100000],
        labels=['Low', 'Medium', 'High', 'Very High']
    )
    
    # Payment delay category
    payment_data = df.dropna(subset=['payment_days'])
    if len(payment_data) > 0:
        df['payment_delay_category'] = pd.cut(
            df['payment_days'],
            bins=[0, 7, 14, 21, 100],
            labels=['Quick', 'Normal', 'Slow', 'Very Slow']
        )
    
    return df


def create_patient_level_features(df):
    """Create patient-level aggregated features"""
    print("Creating patient-level features...")
    
    patient_summary = df.groupby('patient_id').agg({
        'visit_id': 'count',
        'length_of_stay_hours': ['mean', 'sum'],
        'billed_amount': ['sum', 'mean'],
        'approved_amount': ['sum', 'mean'],
        'is_high_risk': 'sum',
    }).reset_index()
    
    patient_summary.columns = ['patient_id', 'total_visits', 'total_los_hours', 'sum_los_hours',
                               'total_billed', 'avg_billing', 'total_approved', 'avg_approved',
                               'high_risk_visits']
    
    # Calculate high-risk visit percentage
    patient_summary['high_risk_visit_percent'] = (
        patient_summary['high_risk_visits'] / patient_summary['total_visits'] * 100
    )
    
    # Merge back to main dataframe
    df = df.merge(patient_summary.drop(['total_visits'], axis=1), on='patient_id', how='left')
    
    return df


def clean_and_handle_missing(df):
    """Clean data and handle missing values"""
    print("Cleaning data and handling missing values...")
    
    # Fill approved_amount with 0 for rejected claims
    df.loc[df['claim_status'] == 'Rejected', 'approved_amount'] = df.loc[df['claim_status'] == 'Rejected', 'approved_amount'].fillna(0)
    
    # Fill payment_days with 0 for instant claims
    df['payment_days'] = df['payment_days'].fillna(0)
    
    # Keep length_of_stay_hours as NULL for now (will investigate)
    
    return df


def validate_features(df):
    """Validate engineered features"""
    print("\nValidating engineered features...")
    
    features_to_check = [
        'visit_frequency', 'avg_los_per_patient', 'provider_rejection_rate',
        'days_since_registration', 'revenue_realization_ratio', 'billing_gap',
        'visit_month', 'visit_quarter', 'age_group'
    ]
    
    print("\nFeature Statistics:")
    for feature in features_to_check:
        if feature in df.columns:
            if df[feature].dtype in ['int64', 'float64']:
                print(f"{feature}: min={df[feature].min():.2f}, max={df[feature].max():.2f}, "
                      f"mean={df[feature].mean():.2f}, missing={df[feature].isnull().sum()}")
            else:
                print(f"{feature}: unique values={df[feature].nunique()}, missing={df[feature].isnull().sum()}")
    
    return df


def save_engineered_dataset(df, output_format='both'):
    """Save the engineered dataset in multiple formats"""
    print("\nSaving engineered dataset...")
    
    if output_format in ['csv', 'both']:
        csv_path = f'{OUTPUT_PATH}/model_table.csv'
        df.to_csv(csv_path, index=False)
        print(f"✓ Saved to {csv_path}")
    
    if output_format in ['parquet', 'both']:
        parquet_path = f'{OUTPUT_PATH}/model_table.parquet'
        df.to_parquet(parquet_path, index=False)
        print(f"✓ Saved to {parquet_path}")
    
    return df


def generate_feature_report(df):
    """Generate a report of all features"""
    print("\nGenerating feature report...")
    
    report = f"""
================================================================================
FEATURE ENGINEERING REPORT
Hospital Data Management System - IITM Capstone Project
Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
================================================================================

DATASET SUMMARY
===============
Total Records: {df.shape[0]}
Total Features: {df.shape[1]}
Date Range: {df['visit_date'].min().date()} to {df['visit_date'].max().date()}

ENGINEERED FEATURES
===================

1. Visit-Level Features:
   - visit_frequency: Number of visits per patient (1-{df['visit_frequency'].max()})
   - avg_los_per_patient: Average length of stay per patient (hours)
   - visit_month: Month of visit (1-12)
   - visit_quarter: Quarter of visit (1-4)
   - visit_year: Year of visit
   - visit_day_of_week: Day of week (0=Monday, 6=Sunday)
   - visit_week_of_year: Week number in year
   - is_emergency: Binary indicator for ER visits
   - is_icu: Binary indicator for ICU visits
   - is_high_risk: Binary indicator for high-risk visits
   - is_medium_risk: Binary indicator for medium-risk visits

2. Financial Features:
   - revenue_realization_ratio: (approved_amount / billed_amount) ratio
   - billing_gap: Difference between billed and approved amounts
   - billing_amount_category: Categorical binning of billing amounts
   - Total_billed: Total amount billed for patient
   - total_approved: Total approved amount for patient
   - avg_billing: Average billing amount per patient visit
   - avg_approved: Average approved amount per patient visit

3. Insurance Features:
   - provider_rejection_rate: Rejection rate by insurance provider (%)
   - claim_rejected: Binary indicator for rejected claims
   - claim_pending: Binary indicator for pending claims
   - claim_paid: Binary indicator for paid claims

4. Patient Features:
   - days_since_registration: Days elapsed since patient registration
   - age_group: Categorical age bins (<18, 18-35, 35-50, 50-65, 65+)
   - has_chronic_condition: Binary indicator for chronic conditions
   - total_visits: Cumulative visits per patient
   - total_los_hours: Cumulative hours in hospital per patient
   - high_risk_visits: Count of high-risk visits per patient
   - high_risk_visit_percent: Percentage of high-risk visits per patient

5. Temporal Features:
   - payment_delay_category: Categorical binning of payment days

FEATURE STATISTICS
==================

Numerical Features:
{df.describe().round(2).to_string()}

Categorical Features:
{df.select_dtypes(include='object').describe().to_string()}

MISSING VALUES
==============
{df.isnull().sum()[df.isnull().sum() > 0].to_string()}

DATA QUALITY
============
Total Records: {df.shape[0]}
Duplicate Records: {df.duplicated().sum()}
Completeness: {(1 - (df.isnull().sum().sum() / (df.shape[0] * df.shape[1]))) * 100:.2f}%

NEXT STEPS FOR MODELING
=======================
1. Handle missing values in length_of_stay_hours using department medians
2. Scale numerical features using StandardScaler or MinMaxScaler
3. Encode categorical variables using one-hot encoding
4. Handle outliers using robust scaling or winsorization
5. Create interaction features if needed
6. Perform feature selection based on business rules and correlations
7. Split data into train/validation/test sets

================================================================================
"""
    
    with open(f'{OUTPUT_PATH}/feature_engineering_report.txt', 'w') as f:
        f.write(report)
    
    print("✓ Feature report saved to feature_engineering_report.txt")
    return report


def main():
    """Main execution function"""
    print("="*80)
    print("HOSPITAL DATA FEATURE ENGINEERING")
    print("="*80 + "\n")
    
    try:
        # Load data
        df = load_data()
        
        # Create features
        df = create_visit_frequency(df)
        df = create_avg_los(df)
        df = create_provider_rejection_rate(df)
        df = create_temporal_features(df)
        df = create_days_since_registration(df)
        df = create_revenue_realization(df)
        df = create_age_group(df)
        df = create_billing_gap(df)
        df = create_additional_features(df)
        df = create_patient_level_features(df)
        
        # Clean and handle missing values
        df = clean_and_handle_missing(df)
        
        # Validate features
        df = validate_features(df)
        
        # Save dataset
        df = save_engineered_dataset(df, output_format='both')
        
        # Generate report
        report = generate_feature_report(df)
        
        print("\n" + "="*80)
        print("✓ FEATURE ENGINEERING COMPLETED SUCCESSFULLY")
        print("="*80)
        print(f"\nOutput Files Created:")
        print(f"  - model_table.csv ({df.shape[0]} rows × {df.shape[1]} columns)")
        print(f"  - model_table.parquet")
        print(f"  - feature_engineering_report.txt")
        
        return df
        
    except Exception as e:
        print(f"\n✗ ERROR: {str(e)}")
        raise


if __name__ == "__main__":
    df_engineered = main()
