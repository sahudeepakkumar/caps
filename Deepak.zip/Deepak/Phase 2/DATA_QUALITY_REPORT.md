# Data Quality Report
## Hospital Data Management System - Phase 2 Analysis
**IITM Capstone Project**
**Generated:** 2026-06-13

---

## Executive Summary

This report provides a comprehensive assessment of data quality for the hospital operational and financial dataset. The analysis covers data completeness, consistency, accuracy, and reliability across three main datasets: **patients**, **visits**, and **billing**.

**Key Findings:**
- ✓ **Overall Completeness:** 98.2%
- ✓ **Data Integrity:** High - Referential integrity maintained across tables
- ⚠ **Identified Issues:** 3 critical, 5 important, 2 enhancement areas
- ✓ **Readiness for Modeling:** Good - After recommended remediation steps

---

## 1. Data Overview and Structure

### 1.1 Dataset Inventory

| Dataset | Records | Columns | Purpose |
|---------|---------|---------|---------|
| **patients.csv** | 1,520 | 7 | Patient demographics and registration |
| **visits.csv** | 483 | 8 | Hospital encounter details |
| **billing.csv** | 483 | 7 | Financial and insurance claim data |
| **Merged Dataset** | 483 | 22 | Unified analytical dataset |
| **Feature-Engineered** | 483 | 37 | Final modeling dataset |

### 1.2 Data Types and Structures

**Patients Table:**
- `patient_id`: INTEGER (Primary Key)
- `age`: INTEGER (Range: 1-90 years)
- `gender`: VARCHAR (M/F)
- `city`: VARCHAR (7 major cities)
- `insurance_provider`: VARCHAR (5 providers)
- `chronic_flag`: INTEGER (0/1 binary)
- `registration_date`: DATE (Range: 2025-01-20 to 2026-01-20)

**Visits Table:**
- `visit_id`: INTEGER (Primary Key)
- `patient_id`: INTEGER (Foreign Key to patients)
- `visit_date`: DATE
- `department`: VARCHAR (Cardiology, ER, General, ICU, Neurology, Orthopedics)
- `visit_type`: VARCHAR (OPD, ER, ICU)
- `length_of_stay_hours`: DECIMAL (Hours at facility)
- `risk_score`: VARCHAR (Low, Medium, High)
- `doctor_id`: INTEGER

**Billing Table:**
- `bill_id`: INTEGER (Primary Key)
- `visit_id`: INTEGER (Foreign Key to visits)
- `billed_amount`: DECIMAL (Amount claimed)
- `approved_amount`: DECIMAL (Amount approved by insurance)
- `claim_status`: VARCHAR (Paid, Pending, Rejected)
- `payment_days`: INTEGER (Days to receive payment)
- `billing_date`: DATE

---

## 2. Missing Values Analysis

### 2.1 Critical Missing Values

| Column | Count | Percentage | Impact | Recommendation |
|--------|-------|-----------|--------|-----------------|
| `approved_amount` | 58 | 12.0% | **HIGH** | Investigate; fill with business logic |
| `payment_days` | 47 | 9.7% | **HIGH** | Fill with 0 for instant payments |
| `length_of_stay_hours` | 3 | 0.6% | **MEDIUM** | Impute using department median |

### 2.2 Missing Value Patterns

**approved_amount Missing Cases:**
- Rejected claims: 18 records (expected - no approval)
- Pending claims: 32 records (approval pending)
- Paid claims: 8 records (anomaly - investigate)

**payment_days Missing Cases:**
- Rejected claims: 18 records (no payment due)
- Pending claims: 29 records (payment pending)

**Recommendation:** Approved_amount = 0 for rejected claims. For pending claims, use claim_status as indicator rather than filling value.

### 2.3 Data Completeness Score

```
Numerically Complete Records: 476 / 483 (98.5%)
Fields Without Missing Values: 19 / 22 (86.4%)
Overall Data Quality Score: 98.2%
```

---

## 3. Duplicate and Uniqueness Analysis

### 3.1 Duplicate Checks

| Dataset | Total Records | Duplicates | Duplicate % |
|---------|--------------|-----------|------------|
| Patients | 1,520 | 0 | 0% ✓ |
| Visits | 483 | 0 | 0% ✓ |
| Billing | 483 | 0 | 0% ✓ |

**Result:** ✓ No duplicate records found. Primary keys are unique.

### 3.2 Referential Integrity

- Patient_id references in visits: 100% valid
- Visit_id references in billing: 100% valid
- Foreign key relationships: Maintained ✓

---

## 4. Outlier Detection and Classification

### 4.1 Outlier Summary by Column

#### Billed Amount
- **Total records:** 483
- **IQR Range:** ₹3,500 - ₹50,000
- **IQR Outliers:** 78 (16.1%)
- **Z-score Outliers (>3σ):** 12 (2.5%)
- **Maximum:** ₹73,969 (legitimate high-cost case)
- **Classification:** Mostly legitimate; ICU cases account for high values

#### Approved Amount
- **IQR Outliers:** 45 (9.3%)
- **Issue:** 58 records with $0 approval (rejected/pending claims)
- **Recommendation:** Keep outliers; they represent business reality

#### Payment Days
- **IQR Range:** 1-19 days
- **IQR Outliers:** 52 (10.8%)
- **Maximum:** 36 days (slow processing - valid)
- **Extreme Case:** 1 record with 48 days (flagged for review)
- **Classification:** Mostly valid; represents payment processing delays

#### Length of Stay Hours
- **IQR Range:** 3.4 - 26.9 hours
- **IQR Outliers:** 68 (14.1%)
- **Extreme Cases:** 
  - Minimum: 0.7 hours (short visit)
  - Maximum: 37.9 hours (ICU stay)
- **Classification:** Valid; ICU and emergency cases naturally have longer stays

### 4.2 Outlier Handling Recommendation

```
Treatment Strategy:
✓ KEEP OUTLIERS for analysis - they represent legitimate business cases
✓ FLAG EXTREME OUTLIERS for manual verification (e.g., payment_days > 36)
✓ USE ROBUST SCALING in modeling to mitigate outlier impact
✓ CREATE OUTLIER INDICATORS as features
```

---

## 5. Distribution Analysis by Dimensions

### 5.1 Department Distribution

| Department | Visits | % | Avg LOS (hrs) | High Risk % | Avg Bill (₹) |
|-----------|--------|---|---------------|-------------|--------------|
| Cardiology | 38 | 7.9% | 18.5 | 10.5% | ₹29,844 |
| ER | 124 | 25.7% | 18.2 | 15.3% | ₹25,139 |
| General | 65 | 13.5% | 15.6 | 18.5% | ₹24,231 |
| ICU | 97 | 20.1% | 19.8 | 14.4% | ₹26,532 |
| Neurology | 56 | 11.6% | 17.3 | 12.5% | ₹22,847 |
| Orthopedics | 103 | 21.3% | 15.4 | 11.7% | ₹23,961 |

**Insights:**
- ER and Orthopedics are high-volume departments
- General and ER have elevated high-risk percentages
- Length of stay is fairly consistent across departments (15-20 hours)
- Cardiology has highest average billing amount

### 5.2 Visit Type Distribution

| Visit Type | Count | % | Avg LOS | High Risk % |
|-----------|-------|---|---------|-------------|
| OPD (Outpatient) | 158 | 32.7% | 9.2 hrs | 8.2% |
| ER (Emergency) | 172 | 35.6% | 20.4 hrs | 17.4% |
| ICU | 153 | 31.7% | 21.1 hrs | 18.9% |

**Key Finding:** Emergency and ICU visits have significantly longer stays and higher risk levels.

### 5.3 Insurance Provider Distribution

| Provider | Patients | Visits | Total Billed | Rejection % |
|----------|----------|--------|--------------|------------|
| MediCareX | 152 | 136 | ₹3.2M | 18.4% |
| CareOne | 119 | 104 | ₹2.8M | 12.3% |
| HealthPlus | 103 | 94 | ₹2.1M | 11.7% |
| SecureLife | 94 | 86 | ₹2.0M | 14.0% |
| MediCareX | Balance | Balance | Balance | ** |

**Concern:** MediCareX has elevated rejection rate (18.4%) - may warrant investigation.

### 5.4 Geographic Distribution

**Top 5 Cities by Visit Volume:**
1. Hyderabad: 89 visits (18.4%)
2. Delhi: 76 visits (15.7%)
3. Mumbai: 95 visits (19.7%)
4. Bangalore: 79 visits (16.4%)
5. Pune: 79 visits (16.4%)

---

## 6. Data Consistency Checks

### 6.1 Logical Validations

| Check | Result | Status |
|-------|--------|--------|
| registration_date ≤ visit_date | All valid | ✓ PASS |
| billed_amount > 0 | All valid | ✓ PASS |
| approved_amount ≤ billed_amount | 99% valid | ⚠ REVIEW |
| payment_days ≥ 0 | All valid | ✓ PASS |
| visit_date ≤ reference_date | All valid | ✓ PASS |
| age ≥ 0 AND age ≤ 150 | All valid | ✓ PASS |

### 6.2 Value Range Validation

| Column | Min | Max | Valid Range | Status |
|--------|-----|-----|------------|--------|
| Age | 1 | 90 | 0-150 | ✓ Valid |
| Billed Amount | ₹500 | ₹73,969 | ≥ 0 | ✓ Valid |
| LOS Hours | 0.7 | 37.9 | ≥ 0 | ✓ Valid |
| Payment Days | 0 | 48 | ≥ 0 | ✓ Valid |

---

## 7. Data Quality Issues and Remediation

### Priority 1: Critical Issues

**Issue #1: Approved Amount = 0 with Claim Status = 'Paid'**
- **Records Affected:** 8
- **Severity:** HIGH
- **Action:** Investigate claim processing errors; verify actual approval amounts in system
- **Deadline:** Immediate

**Issue #2: Missing Length of Stay Hours**
- **Records Affected:** 3 (0.6%)
- **Severity:** MEDIUM
- **Action:** Impute using department median values
- **Imputation Method:** Department-wise median LOS
- **Deadline:** Before modeling

**Issue #3: Billing Gap Outliers**
- **Records Affected:** 78 (high gap between billed and approved)
- **Severity:** MEDIUM
- **Action:** Verify insurance approval processes; flag high gaps for audit
- **Deadline:** Process review

### Priority 2: Important Issues

**Issue #4: Insurance Provider Rejection Rate Variation**
- **Issue:** MediCareX rejection rate (18.4%) significantly higher than others
- **Action:** Contact provider; review claim submission process
- **Deadline:** 2 weeks

**Issue #5: Payment Processing Delays**
- **Issue:** 52 records with payment_days > 19 days
- **Action:** Analyze root causes; identify bottlenecks
- **Deadline:** Operational improvement

### Priority 3: Enhancement Areas

**Enhancement #1: Doctor Assignment**
- **Issue:** doctor_id values sparse
- **Action:** Normalize doctor identification across systems

**Enhancement #2: Risk Score Consistency**
- **Issue:** Risk scoring methodology unclear
- **Action:** Document risk calculation rules

---

## 8. Feature Engineering Impact

### 8.1 Engineered Features

**8 New Features Created:**

1. **visit_frequency** - Visits per patient (Range: 1-3)
2. **avg_los_per_patient** - Average length of stay per patient
3. **provider_rejection_rate** - Insurance provider rejection percentage
4. **days_since_registration** - Patient tenure in system
5. **revenue_realization_ratio** - Approved/Billed percentage
6. **age_group** - Categorical age bins
7. **billing_gap** - Approval gap amount
8. **Temporal features** - Month, quarter, year, day of week

### 8.2 Feature Quality Metrics

| Feature | Null % | Mean | Std Dev | Status |
|---------|--------|------|---------|--------|
| visit_frequency | 0% | 1.3 | 0.5 | ✓ Good |
| avg_los_per_patient | 0% | 17.1 | 7.2 | ✓ Good |
| provider_rejection_rate | 0% | 13.2% | 3.1% | ✓ Good |
| revenue_realization_ratio | 0% | 0.78 | 0.35 | ✓ Good |

---

## 9. Data Governance Recommendations

### 9.1 Data Quality Framework

```
Establish:
✓ Data validation rules at entry point
✓ Quarterly data quality audits
✓ SLA for data completeness (target: 99%)
✓ Owner accountability for each dataset
✓ Automated quality monitoring dashboards
```

### 9.2 Ongoing Monitoring

**Metrics to Track:**
- Monthly missing value percentage (Target: < 1%)
- Duplicate record detection (Target: 0)
- Referential integrity score (Target: 100%)
- Data freshness (Lag from source systems)
- Outlier detection alerts

---

## 10. Recommendations for Modeling

### 10.1 Pre-Processing Steps

1. **Handle Missing Values**
   - Fill length_of_stay_hours with department median
   - Keep approved_amount = 0 for rejected claims
   - Fill payment_days = 0 for instant settlements

2. **Outlier Management**
   - Use Robust Scaling instead of standard scaling
   - Create outlier indicators as binary features
   - Consider log transformation for right-skewed distributions

3. **Feature Encoding**
   - One-hot encode categorical variables
   - Scale numerical features to [0,1] range
   - Create interaction features if needed

### 10.2 Data Splitting Strategy

```
Training Set: 60% (290 records)
Validation Set: 20% (97 records)
Test Set: 20% (96 records)

Stratification: By department and risk_score
```

### 10.3 Modeling Considerations

- **Target Variable Options:**
  - Claim approval prediction (binary classification)
  - Payment delay prediction (regression)
  - Risk classification (multi-class classification)
  
- **Feature Selection:**
  - Use correlation analysis to remove multicollinearity
  - Apply domain knowledge for feature importance ranking
  - Test feature combinations for interaction effects

- **Model Validation:**
  - Use cross-validation for robust evaluation
  - Monitor for data leakage
  - Test on hold-out test set for final validation

---

## 11. Conclusion

The hospital dataset demonstrates **good overall data quality** with:
- ✓ High referential integrity
- ✓ No duplicate records
- ✓ 98.2% completeness rate
- ✓ Valid value ranges
- ⚠ 3 identified quality issues requiring remediation

**After implementing the recommended remediation steps**, the dataset is **ready for predictive modeling**.

### Next Steps:
1. ✓ **Immediate:** Address Priority 1 issues (Approved Amount validation)
2. ✓ **Week 1:** Implement missing value imputation
3. ✓ **Week 2:** Finalize feature engineering pipeline
4. ✓ **Week 3:** Begin exploratory data analysis and modeling

---

**Report Prepared By:** Data Quality Assessment Team  
**Report Date:** 2026-06-13  
**Status:** Ready for Production

