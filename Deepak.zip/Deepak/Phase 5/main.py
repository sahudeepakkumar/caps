"""
Phase 5: Hospital Data Management System - FastAPI Service
Deployment and API Integration for Risk and Claim Models

Models:
- Model A: Visit Risk Classification (Low/Medium/High)
- Model B: Claim Outcome Prediction (Paid/Pending/Rejected)

Created: 2026-06-13
Version: 1.0
"""

import os
import sys
import json
import joblib
import logging
import hashlib
import traceback
from datetime import datetime
from typing import Dict, List, Optional, Tuple
from pathlib import Path

import numpy as np
import pandas as pd
from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field, validator
import uvicorn

# ============================================================================
# LOGGING CONFIGURATION
# ============================================================================

# Create logs directory if it doesn't exist
LOG_DIR = Path("logs")
LOG_DIR.mkdir(exist_ok=True)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(LOG_DIR / f"api_service_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"),
        logging.StreamHandler(sys.stdout)
    ]
)

logger = logging.getLogger(__name__)

# Prediction logging (separate file)
prediction_logger = logging.getLogger("predictions")
prediction_handler = logging.FileHandler(LOG_DIR / f"predictions_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")
prediction_handler.setFormatter(logging.Formatter('%(asctime)s - %(message)s'))
prediction_logger.addHandler(prediction_handler)
prediction_logger.setLevel(logging.INFO)

# ============================================================================
# MODEL CONFIGURATION
# ============================================================================

MODEL_CONFIG = {
    "risk": {
        "model_path": "02_risk_model.joblib",
        "scaler_path": "risk_model_scaler.joblib",
        "encoder_path": "risk_model_label_encoder.joblib",
        "version": "1.0",
        "classes": ["Low", "Medium", "High"],
        "n_features": 18,
        "description": "Visit Risk Classification Model - Predicts Low/Medium/High risk for hospital visits"
    },
    "claim": {
        "model_path": "03_claim_model.joblib",
        "scaler_path": "claim_model_scaler.joblib",
        "encoder_path": "claim_model_label_encoder.joblib",
        "version": "1.0",
        "classes": ["Paid", "Pending", "Rejected"],
        "n_features": 20,
        "description": "Claim Outcome Classification Model - Predicts claim status (Paid/Pending/Rejected)"
    }
}

FEATURE_CONFIG = {
    "risk": {
        "features": [
            "age", "gender", "chronic_flag", "city",
            "visit_type", "department", "length_of_stay_hours",
            "visit_frequency", "avg_los_per_patient", "days_since_registration",
            "billed_amount", "revenue_realization_ratio",
            "insurance_provider", "provider_rejection_rate",
            "visit_month", "visit_quarter", "visit_day_of_week"
        ],
        "categorical": ["gender", "city", "visit_type", "department", "insurance_provider", "visit_month", "visit_quarter", "visit_day_of_week"],
        "numeric": ["age", "chronic_flag", "length_of_stay_hours", "visit_frequency", "avg_los_per_patient", 
                   "days_since_registration", "billed_amount", "revenue_realization_ratio", "provider_rejection_rate"]
    },
    "claim": {
        "features": [
            "age", "gender", "chronic_flag", "city",
            "visit_type", "department", "length_of_stay_hours", "risk_score",
            "billed_amount", "approved_amount", "revenue_realization_ratio", "billing_gap",
            "insurance_provider", "provider_rejection_rate",
            "visit_frequency", "days_since_registration", "avg_los_per_patient",
            "visit_month", "visit_quarter", "visit_day_of_week"
        ],
        "categorical": ["gender", "city", "visit_type", "department", "insurance_provider", "visit_month", "visit_quarter", "visit_day_of_week"],
        "numeric": ["age", "chronic_flag", "length_of_stay_hours", "risk_score", "billed_amount", "approved_amount",
                   "revenue_realization_ratio", "billing_gap", "provider_rejection_rate", "visit_frequency", 
                   "days_since_registration", "avg_los_per_patient"]
    }
}

# ============================================================================
# REQUEST/RESPONSE SCHEMAS
# ============================================================================

class RiskPredictionRequest(BaseModel):
    """Request schema for Risk Prediction"""
    age: int = Field(..., ge=0, le=120, description="Patient age (0-120)")
    gender: str = Field(..., description="Patient gender (M/F/Other)")
    chronic_flag: int = Field(..., ge=0, le=1, description="Has chronic condition (0/1)")
    city: str = Field(..., description="City of residence")
    visit_type: str = Field(..., description="Visit type (OPD/ER/ICU)")
    department: str = Field(..., description="Hospital department")
    length_of_stay_hours: float = Field(..., ge=0, description="Length of stay in hours")
    visit_frequency: int = Field(..., ge=0, description="Number of visits")
    avg_los_per_patient: float = Field(..., ge=0, description="Average length of stay")
    days_since_registration: int = Field(..., ge=0, description="Days since patient registration")
    billed_amount: float = Field(..., ge=0, description="Billed amount in dollars")
    revenue_realization_ratio: float = Field(..., ge=0, le=1, description="Revenue realization ratio (0-1)")
    insurance_provider: str = Field(..., description="Insurance provider name")
    provider_rejection_rate: float = Field(..., ge=0, le=100, description="Provider rejection rate (%)")
    visit_month: int = Field(..., ge=1, le=12, description="Month of visit (1-12)")
    visit_quarter: int = Field(..., ge=1, le=4, description="Quarter (1-4)")
    visit_day_of_week: str = Field(..., description="Day of week (Mon-Sun)")
    
    class Config:
        schema_extra = {
            "example": {
                "age": 45,
                "gender": "M",
                "chronic_flag": 1,
                "city": "Delhi",
                "visit_type": "ER",
                "department": "Cardiology",
                "length_of_stay_hours": 24.5,
                "visit_frequency": 3,
                "avg_los_per_patient": 18.2,
                "days_since_registration": 365,
                "billed_amount": 5000.0,
                "revenue_realization_ratio": 0.95,
                "insurance_provider": "ICICI Health",
                "provider_rejection_rate": 5.2,
                "visit_month": 6,
                "visit_quarter": 2,
                "visit_day_of_week": "Monday"
            }
        }

class ClaimPredictionRequest(BaseModel):
    """Request schema for Claim Outcome Prediction"""
    age: int = Field(..., ge=0, le=120, description="Patient age")
    gender: str = Field(..., description="Patient gender (M/F/Other)")
    chronic_flag: int = Field(..., ge=0, le=1, description="Has chronic condition (0/1)")
    city: str = Field(..., description="City of residence")
    visit_type: str = Field(..., description="Visit type (OPD/ER/ICU)")
    department: str = Field(..., description="Hospital department")
    length_of_stay_hours: float = Field(..., ge=0, description="Length of stay in hours")
    risk_score: str = Field(..., description="Risk score (Low/Medium/High)")
    billed_amount: float = Field(..., ge=0, description="Billed amount in dollars")
    approved_amount: float = Field(..., ge=0, description="Approved amount in dollars")
    revenue_realization_ratio: float = Field(..., ge=0, le=1, description="Revenue realization ratio (0-1)")
    billing_gap: float = Field(..., description="Difference between billed and approved")
    insurance_provider: str = Field(..., description="Insurance provider name")
    provider_rejection_rate: float = Field(..., ge=0, le=100, description="Provider rejection rate (%)")
    visit_frequency: int = Field(..., ge=0, description="Number of visits")
    days_since_registration: int = Field(..., ge=0, description="Days since patient registration")
    avg_los_per_patient: float = Field(..., ge=0, description="Average length of stay")
    visit_month: int = Field(..., ge=1, le=12, description="Month of visit (1-12)")
    visit_quarter: int = Field(..., ge=1, le=4, description="Quarter (1-4)")
    visit_day_of_week: str = Field(..., description="Day of week (Mon-Sun)")
    
    class Config:
        schema_extra = {
            "example": {
                "age": 45,
                "gender": "M",
                "chronic_flag": 1,
                "city": "Delhi",
                "visit_type": "ER",
                "department": "Cardiology",
                "length_of_stay_hours": 24.5,
                "risk_score": "High",
                "billed_amount": 5000.0,
                "approved_amount": 4500.0,
                "revenue_realization_ratio": 0.90,
                "billing_gap": 500.0,
                "insurance_provider": "ICICI Health",
                "provider_rejection_rate": 5.2,
                "visit_frequency": 3,
                "days_since_registration": 365,
                "avg_los_per_patient": 18.2,
                "visit_month": 6,
                "visit_quarter": 2,
                "visit_day_of_week": "Monday"
            }
        }

class RiskPredictionResponse(BaseModel):
    """Response schema for Risk Prediction"""
    prediction_id: str = Field(..., description="Unique prediction identifier")
    timestamp: str = Field(..., description="Prediction timestamp (ISO 8601)")
    model_version: str = Field(..., description="Model version used")
    predicted_class: str = Field(..., description="Predicted risk class (Low/Medium/High)")
    class_probabilities: Dict[str, float] = Field(..., description="Probability for each class")
    confidence: float = Field(..., ge=0, le=1, description="Confidence of prediction")
    feature_hash: str = Field(..., description="SHA256 hash of input features")
    status: str = Field(..., description="Prediction status (success/error)")

class ClaimPredictionResponse(BaseModel):
    """Response schema for Claim Outcome Prediction"""
    prediction_id: str = Field(..., description="Unique prediction identifier")
    timestamp: str = Field(..., description="Prediction timestamp (ISO 8601)")
    model_version: str = Field(..., description="Model version used")
    predicted_class: str = Field(..., description="Predicted claim status (Paid/Pending/Rejected)")
    class_probabilities: Dict[str, float] = Field(..., description="Probability for each class")
    confidence: float = Field(..., ge=0, le=1, description="Confidence of prediction")
    feature_hash: str = Field(..., description="SHA256 hash of input features")
    status: str = Field(..., description="Prediction status (success/error)")

class HealthCheckResponse(BaseModel):
    """Response schema for Health Check"""
    status: str = Field(..., description="Service status (healthy/unhealthy)")
    timestamp: str = Field(..., description="Check timestamp")
    version: str = Field(..., description="API version")
    models_loaded: Dict[str, bool] = Field(..., description="Status of loaded models")
    message: str = Field(..., description="Status message")

class ErrorResponse(BaseModel):
    """Response schema for Errors"""
    status: str = Field(default="error", description="Status")
    error_code: str = Field(..., description="Error code")
    message: str = Field(..., description="Error message")
    timestamp: str = Field(..., description="Error timestamp")
    details: Optional[str] = Field(None, description="Additional error details")

# ============================================================================
# MODEL MANAGER CLASS
# ============================================================================

class ModelManager:
    """Manages model loading, prediction, and versioning"""
    
    def __init__(self):
        self.models = {}
        self.scalers = {}
        self.encoders = {}
        self.loaded = False
        self.load_models()
    
    def load_models(self):
        """Load all models and artifacts"""
        try:
            logger.info("Starting model loading...")
            
            for model_name, config in MODEL_CONFIG.items():
                try:
                    # Load model
                    self.models[model_name] = joblib.load(config["model_path"])
                    logger.info(f"✓ Loaded {model_name} model from {config['model_path']}")
                    
                    # Load scaler
                    self.scalers[model_name] = joblib.load(config["scaler_path"])
                    logger.info(f"✓ Loaded {model_name} scaler from {config['scaler_path']}")
                    
                    # Load encoder
                    self.encoders[model_name] = joblib.load(config["encoder_path"])
                    logger.info(f"✓ Loaded {model_name} encoder from {config['encoder_path']}")
                    
                except FileNotFoundError as e:
                    logger.error(f"✗ Model file not found for {model_name}: {e}")
                    logger.warning(f"  - Expected: {config['model_path']}, {config['scaler_path']}, {config['encoder_path']}")
                except Exception as e:
                    logger.error(f"✗ Error loading {model_name}: {e}")
            
            self.loaded = all(m in self.models for m in MODEL_CONFIG.keys())
            
            if self.loaded:
                logger.info("✓ All models loaded successfully")
            else:
                missing = [m for m in MODEL_CONFIG.keys() if m not in self.models]
                logger.warning(f"⚠ Models not fully loaded. Missing: {missing}")
        
        except Exception as e:
            logger.error(f"✗ Critical error during model loading: {e}")
            logger.error(traceback.format_exc())
            self.loaded = False
    
    def predict_risk(self, request: RiskPredictionRequest) -> Tuple[str, Dict, float, str]:
        """Make risk prediction"""
        if "risk" not in self.models:
            raise ValueError("Risk model not loaded")
        
        try:
            # Prepare features DataFrame
            df = pd.DataFrame([request.dict()])
            
            # Apply one-hot encoding (same as training)
            df_encoded = pd.get_dummies(df, columns=FEATURE_CONFIG["risk"]["categorical"], drop_first=True)
            
            # Scale features
            X_scaled = self.scalers["risk"].transform(df_encoded)
            
            # Make prediction
            pred_class = self.models["risk"].predict(X_scaled)[0]
            pred_proba = self.models["risk"].predict_proba(X_scaled)[0]
            
            # Decode class
            pred_label = self.encoders["risk"].inverse_transform([pred_class])[0]
            
            # Get confidence
            confidence = float(max(pred_proba))
            
            # Class probabilities dictionary
            class_proba_dict = {
                cls: float(prob) 
                for cls, prob in zip(MODEL_CONFIG["risk"]["classes"], pred_proba)
            }
            
            # Feature hash
            feature_hash = self._compute_feature_hash(request.dict())
            
            return pred_label, class_proba_dict, confidence, feature_hash
        
        except Exception as e:
            logger.error(f"Error in risk prediction: {e}")
            logger.error(traceback.format_exc())
            raise
    
    def predict_claim(self, request: ClaimPredictionRequest) -> Tuple[str, Dict, float, str]:
        """Make claim prediction"""
        if "claim" not in self.models:
            raise ValueError("Claim model not loaded")
        
        try:
            # Prepare features DataFrame
            df = pd.DataFrame([request.dict()])
            
            # Apply one-hot encoding (same as training)
            df_encoded = pd.get_dummies(df, columns=FEATURE_CONFIG["claim"]["categorical"], drop_first=True)
            
            # Scale features
            X_scaled = self.scalers["claim"].transform(df_encoded)
            
            # Make prediction
            pred_class = self.models["claim"].predict(X_scaled)[0]
            pred_proba = self.models["claim"].predict_proba(X_scaled)[0]
            
            # Decode class
            pred_label = self.encoders["claim"].inverse_transform([pred_class])[0]
            
            # Get confidence
            confidence = float(max(pred_proba))
            
            # Class probabilities dictionary
            class_proba_dict = {
                cls: float(prob) 
                for cls, prob in zip(MODEL_CONFIG["claim"]["classes"], pred_proba)
            }
            
            # Feature hash
            feature_hash = self._compute_feature_hash(request.dict())
            
            return pred_label, class_proba_dict, confidence, feature_hash
        
        except Exception as e:
            logger.error(f"Error in claim prediction: {e}")
            logger.error(traceback.format_exc())
            raise
    
    @staticmethod
    def _compute_feature_hash(features_dict: dict) -> str:
        """Compute SHA256 hash of input features"""
        try:
            features_json = json.dumps(features_dict, sort_keys=True)
            return hashlib.sha256(features_json.encode()).hexdigest()
        except Exception as e:
            logger.error(f"Error computing feature hash: {e}")
            return "hash_computation_failed"

# ============================================================================
# FASTAPI APPLICATION SETUP
# ============================================================================

app = FastAPI(
    title="Hospital Data Management System - ML Predictions API",
    description="API for Risk Classification and Claim Outcome Predictions",
    version="1.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, restrict to specific origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize model manager
model_manager = ModelManager()

# ============================================================================
# API ENDPOINTS
# ============================================================================

@app.get("/health", response_model=HealthCheckResponse, tags=["Health Check"])
async def health_check():
    """
    Health check endpoint to verify service status and model availability
    
    Returns:
        HealthCheckResponse: Service health status and model status
    """
    try:
        models_loaded = {
            "risk_model": "risk" in model_manager.models,
            "claim_model": "claim" in model_manager.models,
            "risk_scaler": "risk" in model_manager.scalers,
            "claim_scaler": "claim" in model_manager.scalers,
        }
        
        all_loaded = all(models_loaded.values())
        status = "healthy" if all_loaded else "degraded"
        message = "All systems operational" if all_loaded else "Some models not loaded"
        
        logger.info(f"Health check - Status: {status}")
        
        return HealthCheckResponse(
            status=status,
            timestamp=datetime.now().isoformat(),
            version="1.0",
            models_loaded=models_loaded,
            message=message
        )
    
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        return HealthCheckResponse(
            status="unhealthy",
            timestamp=datetime.now().isoformat(),
            version="1.0",
            models_loaded={},
            message=str(e)
        )

@app.post("/predict/risk", response_model=RiskPredictionResponse, tags=["Predictions"])
async def predict_risk(request: RiskPredictionRequest, background_tasks: BackgroundTasks):
    """
    Predict hospital visit risk (Low/Medium/High)
    
    This endpoint evaluates a patient visit and predicts the clinical and operational risk level.
    
    Args:
        request: RiskPredictionRequest containing patient and visit information
    
    Returns:
        RiskPredictionResponse: Risk prediction with probabilities and confidence score
    
    Raises:
        HTTPException: If prediction fails or model is not available
    """
    prediction_id = f"risk_{datetime.now().strftime('%Y%m%d%H%M%S%f')}"
    timestamp = datetime.now().isoformat()
    
    try:
        if "risk" not in model_manager.models:
            raise HTTPException(status_code=503, detail="Risk model not loaded")
        
        # Make prediction
        pred_class, class_proba, confidence, feature_hash = model_manager.predict_risk(request)
        
        response = RiskPredictionResponse(
            prediction_id=prediction_id,
            timestamp=timestamp,
            model_version=MODEL_CONFIG["risk"]["version"],
            predicted_class=pred_class,
            class_probabilities=class_proba,
            confidence=confidence,
            feature_hash=feature_hash,
            status="success"
        )
        
        # Log prediction in background
        background_tasks.add_task(
            log_prediction,
            "risk",
            prediction_id,
            timestamp,
            pred_class,
            confidence,
            feature_hash
        )
        
        logger.info(f"Risk prediction successful: {prediction_id} -> {pred_class} ({confidence:.2%})")
        return response
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error in risk prediction: {e}")
        logger.error(traceback.format_exc())
        raise HTTPException(
            status_code=500,
            detail=f"Prediction failed: {str(e)}"
        )

@app.post("/predict/claim", response_model=ClaimPredictionResponse, tags=["Predictions"])
async def predict_claim(request: ClaimPredictionRequest, background_tasks: BackgroundTasks):
    """
    Predict insurance claim outcome (Paid/Pending/Rejected)
    
    This endpoint evaluates a claim and predicts the likely outcome status.
    
    Args:
        request: ClaimPredictionRequest containing claim and financial information
    
    Returns:
        ClaimPredictionResponse: Claim prediction with probabilities and confidence score
    
    Raises:
        HTTPException: If prediction fails or model is not available
    """
    prediction_id = f"claim_{datetime.now().strftime('%Y%m%d%H%M%S%f')}"
    timestamp = datetime.now().isoformat()
    
    try:
        if "claim" not in model_manager.models:
            raise HTTPException(status_code=503, detail="Claim model not loaded")
        
        # Make prediction
        pred_class, class_proba, confidence, feature_hash = model_manager.predict_claim(request)
        
        response = ClaimPredictionResponse(
            prediction_id=prediction_id,
            timestamp=timestamp,
            model_version=MODEL_CONFIG["claim"]["version"],
            predicted_class=pred_class,
            class_probabilities=class_proba,
            confidence=confidence,
            feature_hash=feature_hash,
            status="success"
        )
        
        # Log prediction in background
        background_tasks.add_task(
            log_prediction,
            "claim",
            prediction_id,
            timestamp,
            pred_class,
            confidence,
            feature_hash
        )
        
        logger.info(f"Claim prediction successful: {prediction_id} -> {pred_class} ({confidence:.2%})")
        return response
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error in claim prediction: {e}")
        logger.error(traceback.format_exc())
        raise HTTPException(
            status_code=500,
            detail=f"Prediction failed: {str(e)}"
        )

@app.get("/", tags=["Info"])
async def root():
    """Root endpoint with API information"""
    return {
        "name": "Hospital Data Management System - ML Predictions API",
        "version": "1.0",
        "status": "running",
        "models": {
            "risk": "Visit Risk Classification (Low/Medium/High)",
            "claim": "Claim Outcome Prediction (Paid/Pending/Rejected)"
        },
        "endpoints": {
            "health": "/health",
            "predict_risk": "/predict/risk",
            "predict_claim": "/predict/claim",
            "docs": "/docs",
            "openapi": "/openapi.json"
        },
        "timestamp": datetime.now().isoformat()
    }

# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

def log_prediction(model_type: str, prediction_id: str, timestamp: str, 
                   predicted_class: str, confidence: float, feature_hash: str):
    """
    Log prediction with details for audit and monitoring
    
    Args:
        model_type: Type of model (risk or claim)
        prediction_id: Unique prediction identifier
        timestamp: Prediction timestamp
        predicted_class: Predicted class label
        confidence: Confidence score
        feature_hash: SHA256 hash of input features
    """
    try:
        log_entry = {
            "timestamp": timestamp,
            "prediction_id": prediction_id,
            "model_type": model_type,
            "model_version": MODEL_CONFIG[model_type]["version"],
            "predicted_class": predicted_class,
            "confidence": f"{confidence:.4f}",
            "feature_hash": feature_hash
        }
        
        prediction_logger.info(json.dumps(log_entry))
    
    except Exception as e:
        logger.error(f"Error logging prediction: {e}")

# ============================================================================
# EXCEPTION HANDLERS
# ============================================================================

@app.exception_handler(HTTPException)
async def http_exception_handler(request, exc):
    """Custom HTTP exception handler"""
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "status": "error",
            "error_code": "HTTP_ERROR",
            "message": exc.detail,
            "timestamp": datetime.now().isoformat()
        }
    )

@app.exception_handler(Exception)
async def general_exception_handler(request, exc):
    """General exception handler"""
    logger.error(f"Unhandled exception: {exc}")
    logger.error(traceback.format_exc())
    
    return JSONResponse(
        status_code=500,
        content={
            "status": "error",
            "error_code": "INTERNAL_SERVER_ERROR",
            "message": "An unexpected error occurred",
            "timestamp": datetime.now().isoformat()
        }
    )

# ============================================================================
# STARTUP AND SHUTDOWN EVENTS
# ============================================================================

@app.on_event("startup")
async def startup_event():
    """Startup event handler"""
    logger.info("=" * 80)
    logger.info("Hospital Data Management System - ML Predictions API")
    logger.info("=" * 80)
    logger.info(f"Startup time: {datetime.now().isoformat()}")
    logger.info(f"Model status: {model_manager.loaded}")
    logger.info("Ready to serve predictions")
    logger.info("=" * 80)

@app.on_event("shutdown")
async def shutdown_event():
    """Shutdown event handler"""
    logger.info("=" * 80)
    logger.info("Shutting down API service")
    logger.info(f"Shutdown time: {datetime.now().isoformat()}")
    logger.info("=" * 80)

# ============================================================================
# MAIN ENTRY POINT
# ============================================================================

if __name__ == "__main__":
    # Run with uvicorn
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=False,
        log_level="info"
    )
