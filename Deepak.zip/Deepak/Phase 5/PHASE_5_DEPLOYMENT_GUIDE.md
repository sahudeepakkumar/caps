# Phase 5: Deployment and Operations Runbook
## Hospital Data Management System - ML Predictions API

**Date:** 2026-06-13  
**Version:** 1.0  
**API Service Version:** 1.0  

---

## Table of Contents

1. [Executive Summary](#executive-summary)
2. [Prerequisites and Requirements](#prerequisites)
3. [Local Development Setup](#local-setup)
4. [Docker Deployment](#docker-deployment)
5. [Production Deployment](#production-deployment)
6. [API Configuration](#api-configuration)
7. [Monitoring and Logging](#monitoring)
8. [Health Checks and Troubleshooting](#health-checks)
9. [Security Considerations](#security)
10. [Scaling and Performance](#scaling)
11. [Maintenance and Updates](#maintenance)
12. [Runbook Procedures](#runbook)

---

<a name="executive-summary"></a>
## 1. Executive Summary

This deployment guide provides complete instructions for deploying the Hospital Data Management System ML Predictions API in various environments (development, testing, production).

**Key Components:**
- **FastAPI Application** (`main.py`) - REST API service for model predictions
- **Docker Container** (`Dockerfile`) - Containerized deployment
- **Python Dependencies** (`requirements.txt`) - Required packages
- **Model Artifacts** - Pre-trained Risk and Claim prediction models
- **Logging System** - Comprehensive prediction and system logging

**Service Capabilities:**
- ✓ Real-time visit risk prediction (Low/Medium/High)
- ✓ Real-time claim outcome prediction (Paid/Pending/Rejected)
- ✓ Health check endpoints for monitoring
- ✓ Request/response validation via Pydantic schemas
- ✓ Comprehensive prediction logging with feature hashing
- ✓ Feature importance and explainability integration
- ✓ CORS support for dashboard integration
- ✓ Automatic error handling and recovery

**API Endpoints:**
```
GET  /                    - API info and documentation
GET  /health              - Service health status
POST /predict/risk        - Risk classification prediction
POST /predict/claim       - Claim outcome prediction
GET  /docs                - Interactive API documentation (Swagger)
GET  /redoc               - Alternative API documentation (ReDoc)
```

---

<a name="prerequisites"></a>
## 2. Prerequisites and Requirements

### 2.1 System Requirements

**Minimum:**
- CPU: 2 cores (4+ recommended)
- RAM: 2GB (4GB+ recommended)
- Storage: 5GB free space
- OS: Linux (Ubuntu 20.04+), Windows 10/11, macOS 10.14+

**Recommended (Production):**
- CPU: 4+ cores
- RAM: 8GB+
- Storage: 20GB+ SSD
- OS: Ubuntu 20.04 LTS or equivalent

### 2.2 Software Requirements

**Required:**
- Python 3.10+
- pip (Python package manager)
- Docker 20.10+ (for containerized deployment)
- Git (for version control)

**Optional:**
- Docker Compose (for multi-container orchestration)
- Kubernetes 1.21+ (for production orchestration)
- NVIDIA Docker (if GPU acceleration needed)

### 2.3 Model Artifacts

Place the following files in the project directory before deployment:

```
├── 02_risk_model.joblib
├── risk_model_scaler.joblib
├── risk_model_label_encoder.joblib
├── 03_claim_model.joblib
├── claim_model_scaler.joblib
├── claim_model_label_encoder.joblib
└── claim_model_smote.joblib (optional, for reference)
```

**File Locations (Expected):**
```
Current Directory: c:\Users\sahud\OneDrive\Documents\IITM-Pravartak\Capstone Project\
```

### 2.4 Environment Variables

Create a `.env` file in the project directory:

```bash
# API Configuration
API_HOST=0.0.0.0
API_PORT=8000
API_RELOAD=false
API_LOG_LEVEL=info

# Model Configuration
MODEL_PATH=./
LOG_PATH=./logs

# Environment
ENVIRONMENT=development  # or production

# CORS (adjust for production)
CORS_ORIGINS=["*"]
```

---

<a name="local-setup"></a>
## 3. Local Development Setup

### 3.1 Clone and Setup Repository

```bash
# Navigate to project directory
cd c:\Users\sahud\OneDrive\Documents\IITM-Pravartak\Capstone Project\

# Verify required files exist
ls -la main.py requirements.txt Dockerfile *.joblib
```

### 3.2 Create Virtual Environment

**Windows (PowerShell):**
```powershell
# Create virtual environment
python -m venv venv

# Activate virtual environment
.\venv\Scripts\Activate.ps1

# Upgrade pip
python -m pip install --upgrade pip
```

**Linux/macOS (Bash):**
```bash
# Create virtual environment
python3 -m venv venv

# Activate virtual environment
source venv/bin/activate

# Upgrade pip
pip install --upgrade pip
```

### 3.3 Install Dependencies

```bash
# Install required packages
pip install -r requirements.txt

# Verify installation
pip list
```

### 3.4 Run API Service Locally

```bash
# Start the FastAPI service
python main.py

# Expected output:
# Started server process
# Uvicorn running on http://0.0.0.0:8000
# Application startup complete
```

### 3.5 Verify API is Running

**Test Health Endpoint:**
```bash
# Using curl
curl http://localhost:8000/health

# Using Python
python -c "import httpx; print(httpx.get('http://localhost:8000/health').json())"
```

### 3.6 Access API Documentation

- **Swagger UI:** http://localhost:8000/docs
- **ReDoc:** http://localhost:8000/redoc
- **OpenAPI JSON:** http://localhost:8000/openapi.json

---

<a name="docker-deployment"></a>
## 4. Docker Deployment

### 4.1 Build Docker Image

```bash
# Build image (from project directory)
docker build -t hospital-ml-api:1.0 .

# Build with custom tag
docker build -t hospital-ml-api:latest -t hospital-ml-api:1.0 .

# Verify image was built
docker images | grep hospital-ml-api
```

### 4.2 Run Docker Container (Development)

```bash
# Run container with model artifacts mounted
docker run \
  --name hospital-ml-api \
  -p 8000:8000 \
  -v $(pwd):/app/models \
  -e ENVIRONMENT=development \
  hospital-ml-api:1.0

# Linux/macOS equivalent
docker run \
  --name hospital-ml-api \
  -p 8000:8000 \
  -v $(pwd):/app/models \
  -e ENVIRONMENT=development \
  hospital-ml-api:1.0
```

### 4.3 Run Docker Container (Production)

```bash
# Run container in detached mode with health checks
docker run \
  --name hospital-ml-api-prod \
  -p 8000:8000 \
  -v /path/to/models:/app/models \
  -v /path/to/logs:/app/logs \
  -e ENVIRONMENT=production \
  --restart unless-stopped \
  --health-cmd='curl --fail http://localhost:8000/health || exit 1' \
  --health-interval=30s \
  --health-timeout=10s \
  --health-retries=3 \
  hospital-ml-api:1.0
```

### 4.4 Docker Compose Setup

Create `docker-compose.yml`:

```yaml
version: '3.8'

services:
  hospital-ml-api:
    build:
      context: .
      dockerfile: Dockerfile
    container_name: hospital-ml-api
    ports:
      - "8000:8000"
    volumes:
      - ./models:/app/models
      - ./logs:/app/logs
    environment:
      - ENVIRONMENT=production
      - API_LOG_LEVEL=info
    restart: unless-stopped
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8000/health"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 40s
    networks:
      - ml-network

networks:
  ml-network:
    driver: bridge
```

**Run with Docker Compose:**
```bash
# Start services
docker-compose up -d

# View logs
docker-compose logs -f hospital-ml-api

# Stop services
docker-compose down
```

### 4.5 Container Management Commands

```bash
# View running containers
docker ps

# View container logs
docker logs -f hospital-ml-api-prod

# Stop container
docker stop hospital-ml-api-prod

# Start container
docker start hospital-ml-api-prod

# Remove container
docker rm hospital-ml-api-prod

# Access container shell
docker exec -it hospital-ml-api-prod /bin/bash

# Inspect container details
docker inspect hospital-ml-api-prod
```

---

<a name="production-deployment"></a>
## 5. Production Deployment

### 5.1 Kubernetes Deployment (Recommended)

**Create `kubernetes-deployment.yaml`:**

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: hospital-ml-api
  namespace: production
spec:
  replicas: 3
  selector:
    matchLabels:
      app: hospital-ml-api
  template:
    metadata:
      labels:
        app: hospital-ml-api
    spec:
      containers:
      - name: hospital-ml-api
        image: hospital-ml-api:1.0
        imagePullPolicy: IfNotPresent
        ports:
        - containerPort: 8000
        env:
        - name: ENVIRONMENT
          value: "production"
        - name: API_LOG_LEVEL
          value: "info"
        resources:
          requests:
            memory: "512Mi"
            cpu: "500m"
          limits:
            memory: "2Gi"
            cpu: "2000m"
        livenessProbe:
          httpGet:
            path: /health
            port: 8000
          initialDelaySeconds: 40
          periodSeconds: 10
          timeoutSeconds: 5
          failureThreshold: 3
        readinessProbe:
          httpGet:
            path: /health
            port: 8000
          initialDelaySeconds: 30
          periodSeconds: 5
          timeoutSeconds: 3
          failureThreshold: 2
        volumeMounts:
        - name: models
          mountPath: /app/models
        - name: logs
          mountPath: /app/logs
      volumes:
      - name: models
        configMap:
          name: ml-models
      - name: logs
        emptyDir: {}

---
apiVersion: v1
kind: Service
metadata:
  name: hospital-ml-api-service
  namespace: production
spec:
  selector:
    app: hospital-ml-api
  type: LoadBalancer
  ports:
  - protocol: TCP
    port: 80
    targetPort: 8000
```

**Deploy to Kubernetes:**
```bash
# Create namespace
kubectl create namespace production

# Deploy application
kubectl apply -f kubernetes-deployment.yaml

# Verify deployment
kubectl get deployments -n production
kubectl get pods -n production
kubectl get service -n production

# View logs
kubectl logs -f deployment/hospital-ml-api -n production

# Scale replicas
kubectl scale deployment hospital-ml-api --replicas=5 -n production
```

### 5.2 Load Balancing Setup

**Nginx Configuration (`nginx.conf`):**

```nginx
upstream hospital_ml_api {
    server localhost:8000;
    server localhost:8001;
    server localhost:8002;
    keepalive 32;
}

server {
    listen 80;
    server_name hospital-api.internal;

    location / {
        proxy_pass http://hospital_ml_api;
        proxy_http_version 1.1;
        proxy_set_header Connection "";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # Timeouts for long requests
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }

    # Health check endpoint
    location /health {
        proxy_pass http://hospital_ml_api;
        access_log off;
    }
}
```

### 5.3 SSL/TLS Configuration

```nginx
server {
    listen 443 ssl http2;
    server_name hospital-api.example.com;

    ssl_certificate /etc/ssl/certs/hospital-api.crt;
    ssl_certificate_key /etc/ssl/private/hospital-api.key;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;

    location / {
        proxy_pass http://hospital_ml_api;
        proxy_set_header X-Forwarded-Proto https;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}

# Redirect HTTP to HTTPS
server {
    listen 80;
    server_name hospital-api.example.com;
    return 301 https://$server_name$request_uri;
}
```

---

<a name="api-configuration"></a>
## 6. API Configuration

### 6.1 Environment Variables Reference

| Variable | Default | Purpose |
|----------|---------|---------|
| `API_HOST` | 0.0.0.0 | Bind address |
| `API_PORT` | 8000 | Port number |
| `API_RELOAD` | false | Auto-reload on file changes (dev only) |
| `API_LOG_LEVEL` | info | Logging level (debug/info/warning/error) |
| `ENVIRONMENT` | development | Environment type |
| `CORS_ORIGINS` | ["*"] | Allowed CORS origins |
| `MODEL_PATH` | ./ | Model artifacts directory |
| `LOG_PATH` | ./logs | Logs directory |

### 6.2 Startup Configuration

**Fine-tune startup parameters in `main.py`:**

```python
if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host=os.getenv("API_HOST", "0.0.0.0"),
        port=int(os.getenv("API_PORT", 8000)),
        reload=os.getenv("API_RELOAD", "false").lower() == "true",
        log_level=os.getenv("API_LOG_LEVEL", "info"),
        workers=4,  # For production
        ssl_keyfile="/path/to/key.pem",  # For HTTPS
        ssl_certfile="/path/to/cert.pem"
    )
```

### 6.3 Model Loading Configuration

Models are automatically loaded from the configured `MODEL_PATH` on startup:

```python
MODEL_CONFIG = {
    "risk": {
        "model_path": "02_risk_model.joblib",
        "scaler_path": "risk_model_scaler.joblib",
        "encoder_path": "risk_model_label_encoder.joblib",
        "version": "1.0",
    },
    "claim": {
        "model_path": "03_claim_model.joblib",
        "scaler_path": "claim_model_scaler.joblib",
        "encoder_path": "claim_model_label_encoder.joblib",
        "version": "1.0",
    }
}
```

---

<a name="monitoring"></a>
## 7. Monitoring and Logging

### 7.1 Prediction Logging

**Logs Location:** `logs/predictions_*.log`

**Log Format:**
```json
{
  "timestamp": "2026-06-13T10:30:45.123456",
  "prediction_id": "risk_20260613103045123456",
  "model_type": "risk",
  "model_version": "1.0",
  "predicted_class": "High",
  "confidence": "0.8765",
  "feature_hash": "a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6"
}
```

### 7.2 System Logging

**Logs Location:** `logs/api_service_*.log`

**View Live Logs:**
```bash
# Follow logs in real-time
tail -f logs/api_service_*.log

# Filter by level
grep ERROR logs/api_service_*.log
grep WARNING logs/api_service_*.log

# Count predictions
wc -l logs/predictions_*.log
```

### 7.3 Monitoring Metrics

**Key Metrics to Monitor:**

```
1. API Availability
   - HTTP 2xx response rate (target: >99.5%)
   - HTTP error rate (target: <0.5%)
   - Average response time (target: <500ms)

2. Model Performance
   - Prediction latency (target: <200ms)
   - Model confidence distribution
   - Prediction error rate (by comparing with actual outcomes)

3. System Health
   - CPU usage (target: <70%)
   - Memory usage (target: <80%)
   - Disk I/O
   - Network throughput

4. Business Metrics
   - Predictions per minute
   - Risk class distribution
   - Claim outcome distribution
   - Cost avoidance (Rejected claims detected)
```

### 7.4 Setting Up Monitoring (Prometheus + Grafana)

**Prometheus Configuration (`prometheus.yml`):**

```yaml
global:
  scrape_interval: 15s
  evaluation_interval: 15s

scrape_configs:
  - job_name: 'hospital-ml-api'
    static_configs:
      - targets: ['localhost:8000']
    metrics_path: '/metrics'
    scrape_interval: 10s
```

**Grafana Dashboard:**
- Import JSON dashboard for Hospital ML API
- Set up alerts for high error rates
- Create alerts for model performance degradation

---

<a name="health-checks"></a>
## 8. Health Checks and Troubleshooting

### 8.1 Health Check Endpoint

**Request:**
```bash
curl -X GET http://localhost:8000/health
```

**Expected Response (Healthy):**
```json
{
  "status": "healthy",
  "timestamp": "2026-06-13T10:30:45.123456",
  "version": "1.0",
  "models_loaded": {
    "risk_model": true,
    "claim_model": true,
    "risk_scaler": true,
    "claim_scaler": true
  },
  "message": "All systems operational"
}
```

**Expected Response (Degraded):**
```json
{
  "status": "degraded",
  "timestamp": "2026-06-13T10:30:45.123456",
  "version": "1.0",
  "models_loaded": {
    "risk_model": true,
    "claim_model": false,
    "risk_scaler": true,
    "claim_scaler": false
  },
  "message": "Some models not loaded"
}
```

### 8.2 Common Issues and Solutions

**Issue 1: Model Files Not Found**

```
Error: FileNotFoundError: [Errno 2] No such file or directory: '02_risk_model.joblib'
```

**Solution:**
1. Verify model files exist in project directory
2. Check file paths in `MODEL_CONFIG`
3. Verify model files have correct permissions (readable)
4. Run from correct directory:
   ```bash
   cd c:\Users\sahud\OneDrive\Documents\IITM-Pravartak\Capstone Project\
   python main.py
   ```

**Issue 2: Port Already in Use**

```
Error: Address already in use: ('0.0.0.0', 8000)
```

**Solution:**
```bash
# Find process using port 8000
lsof -i :8000  # Linux/macOS
netstat -ano | findstr :8000  # Windows

# Kill process
kill -9 <PID>  # Linux/macOS
taskkill /PID <PID> /F  # Windows

# Use different port
python main.py --port 8001
# Or modify uvicorn.run() call
```

**Issue 3: Insufficient Memory**

```
Error: MemoryError or slow predictions
```

**Solution:**
1. Increase available memory
2. Reduce number of workers
3. Enable request queuing
4. Monitor memory usage:
   ```bash
   docker stats hospital-ml-api-prod
   ```

**Issue 4: Prediction Failures**

```
Error: Prediction failed: [details]
```

**Solution:**
1. Check logs: `tail -f logs/api_service_*.log`
2. Verify input schema matches expected format
3. Check for missing features in request
4. Validate feature values (ranges, types)
5. Test with sample request from documentation

### 8.3 Debugging Mode

**Enable debug logging:**

```bash
# Set log level to debug
export API_LOG_LEVEL=debug
python main.py

# Or in Windows PowerShell
$env:API_LOG_LEVEL = "debug"
python main.py
```

---

<a name="security"></a>
## 9. Security Considerations

### 9.1 Authentication and Authorization

**Current Status:** Basic auth recommended for production

**Implementation Example (JWT):**

```python
from fastapi.security import HTTPBearer, HTTPAuthCredentials
from fastapi import Security

security = HTTPBearer()

@app.post("/predict/risk")
async def predict_risk(
    request: RiskPredictionRequest,
    credentials: HTTPAuthCredentials = Security(security)
):
    # Verify token
    if not verify_token(credentials.credentials):
        raise HTTPException(status_code=401, detail="Invalid token")
    
    # Continue with prediction
    ...
```

### 9.2 Input Validation

**Currently Implemented:**
- Pydantic schema validation
- Type checking
- Range validation for numeric fields
- Enum validation for categorical fields

**Additional Checks (if needed):**
```python
@app.post("/predict/risk")
async def predict_risk(request: RiskPredictionRequest):
    # Additional validation
    if request.age > 150:
        raise HTTPException(status_code=422, detail="Invalid age")
    
    if request.billed_amount < 0:
        raise HTTPException(status_code=422, detail="Negative amount")
```

### 9.3 API Rate Limiting

**Install SlowAPI:**
```bash
pip install slowapi
```

**Implement Rate Limiting:**

```python
from slowapi import Limiter
from slowapi.util import get_remote_address

limiter = Limiter(key_func=get_remote_address)
app.state.limiter = limiter

@app.post("/predict/risk")
@limiter.limit("100/minute")
async def predict_risk(request: RiskPredictionRequest):
    ...
```

### 9.4 HTTPS/TLS Configuration

**Enable HTTPS:**

```python
uvicorn.run(
    "main:app",
    ssl_keyfile="/path/to/private.key",
    ssl_certfile="/path/to/certificate.crt",
    host="0.0.0.0",
    port=443
)
```

### 9.5 Security Headers

**Add to Nginx configuration:**

```nginx
add_header X-Content-Type-Options "nosniff";
add_header X-Frame-Options "DENY";
add_header X-XSS-Protection "1; mode=block";
add_header Referrer-Policy "no-referrer";
add_header Strict-Transport-Security "max-age=31536000; includeSubDomains";
```

### 9.6 CORS Configuration

**Current (Development):**
```python
CORSMiddleware(
    allow_origins=["*"],  # Allow all origins
    allow_methods=["*"],
    allow_headers=["*"]
)
```

**Production (Restricted):**
```python
CORSMiddleware(
    allow_origins=[
        "https://dashboard.hospital.internal",
        "https://finance.hospital.internal"
    ],
    allow_credentials=True,
    allow_methods=["GET", "POST"],
    allow_headers=["Content-Type", "Authorization"]
)
```

---

<a name="scaling"></a>
## 10. Scaling and Performance

### 10.1 Horizontal Scaling

**Multiple Workers (Linux/macOS):**

```bash
# Using Gunicorn with Uvicorn workers
gunicorn main:app --workers 4 --worker-class uvicorn.workers.UvicornWorker --bind 0.0.0.0:8000
```

**Multiple Instances (Docker):**

```bash
# Run multiple instances on different ports
for port in 8000 8001 8002 8003; do
  docker run -d \
    -p $port:8000 \
    --name hospital-ml-api-$port \
    hospital-ml-api:1.0
done

# Behind Nginx load balancer
```

### 10.2 Vertical Scaling

**Increase Machine Resources:**
- Add CPU cores
- Increase RAM
- Use SSD storage
- Consider GPU acceleration (if available)

### 10.3 Performance Optimization

**Optimize Model Loading:**
```python
# Use memory-mapped files for large models
model = joblib.load(model_path, mmap_mode='r')
```

**Cache Preprocessing:**
```python
# Pre-compute encoding mappings
ENCODING_CACHE = {}

# Use in predictions
if features_key in ENCODING_CACHE:
    X_encoded = ENCODING_CACHE[features_key]
```

**Connection Pooling:**
```python
# Reuse database connections
from sqlalchemy.pool import QueuePool
```

---

<a name="maintenance"></a>
## 11. Maintenance and Updates

### 11.1 Regular Maintenance Tasks

**Daily:**
- [ ] Check API health status
- [ ] Review error logs
- [ ] Monitor prediction volumes

**Weekly:**
- [ ] Analyze prediction metrics
- [ ] Check model performance
- [ ] Review system resource usage
- [ ] Back up logs

**Monthly:**
- [ ] Audit access logs
- [ ] Performance review
- [ ] Security scan
- [ ] Plan updates if needed

### 11.2 Model Updates

**When to Update:**
1. Model accuracy drops >5%
2. New feature patterns detected
3. Fairness issues identified
4. Business requirements change

**Update Process:**

```bash
# 1. Test new model in staging
docker build -t hospital-ml-api:staging .
docker-compose -f docker-compose.staging.yml up -d

# 2. Run integration tests
pytest tests/integration_tests.py

# 3. Perform A/B testing
# - Route % of traffic to staging
# - Compare metrics
# - If successful, promote to production

# 4. Update production
docker build -t hospital-ml-api:1.1 .
# Rolling update in Kubernetes:
kubectl set image deployment/hospital-ml-api \
  hospital-ml-api=hospital-ml-api:1.1 -n production
```

### 11.3 Backup and Recovery

**Backup Critical Files:**

```bash
# Backup models and logs
tar -czf backup_$(date +%Y%m%d_%H%M%S).tar.gz \
  *.joblib \
  logs/

# Backup to cloud storage
aws s3 cp backup_*.tar.gz s3://backups/hospital-ml-api/
```

**Disaster Recovery:**

```bash
# Restore from backup
tar -xzf backup_20260613_000000.tar.gz
docker-compose up -d

# Verify health
curl http://localhost:8000/health
```

---

<a name="runbook"></a>
## 12. Runbook Procedures

### 12.1 Deployment Checklist

**Pre-Deployment:**
- [ ] Verify all model files present
- [ ] Run unit tests: `pytest tests/`
- [ ] Check code quality: `pylint main.py`
- [ ] Security scan: `safety check`
- [ ] Review changes: `git diff main`

**Deployment:**
- [ ] Build Docker image: `docker build -t hospital-ml-api:1.0 .`
- [ ] Push to registry: `docker push registry.internal/hospital-ml-api:1.0`
- [ ] Update Kubernetes manifests
- [ ] Apply changes: `kubectl apply -f k8s/`
- [ ] Monitor rollout: `kubectl rollout status deployment/hospital-ml-api`

**Post-Deployment:**
- [ ] Verify health: `curl /health`
- [ ] Run smoke tests
- [ ] Check logs for errors
- [ ] Monitor metrics dashboard
- [ ] Notify stakeholders

### 12.2 Emergency Procedures

**API Service Down:**

```bash
# 1. Check service status
docker ps | grep hospital-ml-api
kubectl get pods -n production

# 2. View error logs
docker logs hospital-ml-api-prod
kubectl logs deployment/hospital-ml-api -n production

# 3. Restart service
docker restart hospital-ml-api-prod
# OR
kubectl rollout restart deployment/hospital-ml-api -n production

# 4. Verify recovery
curl http://localhost:8000/health
watch kubectl get pods -n production
```

**High Error Rate:**

```bash
# 1. Check logs for error pattern
grep ERROR logs/api_service_*.log | tail -20

# 2. Check model files
ls -la *.joblib

# 3. Reload models
# Restart service (models are loaded on startup)
docker restart hospital-ml-api-prod

# 4. Fallback to previous version if necessary
docker run ... hospital-ml-api:previous-stable
```

**Out of Memory:**

```bash
# 1. Check memory usage
docker stats hospital-ml-api-prod

# 2. Increase container memory limits
docker update --memory 4g hospital-ml-api-prod

# 3. Or in Kubernetes
kubectl set resources deployment hospital-ml-api \
  --limits=memory=4Gi -n production

# 4. Monitor memory after update
docker stats hospital-ml-api-prod
```

### 12.3 Rollback Procedure

**If New Deployment Has Issues:**

```bash
# 1. Identify previous stable version
docker images hospital-ml-api

# 2. Revert to previous version
docker run ... hospital-ml-api:1.0-stable

# 3. Or in Kubernetes
kubectl rollout undo deployment/hospital-ml-api -n production

# 4. Verify rollback
kubectl rollout status deployment/hospital-ml-api -n production
curl http://localhost:8000/health
```

### 12.4 Escalation Procedure

| Issue | Severity | Escalation |
|-------|----------|------------|
| API unavailable | CRITICAL | Page on-call engineer immediately |
| High error rate (>5%) | HIGH | Alert ops team, investigate immediately |
| High latency (>1s) | MEDIUM | Create ticket, investigate within 1 hour |
| Degraded performance | LOW | Monitor, investigate within 24 hours |

---

## Quick Reference

**Start Development Server:**
```bash
cd c:\Users\sahud\OneDrive\Documents\IITM-Pravartak\Capstone Project\
python main.py
```

**Start Docker Container:**
```bash
docker run -p 8000:8000 -v $(pwd):/app/models hospital-ml-api:1.0
```

**Test Prediction:**
```bash
curl -X POST http://localhost:8000/predict/risk \
  -H "Content-Type: application/json" \
  -d '{"age": 45, "gender": "M", ...}'
```

**View Health Status:**
```bash
curl http://localhost:8000/health
```

**Access API Documentation:**
- http://localhost:8000/docs (Swagger UI)
- http://localhost:8000/redoc (ReDoc)

---

**Document Version:** 1.0  
**Last Updated:** 2026-06-13  
**Next Review:** 2026-07-13  

