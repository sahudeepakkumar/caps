# Phase 5: API Documentation and Integration Guide
## Hospital Data Management System - ML Predictions API

**Date:** 2026-06-13  
**Version:** 1.0  
**API Base URL:** `http://localhost:8000` (development) / `https://hospital-api.internal` (production)

---

## Table of Contents

1. [Overview](#overview)
2. [Authentication](#authentication)
3. [API Endpoints](#endpoints)
4. [Request and Response Schemas](#schemas)
5. [Sample Requests and Responses](#samples)
6. [Error Handling](#error-handling)
7. [Integration Examples](#integration)
8. [Best Practices](#best-practices)
9. [Troubleshooting](#troubleshooting)

---

<a name="overview"></a>
## 1. Overview

### 1.1 API Purpose

The Hospital Data Management System API provides real-time predictions for:
1. **Risk Classification** - Hospital visit risk assessment (Low/Medium/High)
2. **Claim Outcome Prediction** - Insurance claim status prediction (Paid/Pending/Rejected)

### 1.2 Base Information

| Property | Value |
|----------|-------|
| **API Version** | 1.0 |
| **Base URL** | `http://localhost:8000` |
| **Protocol** | HTTP/HTTPS (HTTPS required for production) |
| **Content-Type** | application/json |
| **Response Format** | JSON |
| **Rate Limit** | 100 requests/minute (configurable) |

### 1.3 OpenAPI/Swagger Documentation

- **Interactive Documentation:** `GET /docs`
- **Alternative Documentation:** `GET /redoc`
- **OpenAPI Spec:** `GET /openapi.json`

---

<a name="authentication"></a>
## 2. Authentication

### 2.1 Current Status (Development)

Currently, the API uses **no authentication** for development purposes.

### 2.2 Production Authentication (Recommended)

For production deployment, implement one of the following:

**Option A: API Key Authentication**

```python
from fastapi import Depends, HTTPException
from fastapi.security import APIKeyHeader

api_key_header = APIKeyHeader(name="X-API-Key")

async def verify_api_key(api_key: str = Depends(api_key_header)):
    if api_key not in VALID_API_KEYS:
        raise HTTPException(status_code=403, detail="Invalid API key")
    return api_key

@app.post("/predict/risk")
async def predict_risk(request: RiskPredictionRequest, api_key: str = Depends(verify_api_key)):
    ...
```

**Usage with API Key:**
```bash
curl -X POST http://localhost:8000/predict/risk \
  -H "Content-Type: application/json" \
  -H "X-API-Key: your-api-key-here" \
  -d '{...}'
```

**Option B: JWT Token Authentication**

```python
from fastapi.security import HTTPBearer, HTTPAuthCredentials
from jose import JWTError, jwt

security = HTTPBearer()

async def verify_token(credentials: HTTPAuthCredentials = Depends(security)):
    try:
        payload = jwt.decode(credentials.credentials, "secret", algorithms=["HS256"])
        return payload
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid token")

@app.post("/predict/risk")
async def predict_risk(request: RiskPredictionRequest, payload = Depends(verify_token)):
    ...
```

---

<a name="endpoints"></a>
## 3. API Endpoints

### 3.1 Health Check Endpoint

**Endpoint:** `GET /health`

**Purpose:** Check API service status and model availability

**Request:**
```bash
curl -X GET http://localhost:8000/health
```

**Response Status:** 200 OK

---

### 3.2 Risk Classification Endpoint

**Endpoint:** `POST /predict/risk`

**Purpose:** Predict hospital visit risk level

**Authentication:** (Optional in development, required in production)

**Rate Limit:** 100 requests/minute

**Request Headers:**
```
Content-Type: application/json
```

**Response Status:** 200 OK (success), 400 (validation error), 503 (model not loaded)

---

### 3.3 Claim Outcome Endpoint

**Endpoint:** `POST /predict/claim`

**Purpose:** Predict insurance claim outcome status

**Authentication:** (Optional in development, required in production)

**Rate Limit:** 100 requests/minute

**Request Headers:**
```
Content-Type: application/json
```

**Response Status:** 200 OK (success), 400 (validation error), 503 (model not loaded)

---

### 3.4 API Documentation Endpoints

| Endpoint | Format | Purpose |
|----------|--------|---------|
| `GET /docs` | HTML (Swagger) | Interactive API documentation |
| `GET /redoc` | HTML (ReDoc) | Alternative API documentation |
| `GET /openapi.json` | JSON | OpenAPI specification |

---

<a name="schemas"></a>
## 4. Request and Response Schemas

### 4.1 Risk Prediction Request Schema

**Endpoint:** `POST /predict/risk`

**Content-Type:** `application/json`

**Required Fields:** All

**Schema:**

```json
{
  "age": 45,                              // int (0-120)
  "gender": "M",                          // str (M/F/Other)
  "chronic_flag": 1,                      // int (0/1)
  "city": "Delhi",                        // str
  "visit_type": "ER",                     // str (OPD/ER/ICU)
  "department": "Cardiology",             // str
  "length_of_stay_hours": 24.5,          // float (>=0)
  "visit_frequency": 3,                   // int (>=0)
  "avg_los_per_patient": 18.2,           // float (>=0)
  "days_since_registration": 365,         // int (>=0)
  "billed_amount": 5000.0,               // float (>=0)
  "revenue_realization_ratio": 0.95,     // float (0-1)
  "insurance_provider": "ICICI Health",  // str
  "provider_rejection_rate": 5.2,        // float (0-100)
  "visit_month": 6,                       // int (1-12)
  "visit_quarter": 2,                     // int (1-4)
  "visit_day_of_week": "Monday"          // str (Mon-Sun)
}
```

**Field Descriptions:**

| Field | Type | Range | Description |
|-------|------|-------|-------------|
| age | int | 0-120 | Patient age in years |
| gender | str | M/F/Other | Patient gender |
| chronic_flag | int | 0/1 | Has chronic condition (binary) |
| city | str | - | City of residence |
| visit_type | str | OPD/ER/ICU | Type of hospital visit |
| department | str | - | Hospital department |
| length_of_stay_hours | float | ≥0 | Duration of stay in hours |
| visit_frequency | int | ≥0 | Number of visits in period |
| avg_los_per_patient | float | ≥0 | Average patient stay length |
| days_since_registration | int | ≥0 | Days since patient registered |
| billed_amount | float | ≥0 | Amount billed in dollars |
| revenue_realization_ratio | float | 0-1 | Percentage of revenue realized |
| insurance_provider | str | - | Insurance company name |
| provider_rejection_rate | float | 0-100 | Provider's rejection rate (%) |
| visit_month | int | 1-12 | Month of visit (1=January) |
| visit_quarter | int | 1-4 | Quarter of visit |
| visit_day_of_week | str | Mon-Sun | Day of week |

---

### 4.2 Risk Prediction Response Schema

**Status:** 200 OK

**Content-Type:** `application/json`

**Schema:**

```json
{
  "prediction_id": "risk_20260613103045123456",
  "timestamp": "2026-06-13T10:30:45.123456",
  "model_version": "1.0",
  "predicted_class": "High",
  "class_probabilities": {
    "Low": 0.05,
    "Medium": 0.10,
    "High": 0.85
  },
  "confidence": 0.85,
  "feature_hash": "a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6",
  "status": "success"
}
```

**Response Fields:**

| Field | Type | Description |
|-------|------|-------------|
| prediction_id | str | Unique identifier for this prediction |
| timestamp | str | ISO 8601 timestamp of prediction |
| model_version | str | Version of model used |
| predicted_class | str | Predicted risk class (Low/Medium/High) |
| class_probabilities | dict | Probability for each class (sums to 1.0) |
| confidence | float | Confidence of prediction (0-1) |
| feature_hash | str | SHA256 hash of input features for audit |
| status | str | Status of request (success/error) |

---

### 4.3 Claim Prediction Request Schema

**Endpoint:** `POST /predict/claim`

**Content-Type:** `application/json`

**Required Fields:** All

**Schema:**

```json
{
  "age": 45,
  "gender": "M",
  "chronic_flag": 1,
  "city": "Delhi",
  "visit_type": "ER",
  "department": "Cardiology",
  "length_of_stay_hours": 24.5,
  "risk_score": "High",
  "billed_amount": 5000.0,
  "approved_amount": 4500.0,
  "revenue_realization_ratio": 0.90,
  "billing_gap": 500.0,
  "insurance_provider": "ICICI Health",
  "provider_rejection_rate": 5.2,
  "visit_frequency": 3,
  "days_since_registration": 365,
  "avg_los_per_patient": 18.2,
  "visit_month": 6,
  "visit_quarter": 2,
  "visit_day_of_week": "Monday"
}
```

**Field Descriptions:**

| Field | Type | Range | Description |
|-------|------|-------|-------------|
| age | int | 0-120 | Patient age in years |
| gender | str | M/F/Other | Patient gender |
| chronic_flag | int | 0/1 | Has chronic condition |
| city | str | - | City of residence |
| visit_type | str | OPD/ER/ICU | Type of visit |
| department | str | - | Hospital department |
| length_of_stay_hours | float | ≥0 | Duration of stay |
| risk_score | str | Low/Medium/High | Visit risk classification |
| billed_amount | float | ≥0 | Amount billed |
| approved_amount | float | ≥0 | Amount approved by insurance |
| revenue_realization_ratio | float | 0-1 | Revenue realization % |
| billing_gap | float | - | Difference (billed - approved) |
| insurance_provider | str | - | Insurance company |
| provider_rejection_rate | float | 0-100 | Provider rejection rate |
| visit_frequency | int | ≥0 | Number of visits |
| days_since_registration | int | ≥0 | Days since registration |
| avg_los_per_patient | float | ≥0 | Average stay length |
| visit_month | int | 1-12 | Month of visit |
| visit_quarter | int | 1-4 | Quarter of year |
| visit_day_of_week | str | Mon-Sun | Day of week |

---

### 4.4 Claim Prediction Response Schema

**Status:** 200 OK

**Content-Type:** `application/json`

**Schema:**

```json
{
  "prediction_id": "claim_20260613103045123456",
  "timestamp": "2026-06-13T10:30:45.123456",
  "model_version": "1.0",
  "predicted_class": "Rejected",
  "class_probabilities": {
    "Paid": 0.10,
    "Pending": 0.15,
    "Rejected": 0.75
  },
  "confidence": 0.75,
  "feature_hash": "a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6",
  "status": "success"
}
```

---

### 4.5 Health Check Response Schema

**Status:** 200 OK

**Schema:**

```json
{
  "status": "healthy",
  "timestamp": "2026-06-13T10:30:45.123456",
  "version": "1.0",
  "models_loaded": {
    "risk_model": true,
    "claim_model": true,
    "risk_scaler": true,
    "claim_scaler": true
  },
  "message": "All systems operational"
}
```

---

<a name="samples"></a>
## 5. Sample Requests and Responses

### 5.1 Risk Prediction Examples

**Example 1: High-Risk Patient**

**Request:**
```bash
curl -X POST http://localhost:8000/predict/risk \
  -H "Content-Type: application/json" \
  -d '{
    "age": 72,
    "gender": "M",
    "chronic_flag": 1,
    "city": "Mumbai",
    "visit_type": "ICU",
    "department": "Cardiology",
    "length_of_stay_hours": 48,
    "visit_frequency": 5,
    "avg_los_per_patient": 35.0,
    "days_since_registration": 730,
    "billed_amount": 15000.0,
    "revenue_realization_ratio": 0.85,
    "insurance_provider": "HDFC Health",
    "provider_rejection_rate": 8.5,
    "visit_month": 6,
    "visit_quarter": 2,
    "visit_day_of_week": "Tuesday"
  }'
```

**Response:**
```json
{
  "prediction_id": "risk_20260613103045123456",
  "timestamp": "2026-06-13T10:30:45.123456",
  "model_version": "1.0",
  "predicted_class": "High",
  "class_probabilities": {
    "Low": 0.02,
    "Medium": 0.08,
    "High": 0.90
  },
  "confidence": 0.90,
  "feature_hash": "a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6",
  "status": "success"
}
```

**Interpretation:**
- Patient is **very high risk** (90% confidence)
- Risk factors: Age 72, ICU visit, chronic condition, long stay
- **Action:** Immediate clinical review, intensive monitoring, ICU bed reservation

---

**Example 2: Low-Risk Patient**

**Request:**
```bash
curl -X POST http://localhost:8000/predict/risk \
  -H "Content-Type: application/json" \
  -d '{
    "age": 28,
    "gender": "F",
    "chronic_flag": 0,
    "city": "Bangalore",
    "visit_type": "OPD",
    "department": "General Medicine",
    "length_of_stay_hours": 1.5,
    "visit_frequency": 1,
    "avg_los_per_patient": 1.5,
    "days_since_registration": 30,
    "billed_amount": 500.0,
    "revenue_realization_ratio": 0.98,
    "insurance_provider": "Apollo Health",
    "provider_rejection_rate": 2.1,
    "visit_month": 6,
    "visit_quarter": 2,
    "visit_day_of_week": "Monday"
  }'
```

**Response:**
```json
{
  "prediction_id": "risk_20260613103046234567",
  "timestamp": "2026-06-13T10:30:46.234567",
  "model_version": "1.0",
  "predicted_class": "Low",
  "class_probabilities": {
    "Low": 0.88,
    "Medium": 0.10,
    "High": 0.02
  },
  "confidence": 0.88,
  "feature_hash": "b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6a1",
  "status": "success"
}
```

**Interpretation:**
- Patient is **low risk** (88% confidence)
- Positive factors: Young age, no chronic conditions, OPD visit, short stay
- **Action:** Routine care, standard follow-up, discharge planning

---

### 5.2 Claim Prediction Examples

**Example 1: Predicted Rejection**

**Request:**
```bash
curl -X POST http://localhost:8000/predict/claim \
  -H "Content-Type: application/json" \
  -d '{
    "age": 55,
    "gender": "M",
    "chronic_flag": 1,
    "city": "Delhi",
    "visit_type": "ICU",
    "department": "Orthopedics",
    "length_of_stay_hours": 72,
    "risk_score": "High",
    "billed_amount": 12000.0,
    "approved_amount": 5000.0,
    "revenue_realization_ratio": 0.42,
    "billing_gap": 7000.0,
    "insurance_provider": "United Health",
    "provider_rejection_rate": 15.3,
    "visit_frequency": 2,
    "days_since_registration": 180,
    "avg_los_per_patient": 65.0,
    "visit_month": 6,
    "visit_quarter": 2,
    "visit_day_of_week": "Friday"
  }'
```

**Response:**
```json
{
  "prediction_id": "claim_20260613103047345678",
  "timestamp": "2026-06-13T10:30:47.345678",
  "model_version": "1.0",
  "predicted_class": "Rejected",
  "class_probabilities": {
    "Paid": 0.05,
    "Pending": 0.20,
    "Rejected": 0.75
  },
  "confidence": 0.75,
  "feature_hash": "c3d4e5f6g7h8i9j0k1l2m3n4o5p6a1b2",
  "status": "success"
}
```

**Interpretation:**
- Claim is **likely to be rejected** (75% confidence)
- Risk factors: Large billing gap ($7,000), low approval rate (42%), provider has 15.3% rejection rate
- **Action:** Send to special review team, prepare documentation, contact provider, anticipate rejection

---

**Example 2: Predicted Approval**

**Request:**
```bash
curl -X POST http://localhost:8000/predict/claim \
  -H "Content-Type: application/json" \
  -d '{
    "age": 42,
    "gender": "F",
    "chronic_flag": 0,
    "city": "Pune",
    "visit_type": "ER",
    "department": "Emergency",
    "length_of_stay_hours": 6,
    "risk_score": "Medium",
    "billed_amount": 3500.0,
    "approved_amount": 3450.0,
    "revenue_realization_ratio": 0.99,
    "billing_gap": 50.0,
    "insurance_provider": "Star Health",
    "provider_rejection_rate": 1.2,
    "visit_frequency": 1,
    "days_since_registration": 90,
    "avg_los_per_patient": 5.5,
    "visit_month": 6,
    "visit_quarter": 2,
    "visit_day_of_week": "Wednesday"
  }'
```

**Response:**
```json
{
  "prediction_id": "claim_20260613103048456789",
  "timestamp": "2026-06-13T10:30:48.456789",
  "model_version": "1.0",
  "predicted_class": "Paid",
  "class_probabilities": {
    "Paid": 0.92,
    "Pending": 0.06,
    "Rejected": 0.02
  },
  "confidence": 0.92,
  "feature_hash": "d4e5f6g7h8i9j0k1l2m3n4o5p6a1b2c3",
  "status": "success"
}
```

**Interpretation:**
- Claim is **very likely to be paid** (92% confidence)
- Positive factors: Minimal billing gap ($50), high approval rate (99%), reputable provider
- **Action:** Fast-track processing, prepare for payment, routine claim handling

---

### 5.3 Health Check Examples

**Request:**
```bash
curl -X GET http://localhost:8000/health
```

**Response (Healthy):**
```json
{
  "status": "healthy",
  "timestamp": "2026-06-13T10:30:49.567890",
  "version": "1.0",
  "models_loaded": {
    "risk_model": true,
    "claim_model": true,
    "risk_scaler": true,
    "claim_scaler": true
  },
  "message": "All systems operational"
}
```

**Response (Degraded):**
```json
{
  "status": "degraded",
  "timestamp": "2026-06-13T10:30:49.567890",
  "version": "1.0",
  "models_loaded": {
    "risk_model": true,
    "claim_model": false,
    "risk_scaler": true,
    "claim_scaler": false
  },
  "message": "Some models not loaded"
}
```

---

<a name="error-handling"></a>
## 6. Error Handling

### 6.1 HTTP Status Codes

| Status | Meaning | Example |
|--------|---------|---------|
| 200 | Success | Prediction returned successfully |
| 400 | Bad Request | Invalid input data (validation error) |
| 401 | Unauthorized | Invalid or missing authentication |
| 403 | Forbidden | Access denied |
| 422 | Unprocessable Entity | Valid JSON but invalid values |
| 429 | Too Many Requests | Rate limit exceeded |
| 500 | Internal Server Error | Prediction computation failed |
| 503 | Service Unavailable | Models not loaded |

### 6.2 Error Response Format

**Schema:**
```json
{
  "status": "error",
  "error_code": "VALIDATION_ERROR",
  "message": "Invalid input data",
  "timestamp": "2026-06-13T10:30:45.123456",
  "details": "Field 'age' must be between 0 and 120"
}
```

### 6.3 Common Errors and Solutions

**Error 1: Validation Error (422)**

**Request (Invalid age):**
```bash
curl -X POST http://localhost:8000/predict/risk \
  -H "Content-Type: application/json" \
  -d '{
    "age": 150,  # Invalid: exceeds maximum of 120
    "gender": "M",
    ...
  }'
```

**Response:**
```json
{
  "status": "error",
  "error_code": "VALIDATION_ERROR",
  "message": "Invalid input: age must be between 0 and 120",
  "timestamp": "2026-06-13T10:30:45.123456"
}
```

**Solution:**
- Validate input values match required ranges
- Check field types (int vs float vs string)
- Ensure all required fields are present

---

**Error 2: Model Not Loaded (503)**

**Response:**
```json
{
  "status": "error",
  "error_code": "SERVICE_UNAVAILABLE",
  "message": "Risk model not loaded",
  "timestamp": "2026-06-13T10:30:45.123456"
}
```

**Solution:**
1. Check health endpoint: `curl http://localhost:8000/health`
2. Verify model files exist in project directory
3. Check logs for loading errors: `tail -f logs/api_service_*.log`
4. Restart API service

---

**Error 3: Rate Limit Exceeded (429)**

**Response:**
```json
{
  "status": "error",
  "error_code": "RATE_LIMIT_EXCEEDED",
  "message": "Too many requests (limit: 100/minute)",
  "timestamp": "2026-06-13T10:30:45.123456"
}
```

**Solution:**
- Implement request queuing
- Batch predictions
- Request rate limit increase (if needed)
- Add exponential backoff retry logic

---

### 6.4 Retry Strategy

**Recommended Implementation:**

```python
import time
import httpx

async def predict_with_retry(
    endpoint: str,
    data: dict,
    max_retries: int = 3,
    backoff_factor: float = 2.0
):
    """Predict with exponential backoff retry"""
    
    for attempt in range(max_retries):
        try:
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    f"http://localhost:8000{endpoint}",
                    json=data,
                    timeout=30.0
                )
                
                if response.status_code == 200:
                    return response.json()
                elif response.status_code == 429:  # Rate limit
                    wait_time = backoff_factor ** attempt
                    await asyncio.sleep(wait_time)
                    continue
                else:
                    response.raise_for_status()
        
        except Exception as e:
            if attempt < max_retries - 1:
                wait_time = backoff_factor ** attempt
                await asyncio.sleep(wait_time)
                continue
            else:
                raise
    
    raise Exception("Max retries exceeded")
```

---

<a name="integration"></a>
## 7. Integration Examples

### 7.1 Python Integration

**Basic Example:**

```python
import httpx
import json

def get_risk_prediction(patient_data: dict) -> dict:
    """Get risk prediction for a patient"""
    
    with httpx.Client() as client:
        response = client.post(
            "http://localhost:8000/predict/risk",
            json=patient_data,
            timeout=30.0
        )
        
        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"Prediction failed: {response.text}")

# Example usage
patient = {
    "age": 45,
    "gender": "M",
    "chronic_flag": 1,
    "city": "Delhi",
    "visit_type": "ER",
    "department": "Cardiology",
    "length_of_stay_hours": 24.5,
    "visit_frequency": 3,
    "avg_los_per_patient": 18.2,
    "days_since_registration": 365,
    "billed_amount": 5000.0,
    "revenue_realization_ratio": 0.95,
    "insurance_provider": "ICICI Health",
    "provider_rejection_rate": 5.2,
    "visit_month": 6,
    "visit_quarter": 2,
    "visit_day_of_week": "Monday"
}

result = get_risk_prediction(patient)
print(f"Predicted Risk: {result['predicted_class']}")
print(f"Confidence: {result['confidence']:.2%}")
print(f"Probabilities: {result['class_probabilities']}")
```

---

### 7.2 JavaScript/Node.js Integration

**Example:**

```javascript
async function getRiskPrediction(patientData) {
    try {
        const response = await fetch('http://localhost:8000/predict/risk', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(patientData)
        });

        if (!response.ok) {
            throw new Error(`Prediction failed: ${response.statusText}`);
        }

        const result = await response.json();
        return result;
    } catch (error) {
        console.error('Error:', error);
        throw error;
    }
}

// Example usage
const patient = {
    age: 45,
    gender: 'M',
    chronic_flag: 1,
    city: 'Delhi',
    visit_type: 'ER',
    department: 'Cardiology',
    length_of_stay_hours: 24.5,
    visit_frequency: 3,
    avg_los_per_patient: 18.2,
    days_since_registration: 365,
    billed_amount: 5000.0,
    revenue_realization_ratio: 0.95,
    insurance_provider: 'ICICI Health',
    provider_rejection_rate: 5.2,
    visit_month: 6,
    visit_quarter: 2,
    visit_day_of_week: 'Monday'
};

getRiskPrediction(patient)
    .then(result => {
        console.log(`Predicted Risk: ${result.predicted_class}`);
        console.log(`Confidence: ${(result.confidence * 100).toFixed(2)}%`);
        console.log(`Probabilities:`, result.class_probabilities);
    });
```

---

### 7.3 SQL Integration

**Store predictions in database:**

```sql
-- Create predictions table
CREATE TABLE predictions (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    prediction_id VARCHAR(255) UNIQUE,
    model_type VARCHAR(50),
    predicted_class VARCHAR(50),
    confidence FLOAT,
    feature_hash VARCHAR(64),
    timestamp DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert prediction
INSERT INTO predictions (prediction_id, model_type, predicted_class, confidence, feature_hash, timestamp)
VALUES ('risk_20260613103045123456', 'risk', 'High', 0.85, 'a1b2c3d4...', '2026-06-13 10:30:45');

-- Query predictions
SELECT 
    model_type,
    predicted_class,
    AVG(confidence) as avg_confidence,
    COUNT(*) as count
FROM predictions
WHERE created_at >= DATE_SUB(NOW(), INTERVAL 1 DAY)
GROUP BY model_type, predicted_class;
```

---

### 7.4 Batch Processing

**Process multiple predictions efficiently:**

```python
import asyncio
import httpx

async def batch_predict_risk(patients: list[dict]) -> list[dict]:
    """Process multiple predictions concurrently"""
    
    async with httpx.AsyncClient() as client:
        tasks = [
            client.post(
                "http://localhost:8000/predict/risk",
                json=patient,
                timeout=30.0
            )
            for patient in patients
        ]
        
        responses = await asyncio.gather(*tasks)
        
        results = [
            response.json() if response.status_code == 200 else None
            for response in responses
        ]
        
        return results

# Example usage
patients = [
    {...patient1...},
    {...patient2...},
    {...patient3...}
]

results = asyncio.run(batch_predict_risk(patients))

for result in results:
    if result:
        print(f"Prediction {result['prediction_id']}: {result['predicted_class']}")
```

---

<a name="best-practices"></a>
## 8. Best Practices

### 8.1 Input Data Validation

**Before Sending Request:**

```python
def validate_risk_request(data: dict) -> bool:
    """Validate input data before sending"""
    
    # Check required fields
    required_fields = [
        'age', 'gender', 'chronic_flag', 'city', 'visit_type',
        'department', 'length_of_stay_hours', 'visit_frequency',
        'avg_los_per_patient', 'days_since_registration',
        'billed_amount', 'revenue_realization_ratio',
        'insurance_provider', 'provider_rejection_rate',
        'visit_month', 'visit_quarter', 'visit_day_of_week'
    ]
    
    # Validate presence
    for field in required_fields:
        if field not in data:
            raise ValueError(f"Missing required field: {field}")
    
    # Validate ranges
    if not (0 <= data['age'] <= 120):
        raise ValueError("Age must be between 0 and 120")
    
    if not (0 <= data['revenue_realization_ratio'] <= 1):
        raise ValueError("Revenue realization ratio must be between 0 and 1")
    
    if not (1 <= data['visit_month'] <= 12):
        raise ValueError("Month must be between 1 and 12")
    
    return True
```

---

### 8.2 Handling Predictions

**Process Results Appropriately:**

```python
def handle_risk_prediction(result: dict):
    """Process risk prediction based on class"""
    
    risk_class = result['predicted_class']
    confidence = result['confidence']
    
    if risk_class == 'High':
        if confidence > 0.80:
            # Very confident high risk
            trigger_immediate_alert()
            assign_case_manager()
            reserve_icu_bed()
        else:
            # Moderate confidence
            flag_for_review()
            schedule_specialist_consult()
    
    elif risk_class == 'Medium':
        schedule_routine_monitoring()
        prepare_for_escalation()
    
    else:  # Low
        standard_care_pathway()
        routine_follow_up()
    
    # Always log for audit
    log_prediction(result)
```

---

### 8.3 Error Handling

**Implement Robust Error Handling:**

```python
async def predict_with_fallback(data: dict, fallback_action: callable):
    """Predict with fallback action if API unavailable"""
    
    try:
        result = await get_prediction(data)
        return result
    
    except httpx.TimeoutException:
        logger.warning("API timeout, using fallback")
        return fallback_action(data)
    
    except httpx.ConnectError:
        logger.error("API connection failed, using fallback")
        return fallback_action(data)
    
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 503:
            logger.error("API unavailable, using fallback")
            return fallback_action(data)
        else:
            raise
    
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        return fallback_action(data)

# Fallback: Use simple rule-based approach
def rule_based_risk_assessment(patient_data: dict) -> dict:
    """Simple rule-based assessment when API unavailable"""
    
    score = 0
    if patient_data['age'] > 65:
        score += 2
    if patient_data['chronic_flag'] == 1:
        score += 2
    if patient_data['length_of_stay_hours'] > 24:
        score += 1
    
    if score >= 4:
        risk_class = 'High'
    elif score >= 2:
        risk_class = 'Medium'
    else:
        risk_class = 'Low'
    
    return {
        'predicted_class': risk_class,
        'source': 'rule_based_fallback',
        'confidence': 0.5
    }
```

---

### 8.4 Monitoring and Logging

**Log All Predictions:**

```python
import json
from datetime import datetime

def log_prediction_event(prediction_result: dict, patient_id: str = None):
    """Log prediction for audit and monitoring"""
    
    log_entry = {
        'timestamp': datetime.now().isoformat(),
        'prediction_id': prediction_result['prediction_id'],
        'patient_id': patient_id,
        'model_type': 'risk' if 'risk' in prediction_result['prediction_id'] else 'claim',
        'predicted_class': prediction_result['predicted_class'],
        'confidence': prediction_result['confidence'],
        'status': prediction_result['status']
    }
    
    # Log to file
    with open('predictions.log', 'a') as f:
        f.write(json.dumps(log_entry) + '\n')
    
    # Send to monitoring system
    send_to_monitoring_system(log_entry)
```

---

<a name="troubleshooting"></a>
## 9. Troubleshooting

### 9.1 Common Issues

**Issue 1: Connection Refused**

```
Error: Failed to connect to http://localhost:8000
```

**Solution:**
1. Verify API is running: `curl http://localhost:8000/health`
2. Check port: `netstat -ano | findstr :8000` (Windows)
3. Start API: `python main.py`

---

**Issue 2: Timeout on Prediction**

```
Error: Request timeout after 30 seconds
```

**Solution:**
1. Check API logs for slowness
2. Verify system resources (CPU, RAM, disk)
3. Increase timeout in client: `timeout=60.0`
4. Check model file sizes

---

**Issue 3: Invalid Request Error (422)**

```json
{
  "status": "error",
  "error_code": "VALIDATION_ERROR"
}
```

**Solution:**
1. Validate all required fields are present
2. Check field types and ranges
3. Use example from documentation
4. Print request JSON before sending

---

### 9.2 Performance Optimization

**If predictions are slow:**

1. **Monitor server resources:**
   ```bash
   docker stats hospital-ml-api-prod
   ```

2. **Increase workers (in production):**
   ```bash
   gunicorn main:app --workers 8 --worker-class uvicorn.workers.UvicornWorker
   ```

3. **Enable caching (for similar requests):**
   ```python
   from functools import lru_cache
   
   @lru_cache(maxsize=1000)
   def cached_prediction(features_hash: str):
       ...
   ```

4. **Batch predictions:**
   - Send 10-100 predictions at once
   - Process concurrently

---

### 9.3 Monitoring Dashboard

**Metrics to Track:**

- Prediction latency (ms)
- Requests per minute
- Error rate (%)
- Model confidence distribution
- CPU/Memory usage
- API uptime

---

## Quick Reference

**Health Check:**
```bash
curl http://localhost:8000/health
```

**Risk Prediction:**
```bash
curl -X POST http://localhost:8000/predict/risk \
  -H "Content-Type: application/json" \
  -d '{...}'
```

**Claim Prediction:**
```bash
curl -X POST http://localhost:8000/predict/claim \
  -H "Content-Type: application/json" \
  -d '{...}'
```

**API Docs:**
- http://localhost:8000/docs (Swagger)
- http://localhost:8000/redoc (ReDoc)

---

**Document Version:** 1.0  
**Last Updated:** 2026-06-13  
**API Version:** 1.0  

