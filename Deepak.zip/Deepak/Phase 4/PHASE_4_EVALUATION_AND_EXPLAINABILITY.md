# Phase 4: Model Evaluation and Explainability
## Hospital Data Management System - IITM Capstone Project

**Phase:** 4 - Model Evaluation & Explainability  
**Baseline:** Phase 2 (EDA) + Phase 3 (Models)  
**Date:** 2026-06-13  
**Status:** FRAMEWORK & ANALYSIS TEMPLATE  

---

## Executive Summary

Phase 4 focuses on comprehensive model evaluation, explainability, and fairness assessment for both classification models developed in Phase 3. This document provides detailed analysis of model performance, interpretability, and potential bias issues to ensure safe and reliable deployment in hospital operations and finance teams.

**Business Objectives:**
- Validate prediction reliability across different data segments
- Ensure interpretability for stakeholders (clinical and financial)
- Identify and address fairness gaps
- Create production-ready model documentation
- Provide recommendations for model improvement

---

## Table of Contents

1. [Model A: Risk Classification - Detailed Evaluation](#model-a-evaluation)
2. [Model B: Claim Outcome - Detailed Evaluation](#model-b-evaluation)
3. [Business Metrics Analysis](#business-metrics)
4. [Feature Importance & Explainability](#explainability)
5. [Fairness and Bias Analysis](#fairness-analysis)
6. [Model Cards](#model-cards)
7. [Recommendations & Improvements](#recommendations)
8. [Conclusion](#conclusion)

---

<a name="model-a-evaluation"></a>
## 1. Model A: Visit Risk Classification - Detailed Evaluation

### 1.1 Overview

**Model:** Random Forest Classifier (Tuned)  
**Target:** `risk_score` (Low, Medium, High)  
**Training Samples:** 386  
**Test Samples:** 97  
**Date:** 2026-06-13  

### 1.2 Training Data Performance

#### 1.2.1 Overall Metrics

| Metric | Score | Notes |
|--------|-------|-------|
| Accuracy | **XX%** | To be filled from model evaluation |
| Precision (weighted) | **XX%** | Overall precision across all classes |
| Recall (weighted) | **XX%** | Overall recall across all classes |
| F1-Score (weighted) | **XX%** | Harmonic mean of precision and recall |
| Macro F1-Score | **XX%** | Unweighted F1-score |

**ANALYSIS NEEDED:**
- [ ] Execute 02_risk_model.ipynb to generate training metrics
- [ ] Compare training vs. test performance to assess overfitting
- [ ] Note any discrepancies between train and test accuracy

#### 1.2.2 Training Confusion Matrix

```
                Predicted Low  Predicted Medium  Predicted High
Actual Low      [XX]          [XX]             [XX]
Actual Medium   [XX]          [XX]             [XX]
Actual High     [XX]          [XX]             [XX]

Total Samples: 386
```

**ANALYSIS NEEDED:**
- [ ] Identify confusion patterns (which classes are confused with which)
- [ ] Calculate misclassification rates per class
- [ ] Note if any classes are systematically misclassified

#### 1.2.3 Per-Class Performance (Training)

| Class | Precision | Recall | F1-Score | Support |
|-------|-----------|--------|----------|---------|
| Low | XX% | XX% | XX% | [N] |
| Medium | XX% | XX% | XX% | [N] |
| High | XX% | XX% | XX% | [N] |

**ANALYSIS NEEDED:**
- [ ] Assess balance across class metrics
- [ ] Identify any class-specific performance issues
- [ ] Note support (sample count) for each class

### 1.3 Test Data Performance (Unseen Data)

#### 1.3.1 Overall Metrics

| Metric | Score | Training | Difference | Notes |
|--------|-------|----------|------------|-------|
| Accuracy | **XX%** | **XX%** | **±XX%** | Generalization measure |
| Precision (weighted) | **XX%** | **XX%** | **±XX%** | False positive rate |
| Recall (weighted) | **XX%** | **XX%** | **±XX%** | False negative rate |
| F1-Score (weighted) | **XX%** | **XX%** | **±XX%** | Overall balance |

**ANALYSIS & INTERPRETATION:**
```
[To be filled after model execution]

Overfitting Assessment:
- If Train Acc > Test Acc by >5%: Model may be overfitting
- If difference <3%: Good generalization
- Current gap: ±[XX]% - indicates [GOOD/FAIR/POOR] generalization

Expected Performance on New Data:
- Baseline expectation: Test accuracy represents real-world performance
- Confidence level: [HIGH/MEDIUM/LOW] - depends on test/train difference
```

#### 1.3.2 Test Confusion Matrix

```
                Predicted Low  Predicted Medium  Predicted High
Actual Low      [XX]          [XX]             [XX]
Actual Medium   [XX]          [XX]             [XX]
Actual High     [XX]          [XX]             [XX]

Total Samples: 97
```

**ANALYSIS NEEDED:**
- [ ] Compare with training confusion matrix
- [ ] Identify if same confusion patterns persist
- [ ] Note any new patterns in test data

#### 1.3.3 Per-Class Performance (Test Data)

| Class | Precision | Recall | F1-Score | Support | Interpretation |
|-------|-----------|--------|----------|---------|-----------------|
| Low | XX% | XX% | XX% | [N] | [Analysis] |
| Medium | XX% | XX% | XX% | [N] | [Analysis] |
| High | XX% | XX% | XX% | [N] | [Analysis] |

**CLASS-SPECIFIC INTERPRETATION NEEDED:**

**Low Risk Class:**
```
Precision (XX%): When model predicts Low Risk, [XX]% of predictions are correct
Recall (XX%): Model identifies [XX]% of actual Low Risk patients
Business Impact: [Under/over-identification of low-risk patients]
Recommendation: [Action based on performance]
```

**Medium Risk Class:**
```
Precision (XX%): When model predicts Medium Risk, [XX]% of predictions are correct
Recall (XX%): Model identifies [XX]% of actual Medium Risk patients
Business Impact: [Under/over-identification of medium-risk patients]
Recommendation: [Action based on performance]
```

**High Risk Class:**
```
Precision (XX%): When model predicts High Risk, [XX]% of predictions are correct
Recall (XX%): Model identifies [XX]% of actual High Risk patients
Business Impact: CRITICAL - Missing high-risk patients could lead to patient harm
Recommendation: [Action based on performance]
```

### 1.4 Business Metric: Recall for High Risk Class

**CRITICAL BUSINESS METRIC**

| Metric | Value | Target | Status |
|--------|-------|--------|--------|
| Recall - High Risk | **XX%** | ≥95% | [MET/BELOW] |
| Precision - High Risk | **XX%** | ≥85% | [MET/BELOW] |
| False Negative Rate (High Risk) | **XX%** | ≤5% | [MET/ABOVE] |

**BUSINESS INTERPRETATION:**

```
What this means:
- Recall (XX%): Of all actual HIGH RISK cases, model correctly identifies XX%
- XX% of high-risk patients are MISSED (False Negatives)
- These XX% patients may not receive appropriate interventions

Risk Assessment:
- If recall >95%: Excellent - Nearly all high-risk patients identified
- If recall 85-95%: Good - Most high-risk patients identified, but some may be missed
- If recall <85%: Poor - Too many high-risk patients are being missed

Clinical Impact:
[Analysis of what these missed cases mean for patient care]

Financial Impact:
[Analysis of operational and liability implications]
```

**Recommendations if Recall is Below Target:**
- [ ] Adjust decision threshold (lower threshold = higher recall, lower precision)
- [ ] Implement risk stratification layers (use model score as input to additional validation)
- [ ] Consider ensemble approach with additional models
- [ ] Enhance feature engineering for high-risk indicators
- [ ] Implement manual review process for edge cases

---

<a name="model-b-evaluation"></a>
## 2. Model B: Claim Outcome Prediction - Detailed Evaluation

### 2.1 Overview

**Model:** Gradient Boosting Classifier + SMOTE  
**Target:** `claim_status` (Paid, Pending, Rejected)  
**Training Samples:** 386 → 1,158 (after SMOTE)  
**Test Samples:** 97 (original distribution)  
**Class Imbalance Mitigation:** SMOTE Oversampling  
**Date:** 2026-06-13  

### 2.2 Training Data Performance

#### 2.2.1 Overall Metrics (Before SMOTE)

| Metric | Score | Notes |
|--------|-------|-------|
| Accuracy | **XX%** | On original imbalanced training data |
| Precision (weighted) | **XX%** | Overall precision |
| Recall (weighted) | **XX%** | Overall recall (biased toward majority) |
| F1-Score (weighted) | **XX%** | Weighted harmonic mean |

**ANALYSIS NEEDED:**
- [ ] Note baseline performance before SMOTE
- [ ] Identify which classes are poorly predicted

#### 2.2.2 Class Distribution - Before SMOTE

| Class | Count | Percentage | Notes |
|-------|-------|-----------|-------|
| Paid | [N] | XX% | Majority class |
| Pending | [N] | XX% | Minority class |
| Rejected | [N] | XX% | Minority class |
| **Total** | **386** | **100%** | Original imbalance |

**IMBALANCE ANALYSIS:**
```
Imbalance Ratio: [Calculate Paid : Minority ratio]
- If ratio >2:1: Significant imbalance
- If ratio >5:1: Severe imbalance

Classes at Risk of Underfitting:
[Analysis of which minority classes may be affected]
```

#### 2.2.3 Training Confusion Matrix (Before SMOTE)

```
                Predicted Paid  Predicted Pending  Predicted Rejected
Actual Paid     [XX]           [XX]              [XX]
Actual Pending  [XX]           [XX]              [XX]
Actual Rejected [XX]           [XX]              [XX]

Total Samples: 386
```

**ANALYSIS NEEDED:**
- [ ] Identify strong bias toward majority (Paid) class
- [ ] Note recall for minority classes (likely low)

#### 2.2.4 Per-Class Performance - Before SMOTE

| Class | Precision | Recall | F1-Score | Support | Issue |
|-------|-----------|--------|----------|---------|-------|
| Paid | XX% | XX% | XX% | [N] | Typically high (majority bias) |
| Pending | XX% | XX% | XX% | [N] | Typically low (minority) |
| Rejected | XX% | XX% | XX% | [N] | Typically low (minority) |

### 2.3 After SMOTE Resampling

#### 2.3.1 Class Distribution - After SMOTE

| Class | Count (Original) | Count (After SMOTE) | New Percentage |
|-------|-----------------|-------------------|-----------------|
| Paid | [N] | [N] | ~33% |
| Pending | [N] | [N] | ~33% |
| Rejected | [N] | [N] | ~33% |
| **Total** | **386** | **1,158** | **100%** |

**SMOTE IMPACT:**
```
Synthetic Samples Generated: [1,158 - 386] = [N]
Minority Class Boost:
- Pending: Original [N] → SMOTE [N] (×[ratio])
- Rejected: Original [N] → SMOTE [N] (×[ratio])

Benefit: Allows model to learn minority patterns
Trade-off: Training on synthetic data may affect generalization
Test data unchanged: Preserves honest evaluation
```

#### 2.3.2 Training Metrics (After SMOTE)

| Metric | Before SMOTE | After SMOTE | Improvement |
|--------|--------------|-------------|-------------|
| Accuracy | XX% | XX% | ±XX% |
| Precision (weighted) | XX% | XX% | ±XX% |
| Recall (weighted) | XX% | XX% | ±XX% |
| Recall - Pending | XX% | XX% | +XX% |
| Recall - Rejected | XX% | XX% | +XX% |
| F1-Score (weighted) | XX% | XX% | ±XX% |

**ANALYSIS & TRADE-OFFS:**

```
SMOTE Results Analysis:
[Fill based on execution]

Minority Class Improvements:
- Pending Recall increased by: XX% (DESIRED: +10% minimum)
- Rejected Recall increased by: XX% (DESIRED: +15% minimum)

Overall Accuracy Change:
- If accuracy decreased slightly: Expected and acceptable (minority recall ↑)
- If accuracy decreased significantly: May indicate model instability

Interpretation:
The model now better identifies minority claim statuses at the potential
cost of overall accuracy. For claim processing, catching Rejected and Pending
claims is more valuable than perfect Paid classification.
```

### 2.4 Test Data Performance (Original Distribution - Unseen)

#### 2.4.1 Overall Metrics (Test)

| Metric | Train (SMOTE) | Test (Original) | Difference |
|--------|---------------|-----------------|-------------|
| Accuracy | XX% | XX% | ±XX% |
| Precision (weighted) | XX% | XX% | ±XX% |
| Recall (weighted) | XX% | XX% | ±XX% |
| F1-Score (weighted) | XX% | XX% | ±XX% |

**GENERALIZATION ASSESSMENT:**

```
Expected Behavior:
- Test Recall should remain HIGH for minority classes
  (benefit of SMOTE on training data)
- Test Recall for Paid may be slightly lower
  (due to SMOTE rebalancing)

Actual Performance:
- Train-Test Accuracy Gap: [XX]%
  Status: [GOOD/ACCEPTABLE/POOR]
- Test minority recall preserved: [YES/NO]
  Status: [SUCCESS/PARTIAL/FAILURE]
```

#### 2.4.2 Test Confusion Matrix

```
                Predicted Paid  Predicted Pending  Predicted Rejected
Actual Paid     [XX]           [XX]              [XX]
Actual Pending  [XX]           [XX]              [XX]
Actual Rejected [XX]           [XX]              [XX]

Total Samples: 97
Actual Class Distribution: Paid [XX]% | Pending [XX]% | Rejected [XX]%
```

**ANALYSIS NEEDED:**
- [ ] Verify SMOTE benefit is present in test set (improved minority recall)
- [ ] Check if Paid class precision remains acceptable
- [ ] Identify any new confusion patterns

#### 2.4.3 Per-Class Performance (Test Data)

| Class | Precision | Recall | F1-Score | Support | Interpretation |
|-------|-----------|--------|----------|---------|-----------------|
| Paid | XX% | XX% | XX% | [N] | [Analysis] |
| Pending | XX% | XX% | XX% | [N] | [Analysis] |
| Rejected | XX% | XX% | XX% | [N] | [Analysis] |

**CLASS-SPECIFIC ANALYSIS:**

**Paid Claims (Majority):**
```
Precision (XX%): When model predicts "Paid", [XX]% are actually Paid
Recall (XX%): Model identifies [XX]% of actual Paid claims
False Negative Rate: [XX]% of Paid claims are misclassified
Business Impact: Missed "Paid" predictions could delay cash flow reporting
Acceptable Range: Recall ≥85% (some delay acceptable)
Status: [MET/BELOW]
```

**Pending Claims (Minority):**
```
Precision (XX%): When model predicts "Pending", [XX]% are actually Pending
Recall (XX%): Model identifies [XX]% of actual Pending claims
SMOTE Impact: Recall should be improved from baseline
Business Impact: Helps identify claims requiring follow-up
Target: Recall ≥70% (to catch most pending claims)
Status: [MET/BELOW]
Improvement over pre-SMOTE: +[XX]%
```

**Rejected Claims (Minority):**
```
Precision (XX%): When model predicts "Rejected", [XX]% are actually Rejected
Recall (XX%): Model identifies [XX]% of actual Rejected claims
SMOTE Impact: Recall should show significant improvement
Business Impact: CRITICAL - Early identification reduces wasted effort
Target: Recall ≥75% (catch majority of rejectable claims)
Status: [MET/BELOW]
Improvement over pre-SMOTE: +[XX]%
```

### 2.5 Business Metrics: Recall for Rejected Class

**CRITICAL BUSINESS METRIC**

| Metric | Value | Target | Status |
|--------|-------|--------|--------|
| Recall - Rejected | **XX%** | ≥75% | [MET/BELOW] |
| Precision - Rejected | **XX%** | ≥80% | [MET/BELOW] |
| False Negative Rate (Rejected) | **XX%** | ≤25% | [MET/ABOVE] |
| Cost Savings (Early Detection) | **$[XX]** | Varies | [Calculated below] |

**BUSINESS INTERPRETATION:**

```
What this means:
- Recall (XX%): Of all claims that will be rejected, model identifies [XX]%
- [XX]% of rejectable claims are MISSED (False Negatives)
- These missed claims proceed through approval process unnecessarily

Financial Impact:
- Manual processing cost per claim: ~$[XX]
- Claims processed incorrectly: [XX] out of 97 test claims
- Estimated wasted cost: [XX] × $[XX] = $[XX,XXX]

Recall Achievement:
- If recall >85%: Excellent cost avoidance
- If recall 70-85%: Good, with some inefficiency
- If recall <70%: Poor, significant waste and rework

Improvement from SMOTE:
- Pre-SMOTE recall: XX%
- Post-SMOTE recall: XX%
- Improvement: +XX% (validates SMOTE effectiveness)
```

**Recommendations if Below Target:**
- [ ] Lower prediction threshold for "Rejected" class (more sensitivity)
- [ ] Implement two-stage review (model + human validation for edge cases)
- [ ] Develop ensemble with additional rejection indicators
- [ ] Enhance feature engineering (billing_gap, provider_rejection_rate)
- [ ] Conduct root cause analysis of missed rejections

---

<a name="business-metrics"></a>
## 3. Business Metrics Analysis

### 3.1 Risk Model Business Metrics Summary

| Business Metric | Value | Target | Impact | Status |
|-----------------|-------|--------|--------|--------|
| High Risk Recall | **XX%** | ≥95% | Patient Safety | [MET/BELOW] |
| High Risk Precision | **XX%** | ≥85% | Resource Allocation | [MET/BELOW] |
| Low Risk False Positive | **XX%** | ≤10% | Unnecessary Interventions | [MET/BELOW] |
| Overall Model Accuracy | **XX%** | ≥80% | Operational Trust | [MET/BELOW] |

**IMPACT ANALYSIS:**

```
HIGH RISK DETECTION:
- Patients correctly identified as high-risk: [XX%] of actual high-risk
- Patients incorrectly classified as high-risk: [XX]% of low-risk
- Operational consequence: [Resource planning, ICU bed allocation]
- Clinical consequence: [Intervention planning, monitoring levels]

FAIRNESS CONSIDERATION:
- Does model performance vary by patient demographics?
  See Section 5: Fairness and Bias Analysis

DEPLOYMENT DECISION:
- Risk Score Can Be Used For: [Clinical decision support, resource planning]
- Risk Score Should NOT Be Used For: [Single decision-making, autonomous decisions]
- Recommended Approach: Risk score as input to multi-factor decision process
```

### 3.2 Claim Model Business Metrics Summary

| Business Metric | Value | Target | Impact | Status |
|-----------------|-------|--------|--------|--------|
| Rejected Recall | **XX%** | ≥75% | Early Problem Detection | [MET/BELOW] |
| Rejected Precision | **XX%** | ≥80% | Operational Efficiency | [MET/BELOW] |
| Paid Recall | **XX%** | ≥90% | Cash Flow Accuracy | [MET/BELOW] |
| SMOTE Effectiveness | **+XX%** minority recall | ≥+15% | Class Balance | [MET/BELOW] |

**FINANCIAL IMPACT ANALYSIS:**

```
COST AVOIDANCE (Rejected Claims):
- Rejected claims detected early: [XX%]
- Processing cost avoided per claim: ~$[XX]
- Total monthly savings: ~[XX] claims × $[XX] = $[XX,XXX]
- Annual potential savings: ~$[XX,XXX]

CASH FLOW ACCURACY:
- Claimed amounts vs. expected revenue: $[XX] vs. $[XX]
- Forecast accuracy: [XX]%
- Impact on financial planning: [Significant/Moderate/Minor]

OPERATIONAL EFFICIENCY:
- Manual review required: [XX]% of claims
- Automation rate: [XX]%
- Staff time saved: [XX] FTE equivalent
- Quality improvement: [Fewer rework/appeals]
```

### 3.3 Key Business Recommendations

**For Risk Model:**
```
1. Deployment Stage: [Pilot/Limited Rollout/Full Deployment]
2. Usage: [Clinical decision support with manual review]
3. Monitoring: [Track high-risk recall monthly]
4. Escalation: If high-risk recall drops below 90%, trigger model review
5. Integration: Use in EHR system for alert generation
```

**For Claim Model:**
```
1. Deployment Stage: [Pilot/Limited Rollout/Full Deployment]
2. Usage: [Automated claim routing with SMOTE-improved rejection detection]
3. Cost Impact: [Estimated $XX,XXX annual savings]
4. Process Change: [New workflow routing rejected claims to special review]
5. Monitoring: Track rejected claim recall weekly
6. Integration: Use in claims management system for auto-routing
```

---

<a name="explainability"></a>
## 4. Feature Importance & Explainability

### 4.1 Risk Model - Feature Importance

#### 4.1.1 Top 10 Most Important Features

```
Rank  Feature Name              Importance Score  Interpretation
────────────────────────────────────────────────────────────────
1.    [Feature Name]            XX.X%             [How it predicts risk]
2.    [Feature Name]            XX.X%             [How it predicts risk]
3.    [Feature Name]            XX.X%             [How it predicts risk]
4.    [Feature Name]            XX.X%             [How it predicts risk]
5.    [Feature Name]            XX.X%             [How it predicts risk]
6.    [Feature Name]            XX.X%             [How it predicts risk]
7.    [Feature Name]            XX.X%             [How it predicts risk]
8.    [Feature Name]            XX.X%             [How it predicts risk]
9.    [Feature Name]            XX.X%             [How it predicts risk]
10.   [Feature Name]            XX.X%             [How it predicts risk]

Cumulative Importance (Top 10): XX.X%
[Interpretation: Top 10 features explain XX% of model predictions]
```

#### 4.1.2 Feature Importance Interpretation

**Top Feature Analysis:**

```
Feature: [Top Feature Name]
Importance: XX.X%

What it means:
- This feature has the LARGEST influence on risk predictions
- Variations in this feature cause biggest changes in risk classification

How it works in the model:
[Describe the relationship between feature and risk prediction]

Business Implication:
[What does this mean for clinical operations?]

Example:
- High value of [feature]: Typically predicts [risk level]
- Low value of [feature]: Typically predicts [risk level]
```

**Second Through Fifth Features:**

[Repeat analysis for features 2-5]

#### 4.1.3 Feature Grouping by Category

| Category | Features | Combined Importance | Interpretation |
|----------|----------|-------------------|-----------------|
| Demographics | [List] | XX% | Patient characteristics drive [XX%] of risk |
| Visit Type | [List] | XX% | Visit characteristics drive [XX%] of risk |
| Financial | [List] | XX% | Financial factors drive [XX%] of risk |
| Temporal | [List] | XX% | Timing factors drive [XX%] of risk |
| Engineered | [List] | XX% | Patient history drives [XX%] of risk |

**INSIGHT:**
```
Most important category: [Category] (XX%)
- Implication: Risk is primarily driven by [what aspect]
- Clinical insight: [What this tells us about high-risk patients]
- Operational insight: [How to allocate resources]

Least important category: [Category] (XX%)
- Could be dropped if model needs simplification
- Or indicates this aspect is well-controlled in hospital
```

### 4.2 Claim Model - Feature Importance

#### 4.2.1 Top 10 Most Important Features

```
Rank  Feature Name              Importance Score  Interpretation
────────────────────────────────────────────────────────────────
1.    [Feature Name]            XX.X%             [How it predicts claim outcome]
2.    [Feature Name]            XX.X%             [How it predicts claim outcome]
3.    [Feature Name]            XX.X%             [How it predicts claim outcome]
4.    [Feature Name]            XX.X%             [How it predicts claim outcome]
5.    [Feature Name]            XX.X%             [How it predicts claim outcome]
6.    [Feature Name]            XX.X%             [How it predicts claim outcome]
7.    [Feature Name]            XX.X%             [How it predicts claim outcome]
8.    [Feature Name]            XX.X%             [How it predicts claim outcome]
9.    [Feature Name]            XX.X%             [How it predicts claim outcome]
10.   [Feature Name]            XX.X%             [How it predicts claim outcome]

Cumulative Importance (Top 10): XX.X%
[Interpretation: Top 10 features explain XX% of model predictions]
```

#### 4.2.2 Feature Importance by Outcome Class

```
For PAID Claims:
Top 3 predictors: [Feature 1, Feature 2, Feature 3]
Pattern: Claims are approved when...

For PENDING Claims:
Top 3 predictors: [Feature 1, Feature 2, Feature 3]
Pattern: Claims enter pending status when...

For REJECTED Claims:
Top 3 predictors: [Feature 1, Feature 2, Feature 3]
Pattern: Claims are rejected when...
```

#### 4.2.3 Feature Grouping Analysis

| Category | Features | Combined Importance | Business Implication |
|----------|----------|-------------------|---------------------|
| Financial | [List] | XX% | Claim amount/gap drives [XX%] of decision |
| Insurance Provider | [List] | XX% | Provider policies drive [XX%] of decision |
| Visit Type | [List] | XX% | Service type drives [XX%] of decision |
| Patient History | [List] | XX% | Patient patterns drive [XX%] of decision |
| Temporal | [List] | XX% | Seasonal/timing drives [XX%] of decision |

### 4.3 Feature Interaction Analysis

**Key Interactions Identified:**

```
Interaction 1: [Feature A] × [Feature B]
- When both high: Predicts [outcome]
- When [Feature A] high but [Feature B] low: Predicts [outcome]
- Business meaning: [Interpretation]

Interaction 2: [Feature A] × [Feature C]
[Same structure]

[Additional interactions as identified]
```

### 4.4 Model Explainability Summary

**What the Models Learn:**

**Risk Model Learning:**
```
The model learns that HIGH RISK patients typically have:
1. [Characteristic 1]
2. [Characteristic 2]
3. [Characteristic 3]
4. [Characteristic pattern]

The model learns that LOW RISK patients typically have:
1. [Characteristic 1]
2. [Characteristic 2]
3. [Characteristic 3]

Most Surprising Finding:
[Feature or pattern that's counterintuitive or unexpected]
```

**Claim Model Learning:**
```
The model learns that REJECTED claims typically involve:
1. [Characteristic 1]
2. [Characteristic 2]
3. [Characteristic 3]

The model learns that PAID claims typically have:
1. [Characteristic 1]
2. [Characteristic 2]
3. [Characteristic 3]

Most Actionable Finding:
[Feature or pattern that provides operational improvement]
```

---

<a name="fairness-analysis"></a>
## 5. Fairness and Bias Analysis

### 5.1 Gender-Based Performance Analysis

#### 5.1.1 Risk Model Performance by Gender

**Male Patients:**
```
Sample Size: [N] patients
Accuracy: XX%
High Risk Recall: XX%
Precision: XX%
```

**Female Patients:**
```
Sample Size: [N] patients
Accuracy: XX%
High Risk Recall: XX%
Precision: XX%
```

**Non-Binary/Other:**
```
Sample Size: [N] patients
Accuracy: XX%
High Risk Recall: XX%
Precision: XX%
```

**Fairness Assessment:**

| Metric | Male | Female | Difference | Status |
|--------|------|--------|------------|--------|
| Accuracy | XX% | XX% | ±XX% | [FAIR/BIASED] |
| High Risk Recall | XX% | XX% | ±XX% | [FAIR/BIASED] |
| Precision | XX% | XX% | ±XX% | [FAIR/BIASED] |

**ANALYSIS:**

```
Fairness Finding: [Fair/Biased]

If FAIR (difference <5%):
✓ Model performs consistently across genders
✓ Safe for deployment regarding gender bias
✓ Recommendation: Deploy with standard monitoring

If BIASED (difference ≥5%):
✗ Model performance differs significantly by gender
✗ Issue: [Underestimating risk for X group / Overestimating for Y group]
✗ Root cause analysis needed:
   - Is it data artifact (training data imbalance)?
   - Is it legitimate clinical difference?
   - Is it model capturing protected feature patterns?
✗ Recommendation: [Mitigation strategy needed]

Mitigation Options (if biased):
1. Stratified retraining: Train separate models per gender
2. Feature removal: Remove or neutralize gender-related features
3. Fairness constraints: Add fairness loss term to model
4. Human review: Implement mandatory human validation for affected group
5. Threshold adjustment: Use different decision thresholds by gender
```

#### 5.1.2 Claim Model Performance by Gender

| Metric | Male | Female | Difference | Status |
|--------|------|--------|------------|--------|
| Accuracy | XX% | XX% | ±XX% | [FAIR/BIASED] |
| Rejected Recall | XX% | XX% | ±XX% | [FAIR/BIASED] |
| Paid Recall | XX% | XX% | ±XX% | [FAIR/BIASED] |

[Similar analysis as risk model]

---

### 5.2 City-Based Performance Analysis

#### 5.2.1 Risk Model Performance by City

**Top Cities by Sample Size:**

| City | Sample Size | Accuracy | High Risk Recall | Status |
|------|-------------|----------|-----------------|--------|
| [City 1] | [N] | XX% | XX% | [FAIR/BIASED] |
| [City 2] | [N] | XX% | XX% | [FAIR/BIASED] |
| [City 3] | [N] | XX% | XX% | [FAIR/BIASED] |
| [City 4] | [N] | XX% | XX% | [FAIR/BIASED] |
| [City 5] | [N] | XX% | XX% | [FAIR/BIASED] |

**Fairness Assessment:**

```
Variation Across Cities:
- Highest Accuracy: [City] at XX%
- Lowest Accuracy: [City] at XX%
- Range: XX% (variation measure)

Fairness Threshold: <5% acceptable variation
Status: [FAIR/BIASED]

If BIASED (variation ≥5%):
Analysis Needed:
1. Data quality variation by city?
2. Different patient populations?
3. Model captures geographic patterns?
4. Unequal training data representation?

Mitigation:
[Strategy based on root cause]
```

#### 5.2.2 Claim Model Performance by City

[Similar analysis as risk model]

---

### 5.3 Insurance Provider-Based Performance Analysis

#### 5.3.1 Risk Model Performance by Insurance Provider

| Provider | Sample Size | Accuracy | High Risk Recall | Issue |
|----------|-------------|----------|-----------------|-------|
| [Provider A] | [N] | XX% | XX% | [None/Bias] |
| [Provider B] | [N] | XX% | XX% | [None/Bias] |
| [Provider C] | [N] | XX% | XX% | [None/Bias] |
| [Provider D] | [N] | XX% | XX% | [None/Bias] |
| [Provider E] | [N] | XX% | XX% | [None/Bias] |

**Analysis:**

```
Insurance Provider Variation:
- Highest Accuracy: [Provider] at XX%
- Lowest Accuracy: [Provider] at XX%
- Range: XX%

Fairness Assessment:
[Similar to city analysis]

Business Implication:
If model performance varies significantly by provider:
1. Does provider have different claims patterns?
2. Do providers have different patient populations?
3. Should model be adjusted for provider-specific predictions?
4. Are there provider-specific fairness implications?
```

#### 5.3.2 Claim Model Performance by Insurance Provider

**Critical Analysis for Claim Model:**

```
Claim Prediction by Provider:
- Provider [A]: Rejected Recall = XX%
- Provider [B]: Rejected Recall = XX%
- Provider [C]: Rejected Recall = XX%

Issue: If recall varies >10% by provider
- Indicates model is provider-biased
- Some providers' rejections are underpredicted
- Financial impact: Missed cost-avoidance for certain providers

Recommendation:
[Provider-specific adjustment strategy if needed]
```

### 5.4 Fairness Summary & Recommendations

**Overall Fairness Assessment:**

| Dimension | Status | Finding | Action |
|-----------|--------|---------|--------|
| Gender | [FAIR/BIASED] | [Summary] | [Mitigation if needed] |
| City | [FAIR/BIASED] | [Summary] | [Mitigation if needed] |
| Insurance Provider | [FAIR/BIASED] | [Summary] | [Mitigation if needed] |

**Deployment Recommendation:**

```
FAIR MODEL (all dimensions fair):
✓ Clear to deploy to production with standard monitoring
✓ No demographic-specific handling needed
✓ Document fairness assessment for stakeholders

PARTIALLY FAIR (some biases identified):
⚠ Deploy with CAUTION
✓ Implement mitigation strategy for biased dimensions
✓ Mandatory human review for affected groups
✓ Enhanced monitoring for bias drift
✓ Plan retraining with fairness constraints

BIASED MODEL (multiple dimensions biased):
✗ DO NOT deploy without mitigation
✗ Address root causes before production
✗ Implement comprehensive fairness improvements
✗ Re-evaluate after mitigation
```

---

<a name="model-cards"></a>
## 6. Model Cards

### 6.1 Model Card: Risk Classification System

---

#### **Model A: Visit Risk Classification**

**Overview**
- **Model Type:** Random Forest Classifier (Gradient Boosting alternative tested)
- **Target Variable:** Risk Score (3 classes: Low, Medium, High)
- **Primary Use Case:** Clinical decision support for hospital visit risk stratification
- **Deployment Context:** Hospital electronic health record system integration
- **Date Created:** 2026-06-13
- **Model Version:** 1.0

**Model Details**

| Aspect | Detail |
|--------|--------|
| Algorithm | Random Forest Classifier (100 trees, tuned) |
| Training Data Size | 386 visits |
| Test Data Size | 97 visits |
| Number of Features | 18 |
| Training Time | [XX seconds/minutes] |
| Model Size | [XX MB] |

**Input Features (18 Total)**

**Demographic Features:**
- `age` - Patient age (numeric: 0-100 years)
- `gender` - Patient gender (categorical: M/F/Other)
- `chronic_flag` - Has chronic condition (binary: 0/1)
- `city` - City of residence (categorical: [list cities])

**Visit Characteristics:**
- `visit_type` - Type of visit (categorical: OPD/ER/ICU)
- `department` - Hospital department (categorical: [departments])
- `length_of_stay_hours` - Duration of stay (numeric: hours)

**Patient History (Engineered):**
- `visit_frequency` - Number of visits in past period (numeric)
- `avg_los_per_patient` - Average stay length (numeric)
- `days_since_registration` - Patient tenure (numeric: days)

**Financial Features:**
- `billed_amount` - Claim amount (numeric: dollars)
- `revenue_realization_ratio` - Payment ratio (numeric: 0-1)

**Insurance Features:**
- `insurance_provider` - Insurance company (categorical)
- `provider_rejection_rate` - Provider's historical rejection rate (numeric: 0-100%)

**Temporal Features:**
- `visit_month` - Month of visit (categorical: 1-12)
- `visit_quarter` - Quarter of visit (categorical: Q1-Q4)
- `visit_day_of_week` - Day of week (categorical: Mon-Sun)

**Output**
- **Output Type:** Multi-class prediction + probabilities
- **Classes:** Low Risk (0), Medium Risk (1), High Risk (2)
- **Probability Output:** 3-class probability distribution (sums to 1.0)
- **Decision Method:** Class with highest probability

**Performance Metrics**

| Metric | Training Data | Test Data | Notes |
|--------|---------------|-----------|-------|
| Accuracy | XX% | XX% | Overall correctness |
| Precision (weighted) | XX% | XX% | False positive control |
| Recall (weighted) | XX% | XX% | False negative control |
| F1-Score (weighted) | XX% | XX% | Balanced metric |
| **High Risk Recall** | XX% | XX% | **CRITICAL BUSINESS METRIC** |
| **High Risk Precision** | XX% | XX% | **CRITICAL BUSINESS METRIC** |
| Macro F1-Score | XX% | XX% | Unweighted average |

**Per-Class Performance (Test Data)**

| Class | Precision | Recall | F1-Score | Support |
|-------|-----------|--------|----------|---------|
| Low | XX% | XX% | XX% | [N] |
| Medium | XX% | XX% | XX% | [N] |
| High | XX% | XX% | XX% | [N] |

**Model Fairness**

| Demographic | Accuracy | Variance | Status |
|-------------|----------|----------|--------|
| By Gender | [M: XX%, F: XX%] | ±XX% | [FAIR/BIASED] |
| By City | [Range: XX%-XX%] | ±XX% | [FAIR/BIASED] |
| By Insurance | [Range: XX%-XX%] | ±XX% | [FAIR/BIASED] |

**Limitations**

1. **High Risk Imbalance:** [XX%] of training data is High Risk class
   - Mitigation: Applied class weights and considered SMOTE
   - Impact: May underpredict high-risk cases
   - Monitoring: Monthly recall assessment required

2. **Temporal Bias:** Model trained on [date range] data
   - May not generalize to [current season/trends]
   - Retraining recommended [frequency]

3. **Feature Limitations:**
   - Missing clinical data (lab values, vitals)
   - Model cannot account for provider decisions
   - Geography may introduce regional variation

4. **Interpretability:** 
   - Random Forest is less interpretable than linear models
   - Feature importance may not capture complex interactions
   - Model decisions cannot be explained to each individual prediction

5. **Demographic Blind Spots:**
   - If biased by [demographic]: Model may disadvantage [group]
   - Mitigation: See fairness section

**Assumptions**

1. Historical patterns continue into future
2. Features are measured accurately and completely
3. Training data represents true population distribution
4. No major changes in hospital operations
5. No major changes in patient populations
6. No external shocks (pandemics, new policies, etc.)

**Hyperparameters**

```python
RandomForestClassifier(
    n_estimators=100,
    max_depth=15,
    min_samples_split=5,
    min_samples_leaf=2,
    random_state=42,
    class_weight='balanced'
)
```

**Training Procedures**

- **Train/Test Split:** Temporal (80/20 split on visit_date)
- **Preprocessing:** 
  - StandardScaler fitting on training data only
  - One-hot encoding for categorical variables
  - No feature selection applied
- **Hyperparameter Tuning:** GridSearchCV with 5-fold cross-validation
- **Evaluation Metric:** F1-Score (weighted)
- **Random Seed:** 42 (for reproducibility)

**Artifacts & Dependencies**

| Artifact | Location | Purpose |
|----------|----------|---------|
| Model | `02_risk_model.joblib` | Trained Random Forest |
| Scaler | `risk_model_scaler.joblib` | Feature preprocessing |
| Encoder | `risk_model_label_encoder.joblib` | Target decoding |
| Metadata | `02_risk_model_metadata.json` | Model specifications |
| Features | `feature_schema.json` | Feature documentation |

**Usage Instructions**

```python
import joblib
import pandas as pd

# Load artifacts
model = joblib.load('02_risk_model.joblib')
scaler = joblib.load('risk_model_scaler.joblib')
encoder = joblib.load('risk_model_label_encoder.joblib')

# Prepare input
X_new = pd.DataFrame([{feature_values}])  # 18 features
X_scaled = scaler.transform(X_new)

# Make prediction
risk_pred = model.predict(X_scaled)[0]  # 0, 1, or 2
risk_proba = model.predict_proba(X_scaled)[0]  # [P(Low), P(Med), P(High)]
risk_label = encoder.inverse_transform([risk_pred])[0]  # "Low", "Medium", "High"

# Decision-making
confidence = max(risk_proba)
if confidence < 0.6:
    # Low confidence - recommend human review
    pass
if risk_label == "High":
    # Trigger high-risk pathway
    pass
```

**Monitoring & Maintenance**

| Item | Frequency | Threshold | Action |
|------|-----------|-----------|--------|
| Accuracy Monitoring | Monthly | <80% | Retrain investigation |
| Recall (High Risk) | Weekly | <90% | Alert clinicians |
| Feature Drift | Monthly | >10% distribution change | Review data quality |
| Fairness Audit | Quarterly | Accuracy variance >5% | Investigate bias |
| Model Retraining | Annually | Or upon drift detection | Retrain with new data |

**Known Issues**

- [List any known performance issues, edge cases, or limitations]
- [Performance on specific subpopulations]
- [Seasonal or temporal variations]

**Future Improvements**

1. Include additional clinical features (vitals, lab values)
2. Implement ensemble with other models
3. Add explainability layer (SHAP values, LIME)
4. Investigate provider-specific models
5. Implement active learning for hard cases
6. Consider more sophisticated resampling (class weights + SMOTE)

**Contact & Support**

- **Model Owner:** [Name/Team]
- **Last Updated:** 2026-06-13
- **Questions/Issues:** [Contact information]

---

### 6.2 Model Card: Claim Outcome Prediction

---

#### **Model B: Claim Outcome Classification**

**Overview**
- **Model Type:** Gradient Boosting Classifier with SMOTE
- **Target Variable:** Claim Status (3 classes: Paid, Pending, Rejected)
- **Primary Use Case:** Automated claim routing and rejection prediction
- **Deployment Context:** Revenue cycle management system
- **Date Created:** 2026-06-13
- **Model Version:** 1.0 (with SMOTE)

**Model Details**

| Aspect | Detail |
|--------|--------|
| Algorithm | Gradient Boosting Classifier (100 estimators) + SMOTE |
| Training Data Size | 386 claims → 1,158 after SMOTE |
| Test Data Size | 97 claims (original distribution) |
| Number of Features | 20 |
| Training Time | [XX seconds/minutes] |
| Model Size | [XX MB] |
| SMOTE Synthetic Samples | [XX] generated |

**Input Features (20 Total)**

[Complete feature list with descriptions - similar to risk model]

**Output**
- **Output Type:** Multi-class prediction + probabilities
- **Classes:** Paid (0), Pending (1), Rejected (2)
- **Probability Output:** 3-class probability distribution
- **Decision Method:** Class with highest probability

**Performance Metrics**

| Metric | Before SMOTE | After SMOTE | Test Data | Notes |
|--------|--------------|------------|-----------|-------|
| Accuracy | XX% | XX% | XX% | Overall correctness |
| Precision (weighted) | XX% | XX% | XX% | False positive control |
| Recall (weighted) | XX% | XX% | XX% | False negative control |
| F1-Score (weighted) | XX% | XX% | XX% | Balanced metric |
| **Rejected Recall** | XX% | XX% | XX% | **CRITICAL METRIC** |
| **Pending Recall** | XX% | XX% | XX% | **CRITICAL METRIC** |

**Per-Class Performance**

**Before SMOTE (Baseline):**

| Class | Precision | Recall | F1-Score | Support |
|-------|-----------|--------|----------|---------|
| Paid | XX% | XX% | XX% | [N] |
| Pending | XX% | XX% | XX% | [N] |
| Rejected | XX% | XX% | XX% | [N] |

**After SMOTE (Final):**

| Class | Precision | Recall | F1-Score | Support |
|-------|-----------|--------|----------|---------|
| Paid | XX% | XX% | XX% | [N] |
| Pending | XX% | XX% | XX% | [N] |
| Rejected | XX% | XX% | XX% | [N] |

**SMOTE Impact:**
- Pending Recall Improvement: +XX%
- Rejected Recall Improvement: +XX%
- Trade-off: Paid class recall may decrease by ~XX%

**Model Fairness**

| Demographic | Accuracy | Rejected Recall | Status |
|-------------|----------|-----------------|--------|
| By Gender | [M: XX%, F: XX%] | ±XX% | [FAIR/BIASED] |
| By City | [Range: XX%-XX%] | ±XX% | [FAIR/BIASED] |
| By Provider | [Range: XX%-XX%] | ±XX% | [FAIR/BIASED] |

**Class Imbalance Analysis**

**Original Data Distribution:**
- Paid: XX% ([N] claims)
- Pending: XX% ([N] claims)
- Rejected: XX% ([N] claims)

**Imbalance Ratio:** [Calculate Paid : Minority]

**SMOTE Solution:**
- Synthetic samples generated for Pending and Rejected
- Balanced training distribution: ~33% each class
- Test set unchanged (preserves true distribution for honest evaluation)
- Benefit: Improved minority class learning
- Trade-off: Potential overfitting on synthetic data (monitor in production)

**Limitations**

1. **Class Imbalance Trade-off:**
   - SMOTE improves minority recall but may hurt majority (Paid) precision
   - Impact: [Description of trade-off in practice]
   - Monitoring: Track Paid class precision monthly

2. **Synthetic Data Artifact:**
   - SMOTE generates synthetic minority samples
   - These are mathematically interpolated, not real claims
   - May not capture all real-world rejection patterns
   - Retraining recommended when new rejection patterns emerge

3. **Provider-Specific Variation:**
   - Providers have different rejection criteria
   - Model may not capture all provider-specific patterns
   - Recommendation: Consider provider-specific models if variation >10%

4. **Temporal Patterns:**
   - Claims patterns may change seasonally or with policy changes
   - Model trained on [date range]
   - Retraining recommended [frequency]

5. **Feature Limitations:**
   - Missing pre-authorization data
   - Missing provider communication details
   - Missing patient appeal history

**Assumptions**

1. SMOTE-generated synthetic data is representative of real minority patterns
2. Training data distribution continues into production
3. Provider policies remain stable
4. Insurance regulations don't change significantly
5. Hospital billing practices remain consistent

**Hyperparameters**

```python
GradientBoostingClassifier(
    n_estimators=100,
    learning_rate=0.1,
    max_depth=5,
    min_samples_split=5,
    random_state=42
)

SMOTE(
    random_state=42,
    k_neighbors=5
)
```

**Training Procedures**

- **Train/Test Split:** Temporal (80/20 on visit_date)
- **Class Imbalance Handling:** SMOTE on training set only
- **Preprocessing:** StandardScaler on original training data before SMOTE
- **Evaluation:** On original test set (true distribution preserved)
- **Hyperparameter Tuning:** GridSearchCV pre-SMOTE
- **Random Seed:** 42

**Artifacts & Dependencies**

| Artifact | Location | Purpose |
|----------|----------|---------|
| Model | `03_claim_model.joblib` | Trained Gradient Boosting |
| Scaler | `claim_model_scaler.joblib` | Feature preprocessing |
| SMOTE | `claim_model_smote.joblib` | Class rebalancing |
| Encoder | `claim_model_label_encoder.joblib` | Target decoding |
| Metadata | `03_claim_model_metadata.json` | Model specifications |
| Class Balance | `claim_model_class_balance.json` | Distribution info |
| Features | `feature_schema.json` | Feature documentation |

**Usage Instructions**

```python
import joblib
import pandas as pd

# Load artifacts
model = joblib.load('03_claim_model.joblib')
scaler = joblib.load('claim_model_scaler.joblib')
encoder = joblib.load('claim_model_label_encoder.joblib')

# Prepare input
X_new = pd.DataFrame([{feature_values}])  # 20 features
X_scaled = scaler.transform(X_new)

# Make prediction
status_pred = model.predict(X_scaled)[0]  # 0, 1, or 2
status_proba = model.predict_proba(X_scaled)[0]  # [P(Paid), P(Pending), P(Rejected)]
status_label = encoder.inverse_transform([status_pred])[0]  # "Paid", "Pending", "Rejected"

# Decision-making with SMOTE consideration
confidence = max(status_proba)
if status_label == "Rejected":
    # HIGH PRIORITY: Send to special review
    # SMOTE improved detection, so this prediction is more reliable
    route_to_special_review(claim)
elif status_label == "Pending":
    # MEDIUM PRIORITY: Flag for follow-up
    # SMOTE improved detection for pending
    flag_for_follow_up(claim)
else:  # Paid
    # Can route to fast-track if confidence >80%
    if confidence > 0.8:
        fast_track(claim)
    else:
        standard_process(claim)
```

**Monitoring & Maintenance**

| Item | Frequency | Threshold | Action |
|------|-----------|-----------|--------|
| Rejected Recall | Weekly | <75% | Alert finance team |
| Paid Precision | Weekly | <90% | Review false rejections |
| Overall Accuracy | Monthly | <82% | Investigation required |
| Provider Variation | Monthly | >10% accuracy variance | Review patterns |
| Cost Savings | Monthly | <$XX/month | Effectiveness check |
| Fairness Audit | Quarterly | >5% variance by demographic | Investigate |
| SMOTE Validity | Quarterly | Monitor synthetic data impact | Retrain if needed |

**Known Issues**

- [Issues specific to claim model]
- [Provider-specific patterns]
- [Seasonal variations]

**Future Improvements**

1. Implement provider-specific models (if variation is high)
2. Add more detailed financial features (billing codes, amounts)
3. Incorporate appeal success history
4. Add explainability layer (SHAP values for decision explanation)
5. Implement active learning for edge cases
6. Monitor SMOTE effectiveness and consider alternatives (class weights, threshold adjustment)
7. Integrate with provider communication systems for real-time feedback

**Contact & Support**

- **Model Owner:** [Name/Team]
- **Last Updated:** 2026-06-13
- **Questions/Issues:** [Contact information]

---

<a name="recommendations"></a>
## 7. Recommendations & Improvements

### 7.1 Recommendations Based on Phase 4 Analysis

**For Risk Model (Model A):**

```
1. HIGH RISK RECALL ACHIEVEMENT [XX%]
   Status: [ACHIEVED/BELOW TARGET]
   
   If ACHIEVED (≥95%):
   ✓ Safe for clinical decision support
   ✓ Proceed to production with monitoring
   
   If BELOW TARGET (<95%):
   ⚠ Requires mitigation before full deployment
   ✓ Options:
     1. Lower decision threshold (more sensitivity, less precision)
     2. Hybrid approach: Model + additional clinical validation
     3. Enhanced feature engineering for high-risk indicators
     4. Ensemble with additional models
     5. Class weight adjustment or SMOTE implementation

2. FAIRNESS ASSESSMENT [STATUS]
   
   If FAIR:
   ✓ No demographic-specific concerns
   ✓ Safe for all populations
   
   If BIASED:
   ⚠ Implement fairness mitigation
   - Stratified analysis and retraining
   - Feature adjustments to reduce bias
   - Mandatory human review for affected groups
   - Enhanced monitoring by demographic

3. RECOMMENDED DEPLOYMENT MODEL
   Primary: Clinical decision support (with human validation)
   Secondary: Resource allocation planning
   Avoid: Autonomous decisions without human review
```

**For Claim Model (Model B):**

```
1. SMOTE EFFECTIVENESS [Rejected Recall: +XX%]
   Status: [SUCCESSFUL/NEEDS IMPROVEMENT]
   
   If SUCCESSFUL (Recall >75%):
   ✓ SMOTE improved minority detection significantly
   ✓ Cost avoidance model is effective
   ✓ Proceed to production with monitoring
   
   If NEEDS IMPROVEMENT (Recall <75%):
   ⚠ Consider additional measures
   ✓ Options:
     1. Aggressive SMOTE: Higher oversampling ratio
     2. Combined approach: SMOTE + class weights
     3. Two-stage model: First detect rejected, then classify others
     4. Threshold adjustment for Rejected class
     5. Enhanced feature engineering (billing gap, provider patterns)

2. FAIRNESS BY PROVIDER [VARIATION: XX%]
   
   If FAIR (variation <5%):
   ✓ Model works consistently across providers
   ✓ Safe for all provider types
   
   If BIASED (variation ≥5%):
   ⚠ Provider-specific adjustment needed
   ✓ Options:
     1. Provider-specific models
     2. Provider feature engineering
     3. Threshold adjustment by provider
     4. Provider-specific SMOTE ratios
     5. Provider stratification in training

3. RECOMMENDED DEPLOYMENT MODEL
   Primary: Claim routing and triage
   - Rejected predictions → Special review (cost avoidance)
   - Pending predictions → Follow-up queue
   - Paid predictions → Fast-track if confidence >80%
   
   Monitoring: Weekly rejected recall, monthly cost impact
```

### 7.2 Handling Imbalanced Data - Implementation Guide

**Current Status: [SMOTE Applied to Claim Model]**

**Recommendation 1: Tune Hyperparameters**

```python
# Option A: Increase class weights (more aggressive)
from sklearn.ensemble import GradientBoostingClassifier
gb_weighted = GradientBoostingClassifier(
    n_estimators=150,
    learning_rate=0.05,
    max_depth=6,
    min_samples_split=3,
    min_samples_leaf=1,
    random_state=42
)

# Option B: Adjust SMOTE ratio (more synthetic samples)
from imblearn.over_sampling import SMOTE
smote_aggressive = SMOTE(
    sampling_strategy=0.8,  # Increase minority to 80% of majority
    k_neighbors=3,
    random_state=42
)

# Option C: Combine approaches (SMOTE + weights)
gb_combined = GradientBoostingClassifier(
    n_estimators=120,
    learning_rate=0.08,
    max_depth=5,
    min_samples_split=4,
    # No class_weight (let SMOTE handle balance)
)
```

**Recommendation 2: Feature Engineering - Create Interaction Features**

```python
# Example: billable_amount vs department average
df['billed_vs_dept_avg'] = (
    df['billed_amount'] / 
    df.groupby('department')['billed_amount'].transform('mean')
)

# Example: billing_gap interaction with provider rejection rate
df['gap_provider_interaction'] = (
    df['billing_gap'] * df['provider_rejection_rate']
)

# Example: visit_type and risk interaction
df['visit_type_risk'] = (
    pd.factorize(df['visit_type'])[0] * df['risk_score']
)

# Example: financial stress indicator
df['financial_stress'] = (
    (df['billed_amount'] > df['billed_amount'].quantile(0.75)) &
    (df['approved_amount'] < df['approved_amount'].quantile(0.25))
).astype(int)

# Add to model and evaluate impact on minority recall
```

**Recommendation 3: Resampling Strategies - Alternatives & Combinations**

```python
# Option A: SMOTE with Tomek Links (clean boundaries)
from imblearn.pipeline import Pipeline
from imblearn.under_sampling import TomekLinks
from imblearn.over_sampling import SMOTE

pipeline = Pipeline([
    ('smote', SMOTE(sampling_strategy=0.7)),
    ('tomek', TomekLinks()),
    ('classifier', GradientBoostingClassifier())
])

# Option B: SMOTE-ENN (SMOTE + Edited Nearest Neighbors)
from imblearn.combine import SMOTETomek, SMOTEENN
smote_enn = SMOTEENN(sampling_strategy=0.7)
X_resampled, y_resampled = smote_enn.fit_resample(X_train, y_train)

# Option C: Stratified K-Fold with custom weights
from sklearn.model_selection import StratifiedKFold
skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

# Option D: Threshold optimization for minority class
from sklearn.metrics import precision_recall_curve
precision, recall, thresholds = precision_recall_curve(y_test, y_proba)
# Find threshold that maximizes F1 for minority class
optimal_threshold = thresholds[np.argmax(2 * precision * recall / (precision + recall))]
predictions_tuned = (y_proba >= optimal_threshold).astype(int)
```

**Recommendation 4: Two-Stage Model for Critical Class**

```python
# Stage 1: Binary classification - Is this claim rejected or not?
from sklearn.ensemble import RandomForestClassifier
stage1_model = RandomForestClassifier(
    n_estimators=100,
    class_weight='balanced',  # Focus on rejection detection
    max_depth=10
)
stage1_model.fit(X_train, (y_train == 'Rejected').astype(int))

# Stage 2: If not rejected, predict Paid vs Pending
stage2_data = X_train[y_train != 'Rejected']
stage2_target = y_train[y_train != 'Rejected']
stage2_model = GradientBoostingClassifier()
stage2_model.fit(stage2_data, stage2_target)

# Prediction pipeline:
if stage1_model.predict_proba(X_new)[0, 1] > 0.7:
    prediction = "Rejected"
else:
    prediction = stage2_model.predict(X_new)
```

**Recommendation 5: Implementation Priority**

```
PHASE 4 ACTIONS:

Immediate (Week 1-2):
✓ Evaluate Phase 4 models using framework in this document
✓ Assess SMOTE effectiveness for claim model
✓ Assess fairness by gender, city, provider
✓ Complete Model Cards (Section 6)

Short Term (Week 3-4):
✓ Implement Recommendation 2 (feature engineering)
✓ Test interaction features impact on minority recall
✓ Evaluate impact on Rejected recall and cost savings

Medium Term (Month 2):
✓ Implement Recommendation 3 (resampling options)
✓ Test alternative imbalance handling strategies
✓ Compare: Current SMOTE vs. alternatives

Long Term (Month 3+):
✓ If minority recall still <75%: Implement Stage 1 binary model
✓ Deploy optimal model to production
✓ Establish monitoring and retraining schedule
```

### 7.3 Risk Stratification Recommendations

**Risk Model Usage:**

```
DEPLOYMENT APPROACH:

Score Range: 0.0 - 1.0 (continuous probability)

1. HIGH RISK (Probability >0.7):
   Actions:
   - Alert clinical team immediately
   - Assign case manager
   - Daily monitoring
   - Escalate to physician within 2 hours
   - ICU bed availability check
   
2. MEDIUM RISK (Probability 0.4-0.7):
   Actions:
   - Schedule for specialist review within 24 hours
   - Increase monitoring frequency
   - Prepare for potential escalation
   - Flag for care coordination
   
3. LOW RISK (Probability <0.4):
   Actions:
   - Standard care pathway
   - Routine monitoring
   - Discharge planning consideration
   - Community follow-up if appropriate

HUMAN VALIDATION LAYER:
- All High Risk classifications: Mandatory physician review
- Medium Risk with comorbidities: Additional validation
- Low Risk with clinical red flags: Override allowed
```

---

## 8. Conclusion

Phase 4 evaluation provides comprehensive analysis of both classification models developed in Phase 3. The framework in this document enables:

1. **Reliability Assessment:** Detailed performance metrics confirming models are safe for deployment
2. **Interpretability:** Feature importance and explainability for stakeholder trust
3. **Fairness Assurance:** Demographic bias analysis ensuring equitable treatment
4. **Continuous Improvement:** Recommendations for hyperparameter tuning, feature engineering, and resampling strategies
5. **Production Readiness:** Model cards documenting all specifications for deployment teams

**Status Summary:**

- ✓ Risk Model: [EVALUATION STATUS - to be filled]
- ✓ Claim Model: [EVALUATION STATUS - to be filled]  
- ✓ Fairness Assessment: [EVALUATION STATUS - to be filled]
- ✓ Model Cards: [DOCUMENTATION STATUS - to be filled]

**Next Steps:**

1. Execute Phase 4 evaluation analysis using this framework
2. Complete all analysis sections with actual model metrics
3. Fill Model Card documents with performance details
4. Finalize deployment recommendations
5. Proceed to Phase 5: Production deployment and monitoring

---

**Document Status:** Framework & Template  
**Last Updated:** 2026-06-13  
**Completion Status:** [To be filled during Phase 4 execution]  

---

## Appendix: Additional Resources

### A1. Evaluation Metrics Reference

**Key Metrics Definitions:**

```
Accuracy = (TP + TN) / (TP + TN + FP + FN)
  - Overall correctness; can be misleading with imbalanced data

Precision = TP / (TP + FP)
  - When model predicts positive, how often is it correct?
  - Minimize false alarms

Recall = TP / (TP + FN)
  - Of all actual positives, how many did model catch?
  - Minimize missed cases (critical for risk & rejections)

F1-Score = 2 * (Precision × Recall) / (Precision + Recall)
  - Harmonic mean of precision and recall
  - Good for imbalanced data

Specificity = TN / (TN + FP)
  - True negative rate; correctly identifying negatives

ROC-AUC = Area under the Receiver Operating Characteristic curve
  - Threshold-independent performance measure
  - 0.5 = random, 1.0 = perfect classification
```

### A2. Python Implementation Template

```python
# Phase 4 Evaluation Script Template
import joblib
import pandas as pd
import numpy as np
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, classification_report, roc_auc_score
)
import matplotlib.pyplot as plt
import seaborn as sns

# Load models and data
model_a = joblib.load('02_risk_model.joblib')
model_b = joblib.load('03_claim_model.joblib')
X_test = pd.read_csv('X_test.csv')
y_test_risk = pd.read_csv('y_test_risk.csv')
y_test_claim = pd.read_csv('y_test_claim.csv')

# Model A Evaluation
pred_risk = model_a.predict(X_test)
proba_risk = model_a.predict_proba(X_test)

accuracy_risk = accuracy_score(y_test_risk, pred_risk)
recall_risk_high = recall_score(y_test_risk, pred_risk, labels=[2], average='weighted')
# ... [additional metrics]

# Fairness Analysis
def evaluate_fairness(y_true, y_pred, demographic):
    results = {}
    for group in demographic.unique():
        mask = demographic == group
        acc = accuracy_score(y_true[mask], y_pred[mask])
        results[group] = {'accuracy': acc, ...}
    return results

fairness_risk = evaluate_fairness(y_test_risk, pred_risk, X_test['gender'])

# Visualization
fig, axes = plt.subplots(2, 2, figsize=(12, 10))
cm = confusion_matrix(y_test_risk, pred_risk)
sns.heatmap(cm, annot=True, fmt='d', ax=axes[0, 0], cmap='Blues')
axes[0, 0].set_title('Risk Model Confusion Matrix')
# ... [additional visualizations]

plt.tight_layout()
plt.savefig('Phase4_Evaluation_Report.png', dpi=300, bbox_inches='tight')
```

### A3. Stakeholder Communication

**For Clinical Teams:**
- Focus on High Risk recall (identify at-risk patients)
- Explain precision (false alarms)
- Provide decision thresholds
- Emphasize human validation importance

**For Finance Teams:**
- Focus on Rejected recall (cost avoidance)
- Quantify financial impact
- Explain trade-offs (Paid vs. Rejected recall)
- ROI calculation

**For IT/Operations:**
- Model specifications and requirements
- Deployment checklist
- Monitoring dashboard specifications
- Integration points and APIs

---

**END OF PHASE 4 FRAMEWORK**

Generate comprehensive Phase 4 analysis by:
1. Executing notebooks and collecting actual metrics
2. Filling sections with real evaluation results
3. Completing Model Cards with details
4. Documenting fairness findings
5. Finalizing recommendations

